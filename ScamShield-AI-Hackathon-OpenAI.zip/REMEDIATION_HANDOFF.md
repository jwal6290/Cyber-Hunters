# Remediation handoff

Snapshot: November 14, 2026. This is the current continuation entry point.

## Provider integration update

The user explicitly requested OpenAI integration. `app.py` now selects the server-side provider with `AI_PROVIDER` (OpenAI by default; Gemini remains opt-in), and OpenAI uses the Responses API with strict structured output, `store: false`, and the existing schema/evidence validation. Configure only a newly issued `OPENAI_API_KEY` in the private `.env`; a key previously posted in chat must be revoked. No key was added to source and no live provider call was made. OpenAI request/response behavior is covered by mocked tests. The standalone Firebase Gemini module remains a separate, inactive integration.

The current implementation also adds `scamshield-text-model.js` to Flask's public asset allowlist. Verify its served route and frontend script order with the current tests.

## Folder identity and scope

The folder containing this document is the patched working copy. The Downloads
original and downloaded ZIP were not edited. Downloads was outside the session's
writable paths. The patched copy deliberately excludes the original .env and runtime
database. Configure secrets privately if running it, without overwriting an existing
.env. Public model downloads and live AI calls were not used for this remediation.

The previous session disconnected before packaging and before an additional proposed
model-fallback patch could execute. That patch must NOT be assumed applied.

## Implemented and tested at the Node level

| Area | Current change | Main files |
| --- | --- | --- |
| Model delivery | Flask route serves the bundled or LOCAL_TEXT_MODEL_PATH-selected model; benchmark --model reaches all JS comparison strategies | app.py, benchmark_text_model.py, benchmark_scanner.js, .env.example |
| Coverage | Complete/partial/unassessed metadata; OCR English notice, 30-page PDF/text-layer disclosure, unreadable and oversized handling, truncation notices | scanner-engine.js, results.js, results.html, history.js |
| Persistence | Per-record checkpoints; temporary sessionStorage results with memory fallback; opted-in history upserts; interrupted-review state | scanner-engine.js, script.js, results.js |
| Privacy | Durable history defaults off; explicit page-level opt-in; preference failure leaves history off | app-controls.js, app.py, scanner-engine.js |
| Learn | Removed scanner-only script that accessed absent elements | learn.html |
| UX | Local callbacks precede optional AI; AI does not replace local score; AI renderer updates its own section; evidence/actions precede scores | results.js, results.html, script.js, style.css |
| Rules | Narrow fixes for ordinary congratulations, negated credential sharing, birthday gift requests and cross-sentence gift-card pressure | scanner-engine.js, test_scanner_rules.js |

Python regression tests were added in test_app.py and test_text_model_benchmark.py,
but were not executed. test_remediation.js adds mocked failure-path and renderer
checks. README was updated but still needs reconciliation with all edge cases.

## Evidence from the earlier remediation run

- All 14 scanner cases passed: eight existing cases and six contextual cases.
- Nine remediation test groups passed: selected-model comparisons; private refresh
  recovery/AI failure; storage fallback; incomplete input; OCR/PDF coverage; local
  results before conflicting AI; Learn local links/result order; mocked renderer;
  privacy preference failure.
- JavaScript syntax checks passed during the work. Re-run after any new change.
- No real-browser end-to-end, accessibility, live Gemini or Flask runtime verification
  was completed. The DOM test uses simplified test doubles.
- Python and python3 resolved to inaccessible WindowsApps aliases. uv was installed,
  but its interpreter discovery also reached inaccessible executables. A workspace
  runtime installation failed because DNS resolution failed. Recheck availability
  rather than assuming this limitation persists forever.

## Remaining work: distinguish confirmed gaps from checks to perform

### Confirmed gaps in current source

1. **Missing/malformed model behavior.** predictTextModel returns null when the model
   is absent and throws for malformed weights/configuration. There is no modelStatus
   field or visible selected-model fallback status. Preserve rule findings and show
   degraded coverage; do not silently substitute a different trained model.
2. **Tokenizer parity.** Training uses word-boundary ASCII tokens with Unicode-aware
   boundaries; Python/browser inference extracts ASCII substrings without those
   boundaries. Add parity fixtures (underscores, accented/non-Latin adjacency, mixed
   digits and repeated tokens) and align all three paths.
3. **Recovery expiration.** getCurrentResults immediately returns in-memory results
   without age checking. Storage expiration is checked on loading, and checkpoints
   renew the timestamp. There is no automatic purge timer. Do not describe this as
   unconditional deletion after 30 minutes. Choose and document a precise policy.
4. **Home-page immediacy.** Home onRecord updates a status summary; full results usually
   wait until the batch completes and navigation occurs. Full inline rendering is
   currently the storage-unavailable fallback. Verify/improve full evidence rendering
   while later files or AI are still pending.
5. **Residual learned-model false positive.** With the shipped model, the fictional
   safety message "Do not pay with gift cards. This is a scam warning." still scored
   44 because the model matched, although the gift-card rule no longer matched.
   Do not claim that the rule fix solved the combined detector.
6. **Documentation drift.** README's gift-card description mentions same-sentence
   logic without its new narrow cross-sentence exception. Its Gemini wording and
   recovery retention description need checking against actual behavior.

### Focused risks to reproduce before changing

- Old asynchronous reviewBatch work may call reviewRecord for the next old record
  after a new scan begins. reviewRecord initially saves its supplied records before
  its completion guard. Ensure stale batches cannot replace newer recovery data.
- With tab storage blocked, verify every screen retains visible results and explains
  that refresh recovery is impossible. Do not persist privately scanned content to
  localStorage as a fallback.
- Inspect history statistics/filter labels, batch dots, numeric scores and no-match
  lists for reassuring low-risk presentation of unassessed content.
- Test stalled network requests, failed CDN library loads/retries and OCR/PDF work;
  only the AI fetch currently has an explicit AbortController timeout.
- Check empty text, unsupported files, attachment coverage, oversized inputs, multiple
  scans, back/forward navigation, refresh during each phase, expired/invalid snapshots,
  and repeated privacy/consent toggles.
- Inspect malformed stored-record validation and dynamic HTML rendering before
  expanding persisted data formats. Use textContent for untrusted strings.
- Verify actual browser focus, layout and keyboard behavior; do not infer these from
  the mock DOM test.

## Evaluation boundaries

Older audits contain historical benchmark numbers, not fresh results for this patched
scanner. The previously evaluated synthetic 101-300 corpus and 17-record file are not
new holdouts. Do not retrain on them while retaining independent-test claims. Use
development data for rule changes; preserve an untouched final evaluation set.
Do not save or print private message contents in test reports.

## Documentation maintenance

Update this file after each meaningful batch: changed behavior, files, exact command
outcomes, remaining gaps. Use VERIFICATION_CHECKLIST.md for acceptance status.
Historical files: NEXT_SESSION_BRIEF.md and SCAMSHIELD_PROJECT_AUDIT.md. Firebase
handoffs describe a separate unfinished integration and are not the active architecture.
