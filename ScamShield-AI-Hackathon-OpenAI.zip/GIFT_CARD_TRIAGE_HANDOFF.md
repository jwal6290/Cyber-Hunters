# Team handoff: gift-card triage precision

This handoff is for the team to review and apply. The team folder was inspected read-only and has not been changed. The updated implementation and regression test are in the personal project:

- `scanner-engine.js` — refined local gift-card rule
- `firebase-ai-review-demo.html` — matching rule in the practice demo
- `test_scanner_rules.js` — six focused regression cases

## What changed

The old personal-project rule treated any nearby mention of “ask,” “pay,” or a gift card as enough to add a medium-risk indicator. It now requires the gift-card phrase and a stronger signal in the same sentence: urgency/secrecy, wire or crypto language, a direct “pay with” instruction, a priced ask/request, or an explicit pressured action.

The cases verified in the personal project:

| Message | Gift-card pressure indicator |
|---|---|
| “I asked for a gift card for my birthday.” | No |
| “You can pay for game credits with gift cards.” | No |
| “Apple asked for a $5 Google giftcard.” | Yes |
| “Urgent: buy a Google gift card and send the code now.” | Yes |
| “Keep this secret and pay with gift cards.” | Yes |
| “Apple asked for a gift card. This is urgent.” | No; context is in a different sentence |

This is still a local heuristic and “Initial Triage,” not a scam verdict or calibrated probability. It only reduces these targeted false positives; it does not establish real-world detection accuracy.

## Apply to the team app

The team checkout has both root-level and `Cyber-Hunters-main` copies of the frontend files. Confirm which `scanner-engine.js` the team runs, and keep copies in sync if both are used. The existing team `untraceable` rule currently combines gift cards with crypto and wire terms, so simply adding a second rule would double-count some messages.

1. In the active `scanner-engine.js`, separate gift cards from the existing `untraceable` rule. Remove gift-card terms from its first pattern and retain crypto terms there; retain the existing wire and money-transfer patterns. Update its description to refer to crypto/wire only.
2. Add the helper below near the core analysis functions. In `analyze()`, after the `TEXT_RULES` loop, add a `gift-card-pressure` indicator with weight `40` when it returns `true`. Do not add a second copy of this indicator.
3. Keep the local score labeled as an initial triage signal. Do not let this rule override a separate AI assessment.
4. Run the six cases in the table through the team's scanner and confirm they match the expected outcomes. Also test several real, consented examples before deployment; this small regression set is not an accuracy benchmark.

```js
function hasGiftCardPressure(text) {
    const giftCard = /\b(?:gift[\s-]*(?:cards?|crad|caard)|google\s*play\s*cards?|(?:itunes|steam|apple)\s+cards?|gift\s+certificates?)\b/i;
    const pressure = /\b(?:urgent(?:ly)?|immediately|act now|asap|secret|confidential|don't tell|do not tell)\b/i;
    const untraceablePayment = /\b(?:wire|bitcoin|btc|crypto(?:currency)?|wallet)\b/i;
    const directPayment = /\bpay\s+(?:with|using|via|in)\b/i;
    const pricedRequest = /\$\s?\d.{0,35}\b(?:ask(?:ed|d|s|ing)?|request(?:ed|ing)?)\b|\b(?:ask(?:ed|d|s|ing)?|request(?:ed|ing)?)\b.{0,35}\$\s?\d/i;
    const pressuredAction = /\b(?:please|you must|you need to|you have to|i need you to)\b.{0,35}\b(?:buy|purchase|send|pay)\b/i;

    return text.split(/(?:[.!?]+\s+)|(?:\r?\n+)/).some(function (sentence) {
        return giftCard.test(sentence) && (
            pressure.test(sentence) ||
            untraceablePayment.test(sentence) ||
            directPayment.test(sentence) ||
            pricedRequest.test(sentence) ||
            pressuredAction.test(sentence)
        );
    });
}
```

In the existing rule array, keep the crypto-specific first pattern separate from the new helper; for example:

```js
/\b(buy|purchase|send|pay (with|in|using|via)|in the form of)\b.{0,30}\b(bitcoin|btc|crypto(currency)?|usdt|ethereum)\b/i
```

The personal-project validation passed 19 pytest tests, 12 unittest tests, JavaScript syntax checks, and all six gift-card regression cases. No live AI or provider accuracy evaluation was performed.
