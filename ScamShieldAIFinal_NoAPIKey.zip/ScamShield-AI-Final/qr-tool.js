/* =========================================================
   ScamShield AI — QR code checking panel
   Decodes an uploaded screenshot or camera frame on the
   device, shows the destination as inert text, and passes
   the payload through the local rule checks. It never opens
   the destination automatically.
========================================================= */
(function () {
    "use strict";

    const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
    const MAX_DECODE_DIMENSION = 1600;
    const CAMERA_INTERVAL_MS = 300;

    function I18n() {
        return window.ScamShieldI18n;
    }

    function t(text, vars) {
        const api = I18n();
        return api ? api.translate(text, vars) : String(text);
    }

    function currentLang() {
        const api = I18n();
        return api ? api.lang : "en";
    }

    function element(tag, className, text) {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text != null) node.textContent = text;
        return node;
    }

    function typeLabel(type) {
        const map = {
            url: "Website",
            email: "Email address",
            phone: "Phone number",
            sms: "SMS",
            wifi: "Wi-Fi network",
            contact: "Contact card",
            location: "Location",
            crypto: "Crypto payment",
            dangerous: "Dangerous link",
            text: "Plain text",
            empty: "Empty"
        };
        return t(map[type] || "Plain text");
    }

    function buildPanel(container) {
        const panel = element("section", "qr-check");
        panel.setAttribute("aria-labelledby", "qrCheckTitle");

        const heading = element("div", "qr-check-heading");
        heading.innerHTML =
            '<span class="eyebrow"><i class="fa-solid fa-qrcode"></i> ' + t("QR CHECK") + "</span>" +
            '<h3 id="qrCheckTitle"></h3>' +
            "<p></p>";
        heading.querySelector("h3").textContent = t("Scan a QR code safely");
        heading.querySelector("p").textContent = t("Upload a screenshot or use your camera. The code is decoded on this device; we show the destination but never open it.");
        panel.appendChild(heading);

        const controls = element("div", "qr-check-controls");
        const cameraButton = element("button", "qr-button", t("Use camera"));
        cameraButton.type = "button";
        cameraButton.innerHTML = '<i class="fa-solid fa-camera"></i> ' + t("Use camera");

        const uploadLabel = element("label", "qr-button");
        uploadLabel.innerHTML = '<i class="fa-solid fa-image"></i> ' + t("Upload QR image");
        const upload = element("input");
        upload.type = "file";
        upload.accept = "image/*";
        upload.hidden = true;
        uploadLabel.appendChild(upload);

        controls.appendChild(cameraButton);
        controls.appendChild(uploadLabel);
        panel.appendChild(controls);

        const cameraWrap = element("div", "qr-camera");
        cameraWrap.hidden = true;
        const video = element("video");
        video.setAttribute("playsinline", "");
        video.muted = true;
        video.setAttribute("aria-label", t("Point the camera at a QR code. It is scanned on this device."));
        cameraWrap.appendChild(video);
        panel.appendChild(cameraWrap);

        const status = element("p", "qr-status");
        status.setAttribute("role", "status");
        status.setAttribute("aria-live", "polite");
        panel.appendChild(status);

        const result = element("div", "qr-result");
        result.hidden = true;
        panel.appendChild(result);

        const note = element("p", "qr-note");
        note.innerHTML = '<i class="fa-solid fa-lock"></i> ' + t("Decoding happens on this device. Nothing is uploaded and the destination is never opened automatically.");
        panel.appendChild(note);

        container.appendChild(panel);

        const state = {
            stream: null,
            timer: null,
            lastPayload: null,
            record: null,
            destroyed: false
        };

        function setStatus(text, tone) {
            status.textContent = text || "";
            status.className = "qr-status" + (tone ? " " + tone : "");
        }

        function clearResult() {
            result.hidden = true;
            result.replaceChildren();
            state.record = null;
            state.lastPayload = null;
        }

        function stopCamera() {
            clearTimeout(state.timer);
            state.timer = null;
            if (state.stream) {
                state.stream.getTracks().forEach(function (track) { track.stop(); });
                state.stream = null;
            }
            video.srcObject = null;
            cameraWrap.hidden = true;
            cameraButton.innerHTML = '<i class="fa-solid fa-camera"></i> ' + t("Use camera");
            cameraButton.setAttribute("aria-pressed", "false");
        }

        function showError(message) {
            setStatus(message, "error");
            clearResult();
        }

        function decodeCanvas(canvas) {
            const api = window.ScamShieldQrDecode;
            if (!api) throw new Error("QR decoder unavailable");
            const context = canvas.getContext("2d", { willReadFrequently: true });
            const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
            return api.decodeImageData(imageData);
        }

        function drawToCanvas(source, width, height) {
            const scale = Math.min(1, MAX_DECODE_DIMENSION / Math.max(width, height));
            const canvas = document.createElement("canvas");
            canvas.width = Math.max(1, Math.round(width * scale));
            canvas.height = Math.max(1, Math.round(height * scale));
            const context = canvas.getContext("2d", { willReadFrequently: true });
            context.drawImage(source, 0, 0, canvas.width, canvas.height);
            return canvas;
        }

        function handlePayload(payload, api) {
            const info = api.classifyPayload(payload);
            if (!info.payload) {
                showError(t("A QR code was found, but it is empty."));
                return;
            }
            if (state.lastPayload === info.payload) return;
            state.lastPayload = info.payload;
            runChecks(info);
        }

        function runChecks(info) {
            const S = window.ScamShield;
            if (!S || typeof S.scanQr !== "function") {
                showError(t("The image could not be read."));
                return;
            }
            const privacyMode = window.ScamShieldControls && window.ScamShieldControls.isPrivacyMode
                ? window.ScamShieldControls.isPrivacyMode()
                : false;
            let record;
            try {
                record = S.scanQr({
                    text: info.payload,
                    displayText: info.displayText,
                    type: info.type
                }, { lang: currentLang(), privacyMode: privacyMode });
            } catch (error) {
                showError(t("The image could not be read."));
                return;
            }
            state.record = record;
            renderResult(info, record, privacyMode);
        }

        function renderResult(info, record, privacyMode) {
            result.replaceChildren();
            result.hidden = false;

            const head = element("div", "qr-result-head");
            const typePill = element("span", "qr-type", typeLabel(info.type));
            head.appendChild(typePill);
            const pill = element("span", "risk-pill " + record.level, t(
                record.level === "high" ? "High Risk" : record.level === "medium" ? "Medium Risk" : "Low Risk"
            ));
            head.appendChild(pill);
            const score = element("span", "qr-score", t("Risk Score:") + " " + record.score + "/100");
            head.appendChild(score);
            result.appendChild(head);

            const label = element("p", "qr-destination-label", t("Decoded destination (not opened)"));
            result.appendChild(label);

            const destination = element("pre", "qr-destination");
            destination.textContent = info.displayText;
            result.appendChild(destination);

            const warning = element("p", "qr-safe-warning", t("This destination was decoded on your device and was not opened."));
            warning.prepend(element("i", "fa-solid fa-shield-halved"));
            result.appendChild(warning);

            result.appendChild(element("p", "qr-explanation", record.explanation));

            const signals = record.indicators.slice(0, 3);
            if (signals.length) {
                const list = element("ul", "qr-signals");
                signals.forEach(function (ind) {
                    const li = element("li", "flag " + ind.severity);
                    const strong = element("strong", null, ind.title);
                    const detail = element("span", null, " (" + ind.detail + ")");
                    li.appendChild(element("i", "fa-solid fa-triangle-exclamation"));
                    const body = element("span");
                    body.appendChild(strong);
                    body.appendChild(document.createTextNode(" "));
                    body.appendChild(detail);
                    li.appendChild(body);
                    list.appendChild(li);
                });
                result.appendChild(list);
            }

            const actions = element("div", "qr-result-actions");
            const copy = element("button", "qr-button", t("Copy destination"));
            copy.type = "button";
            copy.addEventListener("click", function () {
                copyText(info.displayText).then(function (ok) {
                    setStatus(ok ? t("Copied") : t("The image could not be read."), ok ? "success" : "error");
                });
            });
            actions.appendChild(copy);

            const view = element("a", "qr-button solid", t("Check this destination"));
            view.href = privacyMode ? "results.html?private=1" : "results.html?id=" + encodeURIComponent(record.id);
            if (privacyMode) {
                try {
                    sessionStorage.setItem("scamshield-private-results", JSON.stringify({
                        createdAt: Date.now(),
                        records: [record]
                    }));
                } catch (_error) { /* ignore */ }
            }
            actions.appendChild(view);
            result.appendChild(actions);

            result.appendChild(element("p", "qr-note", t("QR checks use local rules only. No QR content is sent to the AI provider.")));
        }

        function copyText(value) {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                return navigator.clipboard.writeText(value).then(function () { return true; }, function () { return false; });
            }
            try {
                const area = document.createElement("textarea");
                area.value = value;
                area.setAttribute("readonly", "");
                area.style.position = "fixed";
                area.style.opacity = "0";
                document.body.appendChild(area);
                area.select();
                const ok = document.execCommand("copy");
                area.remove();
                return Promise.resolve(ok);
            } catch (_error) {
                return Promise.resolve(false);
            }
        }

        function handleDecoded(decoded) {
            const api = window.ScamShieldQrDecode;
            if (!api) {
                showError(t("The image could not be read."));
                return;
            }
            if (!decoded) {
                setStatus(t("No QR code was found. Try a sharper, closer screenshot or better lighting."), "error");
                return;
            }
            setStatus("");
            handlePayload(decoded.payload, api);
        }

        function decodeImageFile(file) {
            const api = window.ScamShieldQrDecode;
            if (!api) {
                showError(t("The image could not be read."));
                return;
            }
            if (file.size > MAX_IMAGE_BYTES) {
                showError(t("That image is too large. Use one under 15 MB."));
                return;
            }
            if (file.type && file.type.indexOf("image/") !== 0) {
                showError(t("The image could not be read."));
                return;
            }
            stopCamera();
            clearResult();
            setStatus(t("Looking for a QR code…"));
            const url = URL.createObjectURL(file);
            const image = new Image();
            image.onload = function () {
                try {
                    const decoded = decodeCanvas(drawToCanvas(image, image.naturalWidth, image.naturalHeight));
                    handleDecoded(decoded);
                } catch (_error) {
                    showError(t("The image could not be read."));
                } finally {
                    URL.revokeObjectURL(url);
                }
            };
            image.onerror = function () {
                URL.revokeObjectURL(url);
                showError(t("The image could not be read."));
            };
            image.src = url;
        }

        upload.addEventListener("change", function () {
            const file = upload.files && upload.files[0];
            upload.value = "";
            if (file) decodeImageFile(file);
        });

        function scanFrame() {
            if (!state.stream || state.destroyed) return;
            if (video.readyState >= 2 && video.videoWidth) {
                try {
                    const decoded = decodeCanvas(drawToCanvas(video, video.videoWidth, video.videoHeight));
                    if (decoded) {
                        stopCamera();
                        setStatus("");
                        handlePayload(decoded.payload, window.ScamShieldQrDecode);
                        return;
                    }
                } catch (_error) { /* keep trying */ }
            }
            state.timer = setTimeout(scanFrame, CAMERA_INTERVAL_MS);
        }

        cameraButton.addEventListener("click", function () {
            if (state.stream) {
                stopCamera();
                setStatus("");
                return;
            }
            clearResult();
            const media = navigator.mediaDevices;
            if (!media || !media.getUserMedia) {
                showError(t("This browser does not support camera capture. You can upload a screenshot instead."));
                return;
            }
            setStatus(t("Point the camera at a QR code. It is scanned on this device."));
            cameraWrap.hidden = false;
            media.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false })
                .then(function (stream) {
                    state.stream = stream;
                    video.srcObject = stream;
                    video.play().catch(function () {});
                    cameraButton.innerHTML = '<i class="fa-solid fa-stop"></i> ' + t("Stop camera");
                    cameraButton.setAttribute("aria-pressed", "true");
                    scanFrame();
                })
                .catch(function (error) {
                    cameraWrap.hidden = true;
                    if (error && (error.name === "NotAllowedError" || error.name === "SecurityError")) {
                        showError(t("Camera access was blocked. You can upload a screenshot instead."));
                    } else {
                        showError(t("No camera was found. You can upload a screenshot instead."));
                    }
                });
        });

        window.addEventListener("pagehide", stopCamera);
        window.addEventListener("beforeunload", stopCamera);
        window.addEventListener("scamshield:langchange", function () {
            heading.querySelector(".eyebrow").innerHTML = '<i class="fa-solid fa-qrcode"></i> ' + t("QR CHECK");
            heading.querySelector("h3").textContent = t("Scan a QR code safely");
            heading.querySelector("p").textContent = t("Upload a screenshot or use your camera. The code is decoded on this device; we show the destination but never open it.");
            cameraButton.innerHTML = '<i class="fa-solid ' + (state.stream ? "fa-stop" : "fa-camera") + '"></i> ' + t(state.stream ? "Stop camera" : "Use camera");
            uploadLabel.innerHTML = '<i class="fa-solid fa-image"></i> ' + t("Upload QR image");
            uploadLabel.appendChild(upload);
            note.innerHTML = '<i class="fa-solid fa-lock"></i> ' + t("Decoding happens on this device. Nothing is uploaded and the destination is never opened automatically.");
            video.setAttribute("aria-label", t("Point the camera at a QR code. It is scanned on this device."));
            if (state.record && state.lastPayload) {
                const info = window.ScamShieldQrDecode.classifyPayload(state.lastPayload);
                const privacyMode = window.ScamShieldControls && window.ScamShieldControls.isPrivacyMode
                    ? window.ScamShieldControls.isPrivacyMode()
                    : false;
                renderResult(info, state.record, privacyMode);
            }
        });

        return { stopCamera: stopCamera, decodeImageFile: decodeImageFile };
    }

    function mount() {
        document.querySelectorAll("[data-qr-tool]").forEach(function (container) {
            if (container.querySelector(".qr-check")) return;
            container.__qrControl = buildPanel(container);
        });
    }

    window.ScamShieldQrTool = {
        mount: mount,
        stopCamera: function () {
            document.querySelectorAll("[data-qr-tool]").forEach(function (container) {
                if (container.__qrControl) container.__qrControl.stopCamera();
            });
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", mount);
    } else {
        mount();
    }
}());
