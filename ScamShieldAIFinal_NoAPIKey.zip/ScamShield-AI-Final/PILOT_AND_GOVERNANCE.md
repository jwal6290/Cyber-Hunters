# Pilot, governance, and measurement

ScamShield AI is a demonstration, not an emergency service and not a fraud detector with calibrated accuracy. This plan describes how a campus, nonprofit, or community group could run a small, supervised pilot without overstating what the tool does.

## Who owns what

| Role | Accountable for | Must not |
| --- | --- | --- |
| IT / security | Deployment, server-side secrets, provider configuration, rate limiting, dependency review, accessibility review, incident response, custody of consented evaluation data | Approve public claims about detection accuracy on their own |
| Management / business | Audience, budget, legal and privacy review, vendor approval, communications, adoption goals, go/no-go decision | Ask staff to paste private messages into a shared channel |
| Joint launch review | Risk acceptance, wording, native-language sign-off, retention rules, evaluation results, rollback plan | Launch while a blocking privacy, accessibility, or credential issue is open |
| Help desk / peer ambassadors | First-line questions, reporting route, feedback collection that does not require message content | Diagnose a possible fraud as a certainty or promise recovery |

Recommended separation of duties: the person who configures the AI provider should not be the only person who reviews its privacy terms, and the person who writes the campaign copy should not be the only person who approves it.

## Launch gates

1. Keep provider API keys server-side. Rotate any key that was ever pasted into chat, source control, screenshots, or a browser.
2. Publish a plain-language notice covering what is sent to the AI provider, what stays local, retention, and how to use Privacy Mode.
3. Confirm the age gate and consent flow match the actual audience and applicable rules. A checkbox is not independent age verification.
4. Have a native Spanish reviewer approve the Spanish interface, warnings, and help text before describing the product as Spanish-supported. Until then, describe it as an English-first demo with a Spanish pilot interface and bilingual local rules.
5. Review the evaluation set and its limits in [EVALUATION.md](EVALUATION.md). Do not quote precision or recall without the caveats and confidence intervals.
6. Test keyboard-only use, screen-reader reading order, contrast, zoom, mobile layout, and reduced motion.
7. Publish the escalation route in [learn.html](learn.html): campus IT/security, account recovery, bank or gift-card issuer, local emergency services, and country-specific reporting examples labeled as examples.
8. Rehearse provider outage, rate-limit, malformed AI response, and leaked-key scenarios. Local rules and safety advice must remain available when the provider fails.

## Awareness and prevention campaign

**Goal:** help people pause, verify through an official channel, and ask for help, without fear-based messaging.

**Four-week outline**

1. **Baseline and launch.** Short anonymous scenario quiz, a one-page "Check before you click" guide, and a link to the scanner and Learn page. Announce that the tool is a demo and that a low score is not proof of safety.
2. **Payment pressure.** Focus on gift cards, wire transfers, crypto, and "keep this secret." Show one concrete example per language and the safe alternative: verify with the person or organization through a known number or app.
3. **QR and delivery messages.** Demonstrate the QR checker on a harmless sample. Emphasize that the destination is displayed as inert text and is never opened automatically.
4. **Practice and feedback.** Run a short clinic, repeat the scenario quiz, publish aggregate adoption and feedback, and list what will change next.

**Channels:** orientation sessions, intranet or student portal, help-desk script, printable posters with a QR code to the Learn page, peer-ambassador chats, and a short demo video with captions.

**Message examples**

- "Not sure about a message? Check it before you click."
- "A real bank will not ask for your password or a one-time code."
- "Verify using a number or app you already trust, not the contact details in the message."
- "If you already shared something, acting quickly still helps."

Avoid "you will be hacked," "100% detection," "AI knows if it is a scam," and claims that the tool can recover money.

## Measuring adoption and protective impact

Collect the minimum data needed, at aggregate level, with a documented retention period. Do not record message text, destinations, or AI prompts for analytics.

**Adoption**

- Unique users and repeat users per week.
- Scans per week, split by text, file, and QR.
- Interface language split.
- AI second-opinion opt-in rate and provider failure rate.
- Learn-page visits and completion of the scenario quiz.
- Help-desk or ambassador contacts that mention the pilot.

**Protective behavior**

- Pre/post scenario quiz: would you click, reply, pay, or verify through an official channel?
- Self-reported actions after a real or simulated message: verified independently, asked for help, stopped a payment, changed a password.
- Optional, ethically approved simulated-phishing exercise, with no individual scoring and a clear debrief.
- Time to complete a check and whether people understood the next step.

**Quality and trust**

- User-reported false positives and false negatives, using a "this looks wrong" route that does not require sending the message.
- Native-speaker review notes and unresolved wording issues.
- Accessibility issues reported and closed.
- Provider errors and the share of checks completed with local rules only.

**Guardrails**

- Report aggregate counts, not individual behavior. Suppress small cells.
- Do not use the tool to monitor employees, students, or private messages.
- Do not turn usage counts into an effectiveness claim. A download or scan count measures exposure, not protection.
- If a comparison group is possible, use a pre-registered design. Otherwise describe findings as signals, not causal impact.
- Keep evaluation data separate from the demo holdout. Never tune on the test set.

## Honest limitations to repeat in every report

- The system identifies scam tactics; it does not determine whether AI wrote a message.
- Scores are heuristic indicators, not calibrated probabilities. A low score does not certify safety.
- The local learned model is trained on English SMS-style text. Its Spanish recall in the demo holdout was 0/10; Spanish triage relies on bilingual rules.
- The Spanish interface and help text have not been validated by native reviewers in this environment.
- The evaluation set is small, synthetic, hand-authored, and not representative of real messages or real-world harm.
- Optional AI review depends on a third-party provider that may retain or review prompts under its terms. Provider output is a second opinion, not a verdict.
- The age gate is a self-attestation. It does not verify age or legal eligibility.
- This demo cannot monitor accounts, stop payments, recover funds, or replace emergency services.

## If something goes wrong

- **Credentials or password shared:** change the password from the official app or site, enable two-factor authentication, sign out other sessions, and contact campus IT/security.
- **Payment or gift card:** contact the bank or card issuer immediately, report the gift-card codes to the issuer, and preserve order and message records.
- **Personal safety:** contact local emergency services. Do not meet someone or travel somewhere because a message told you to.
- **Product incident:** if a key is exposed, rotate it before further use; if provider output is malformed, keep local results and show the failure; if data handling changes, update the notice before collection.
