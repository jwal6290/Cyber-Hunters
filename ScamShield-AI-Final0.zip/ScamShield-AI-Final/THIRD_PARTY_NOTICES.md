# Third-party notices

This repository includes or derives from the following sources. Keep these notices with the files if you publish or redistribute them.

## jsQR

- File: `vendor/jsqr.js`
- Project: https://github.com/cozmo/jsQR
- License: Apache License 2.0
- Use: local QR image decoding. No QR payload is sent to a third party by this module.

The Apache-2.0 license text is included in `vendor/jsqr.LICENSE`.

## Scam Shield SMS corpus

- Source: https://huggingface.co/datasets/rasheq/scam-shield-sms
- License: CC BY 4.0
- Use: offline training, validation, and held-out testing of the generated text model.
- The generated `scamshield-text-model.js` contains feature weights, not raw training messages. Attribution and caveats are documented in `DATASET_SOURCES.md`.

## UCI SMS Spam Collection

- Source: https://archive.ics.uci.edu/dataset/228/sms+spam+collection
- License: CC BY 4.0
- Use: domain-shift benchmark only. Its "spam" label is not equivalent to "scam."

## Bilingual demo holdout

- File: `test/fixtures/eval_bilingual_holdout.json`
- Authorship: synthetic examples written for this demo. No private messages or personal data are included.
- Use: evaluation only. See `EVALUATION.md` for the limitations.

## License status of this project

The project does not currently declare a license for the original ScamShield code. Add one before public redistribution. Do not remove the dataset or dependency attributions when doing so.
