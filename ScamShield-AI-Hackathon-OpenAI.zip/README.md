# ScamShield AI

ScamShield combines browser-side scam-rule analysis with an optional OpenAI second opinion through a Python/Flask endpoint. The provider is selected server-side with `AI_PROVIDER` (`openai` by default, or `gemini` as an alternative); the browser sends extracted text only and never receives the API key or uploaded binary file. Rules-only scanning remains available if AI is not configured. AI review requires a blocking 18+ self-attestation and a separate data-sharing choice recorded in the server session.

## Run locally

1. Install Python 3.10 or later.
2. From this folder, run:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   if (-not (Test-Path .env)) { Copy-Item .env.example .env }
   ```

3. Configure the provider in `.env`. The default is OpenAI: set `OPENAI_API_KEY` to a newly generated key and optionally set `OPENAI_MODEL` (default `gpt-4o-mini`). To use Gemini instead, set `AI_PROVIDER=gemini` and configure `GEMINI_API_KEY`. Keep all credentials server-side; never paste keys into chat, source code, or frontend files. If `.env` already exists, edit only the provider settings you need and do not overwrite it. If a key has been shared, revoke it and replace it before running the provider.
4. Start the app and open the local address:

   ```powershell
   python app.py
   ```

   Visit `http://127.0.0.1:5001`.

   To try the standalone review flow, visit `http://127.0.0.1:5001/firebase-ai-review-demo.html`. It runs Initial Triage in the browser; after the age gate, an explicit AI data-consent choice enables a request to Flask `/api/analyze`.

   For stable server sessions across restarts, set a private `FLASK_SECRET_KEY` in `.env` before running the app. A random key is used for local development if this is omitted. Never commit a real key.

Without a configured provider key, the local scanner remains usable. Do not open the HTML files directly with `file://`; Flask serves the site and same-origin AI endpoint.

## AI and privacy

- AI warning signs must contain verbatim quotes from the submitted text; the backend rejects unsupported or malformed evidence. The AI summary, confidence, context questions, and recommendation are displayed separately from Initial Triage. Scores are heuristic risk indicators, not calibrated statistical probabilities; local rules never override the AI assessment. AI authorship is not assessed.
- Medium risk starts at 40 in both Python and JavaScript; high risk starts at 70. Gift-card pressure requires a same-sentence match with urgency/secrecy, wire or crypto terms, a direct “pay with” instruction, a priced ask/request, or an explicit pressured action. Generic birthday or product-payment mentions alone do not trigger this rule.
- Normal scans are stored in browser `localStorage` history. Privacy Mode prevents newly scanned text from being saved there. For scans started on the home page, results are passed once through `sessionStorage` and removed immediately after loading; private scans do not add scan IDs or text to browser history. The session preference, age attestation, and AI consent are stored server-side; the SQLite rate limiter stores client IP addresses and prunes requests older than one minute. The backend does not log message payloads. Turning Privacy Mode on does not delete older local history.
- OpenAI API requests are optional. The endpoint sets `store: false`, but that setting is not a promise of zero retention; review OpenAI's current API data controls and terms. When Gemini is selected, review Google's current terms and data-use settings as well. Disclose the configured provider before consent and do not submit passwords, one-time codes, financial details, or other sensitive/confidential information.
- The age gate is a blocking self-attestation, not independent age verification. Confirm the selected provider's current eligibility requirements, the hackathon rules, and the intended audience before enabling AI; a checkbox does not establish legal age or make an otherwise ineligible audience acceptable.
- SQLite rate limiting allows 10 AI requests per client IP per minute and persists through app restarts in `instance/scamshield.sqlite3`. Keep `FLASK_SECRET_KEY` private, configure secure cookies behind HTTPS, and do not deploy Flask’s development server publicly. A public deployment also needs production hosting and review of current provider terms and applicable privacy law.

## Optional local text model

The main scanner loads the generated `scamshield-text-model.js` before `scanner-engine.js`; Flask serves that asset through its explicit public-file allowlist. A match adds a medium learned-pattern signal and a conservative medium Initial Triage floor; `ruleScore` stays separate, and the configured AI provider remains an optional second opinion. The model's logistic output is not calibrated and must never be shown as a probability or used as a verdict.

The model was trained offline from the Scam Shield SMS training split plus a small local development supplement. It does not contain raw training messages. To retrain or evaluate the classifier and actual JavaScript scanner on the public held-out set, UCI domain-shift corpus, and an optional labeled local holdout, see [DATASET_SOURCES.md](DATASET_SOURCES.md). Public test messages are downloaded into memory for benchmarking and only aggregate metrics are printed. Do not tune against a holdout and then present it as independent evaluation.

`firebase-ai-review.js` is a separate Firebase AI Logic/Gemini drop-in and is not used by this Flask app. The Flask app's OpenAI integration does not require Firebase AI Logic or a browser-side API key.

## Tests

```powershell
python -m pytest -v
python -m unittest -v
node --check scanner-engine.js
node --check script.js
node --check results.js
node --check app-controls.js
node test_scanner_rules.js
python benchmark_text_model.py --skip-public --user-json path\to\labeled-holdout.json
```

The pytest suite uses `responses` to exercise outbound OpenAI and Gemini HTTP requests, structured schema handling, malformed provider responses, and supported evidence without making live API calls. The scanner regression test covers benign gift-card mentions, explicit pressure, and sentence boundaries.

## Provider references

- [OpenAI API keys](https://platform.openai.com/api-keys)
- [OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [OpenAI API data controls](https://platform.openai.com/docs/guides/your-data)
- [OpenAI API terms](https://openai.com/policies/row-terms-of-use/)
- [Gemini API terms](https://ai.google.dev/gemini-api/docs/terms)
- [Gemini API pricing and free-tier terms](https://ai.google.dev/gemini-api/docs/pricing)
- [Gemini 3.5 Flash-Lite model](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite)
- [Scam Shield SMS dataset](https://huggingface.co/datasets/rasheq/scam-shield-sms)
- [UCI SMS Spam Collection](https://archive.ics.uci.edu/dataset/228/sms+spam+collection)
