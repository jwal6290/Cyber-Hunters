const messageInput = document.getElementById("messageInput");
const analyzeButton = document.getElementById("analyzeButton");
const fileUpload = document.getElementById("fileUpload");
const fileName = document.getElementById("fileName");
const scannerStatus = document.getElementById("scannerStatus");
const aiConsent = document.getElementById("aiConsent");

function t(text, vars) {
    return window.ScamShieldI18n ? window.ScamShieldI18n.translate(text, vars) : text;
}

function currentLang() {
    return window.ScamShieldI18n ? window.ScamShieldI18n.lang : "en";
}

// Display selected file(s)
fileUpload.addEventListener("change", function () {
    const files = Array.from(fileUpload.files);
    if (files.length === 1) {
        fileName.textContent = t("Selected file: {name}", { name: files[0].name });
    } else if (files.length > 1) {
        fileName.textContent = t("Selected files: {names}", { names: files.map(function (f) { return f.name; }).join(", ") });
    } else {
        fileName.textContent = "";
    }
    scannerStatus.textContent = "";
});

// Analyze the message and/or files, then open the results page
analyzeButton.addEventListener("click", async function () {
    const message = messageInput.value.trim();
    const files = Array.from(fileUpload.files);

    if (!message && !files.length) {
        scannerStatus.textContent = t("Please enter a message or upload a file first.");
        return;
    }

    analyzeButton.disabled = true;
    scannerStatus.textContent = t("Analyzing…");

    try {
        await Promise.all([
            window.ScamShieldControls.waitForConsentSync(),
            window.ScamShieldControls.waitForPrivacySync()
        ]);
        const consented = aiConsent.checked;
        const privacyMode = window.ScamShieldControls.isPrivacyMode();
        const records = await window.ScamShield.scan({
            text: message,
            files: files,
            aiConsent: consented,
            privacyMode: privacyMode,
            lang: currentLang()
        }, function (msg) {
            scannerStatus.textContent = msg;
        });
        if (privacyMode) {
            sessionStorage.setItem("scamshield-private-results", JSON.stringify({
                createdAt: Date.now(),
                records: records
            }));
            window.location.replace("results.html?private=1");
        } else {
            window.location.href = "results.html?ids=" + records.map(function (r) { return r.id; }).join(",");
        }
    } catch (err) {
        console.error(err);
        scannerStatus.textContent = t("Something went wrong while scanning. Please try again.");
        analyzeButton.disabled = false;
    }
});

// Clear status when user edits input
messageInput.addEventListener("input", function () {
    scannerStatus.textContent = "";
});
