"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");

const context = {
    window: {
        ScamShieldTextModel: Object.freeze({
            intercept: -2,
            threshold: 0.7,
            weights: Object.freeze({ "rareword": 5 })
        })
    },
    localStorage: { getItem: function () { return null; }, setItem: function () {} },
    URL: URL
};
vm.runInNewContext(fs.readFileSync("scanner-engine.js", "utf8"), context);

const cases = [
    { name: "birthday gift-card request is not pressured", text: "I asked for a gift card for my birthday.", expected: false },
    { name: "general gift-card payment is not pressured", text: "You can pay for game credits with gift cards.", expected: false },
    { name: "priced gift-card request is flagged", text: "Apple asked for a $5 Google giftcard.", expected: true },
    { name: "urgent gift-card request is flagged", text: "Urgent: buy a Google gift card and send the code now.", expected: true },
    { name: "secret gift-card payment is flagged", text: "Keep this secret and pay with gift cards.", expected: true },
    { name: "context in another sentence does not count", text: "Apple asked for a gift card. This is urgent.", expected: false }
];

for (const testCase of cases) {
    const result = context.window.ScamShield.analyze({ text: testCase.text });
    const found = result.indicators.some(function (item) { return item.id === "gift-card-pressure"; });
    assert.equal(found, testCase.expected, testCase.name);
    console.log("PASS " + testCase.name);
}

const matched = context.window.ScamShield.analyze({ text: "rareword appears in this message" });
assert.equal(matched.textModelMatched, true, "learned text match is surfaced");
assert.equal(matched.ruleScore, 3, "rule score remains separate from the model signal");
assert.equal(matched.score, 44, "model contributes a conservative medium-triage floor");
assert.ok(matched.indicators.some(function (item) { return item.id === "learned-text-pattern"; }));
console.log("PASS model signal remains separate from rule score");

const noMatch = context.window.ScamShield.analyze({ text: "ordinary message text" });
assert.equal(noMatch.textModelMatched, false, "below-threshold model output is not flagged");
assert.equal(noMatch.score, noMatch.ruleScore, "non-matching model does not change triage score");
console.log("PASS below-threshold model output leaves triage unchanged");

// QR payloads go through the same local rule checks, never through AI.
const dangerousQr = context.window.ScamShield.scanQr(
    { text: "javascript:alert(1)", displayText: "javascript:alert(1)", type: "dangerous" },
    { lang: "en", privacyMode: true }
);
assert.equal(dangerousQr.source, "qr");
assert.equal(dangerousQr.scoreBasis, "rules");
assert.equal(dangerousQr.qr.localOnly, true);
assert.ok(dangerousQr.indicators.some(function (item) { return item.id === "qr-dangerous-scheme"; }));
assert.ok(dangerousQr.score >= 45);
assert.ok(dangerousQr.actions.some(function (action) { return /Don't open this destination/.test(action); }));
assert.equal(dangerousQr.aiAnalysis, undefined, "QR checks do not call the AI provider");
console.log("PASS dangerous QR scheme is flagged locally and never sent to AI");

const lookalikeQr = context.window.ScamShield.scanQr(
    {
        text: "http://usps-track-update.com/reschedule?fee=2.99",
        displayText: "http://usps-track-update.com/reschedule?fee=2.99",
        type: "url"
    },
    { lang: "en", privacyMode: true }
);
assert.ok(lookalikeQr.indicators.some(function (item) { return item.id === "lookalike"; }));
assert.ok(lookalikeQr.indicators.some(function (item) { return item.evidence; }));
console.log("PASS lookalike QR destination is flagged with quoted evidence");

const wifiQr = context.window.ScamShield.scanQr(
    {
        text: "WIFI:T:WPA;S:CampusGuest;P:[hidden];;",
        displayText: "WIFI:T:WPA;S:CampusGuest;P:[hidden];;",
        type: "wifi"
    },
    { lang: "en", privacyMode: true }
);
assert.equal(wifiQr.qr.destination.indexOf("example123"), -1, "Wi-Fi password is not stored in the record");
assert.ok(wifiQr.notes.some(function (note) { return /password is hidden/i.test(note); }));
console.log("PASS Wi-Fi password is absent from QR records");

const spanish = context.window.ScamShield.analyze({
    text: "URGENTE: Tu cuenta está bloqueada. Verifica tus datos en http://secure-bank-verify.xyz",
    lang: "es"
});
assert.equal(spanish.lang, "es");
assert.ok(spanish.indicators.length > 0);
assert.ok(spanish.indicators.every(function (item) { return typeof item.nextStep === "string" && item.nextStep.length > 0; }));
assert.ok(/cuenta|verifica|estafa/i.test(spanish.explanation));
assert.ok(spanish.actions.some(function (action) { return /No hagas clic|Verifica/.test(action); }));
console.log("PASS Spanish analysis localizes indicators, explanation, and actions");

const hindi = context.window.ScamShield.analyze({
    text: "तुरंत: आपका खाता ब्लॉक हो गया है। गिफ्ट कार्ड खरीदकर कोड भेजें और इसे गुप्त रखें।",
    lang: "hi"
});
assert.equal(hindi.lang, "hi");
assert.ok(hindi.indicators.length > 0);
assert.ok(hindi.indicators.every(function (item) { return typeof item.nextStep === "string" && item.nextStep.length > 0; }));
assert.ok(hindi.indicators.every(function (item) { return /[\u0900-\u097f]/.test(item.title); }));
assert.ok(hindi.actions.length > 0);
assert.ok(hindi.actions.every(function (action) { return typeof action === "string" && action.length > 0; }));
console.log("PASS Hindi analysis localizes indicators, explanation, and actions");

const chinese = context.window.ScamShield.analyze({
    text: "紧急：您的账户已被冻结。请立即购买礼品卡并发送卡号，对此事保密。",
    lang: "zh"
});
assert.equal(chinese.lang, "zh");
assert.ok(chinese.indicators.length > 0);
assert.ok(chinese.indicators.every(function (item) { return typeof item.nextStep === "string" && item.nextStep.length > 0; }));
assert.ok(chinese.indicators.every(function (item) { return /[\u4e00-\u9fff]/.test(item.title); }));
assert.ok(chinese.actions.length > 0);
console.log("PASS Mandarin analysis localizes indicators, explanation, and actions");

const detectedHindi = context.window.ScamShield.analyze({ text: "कृपया अपना पासवर्ड और ओटीपी साझा करें।" });
assert.equal(detectedHindi.lang, "hi", "Devanagari text is detected as Hindi");
const detectedChinese = context.window.ScamShield.analyze({ text: "请提供您的银行账户信息。" });
assert.equal(detectedChinese.lang, "zh", "Han text is detected as Mandarin");
console.log("PASS Hindi and Mandarin scripts are auto-detected");
