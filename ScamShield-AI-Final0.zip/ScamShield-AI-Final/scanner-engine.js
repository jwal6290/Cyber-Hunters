/* =========================================================
   ScamShield AI — Scan Engine
   Runs local rules in the browser. Reads pasted text and uploaded
   files, looks for common scam warning signs, and saves scans to
   local history unless Privacy Mode is enabled.
   Exposes: window.ScamShield
========================================================= */
(function () {
    "use strict";

    const STORAGE_KEY = "scamshield-history";
    const MAX_HISTORY = 200;
    const MAX_FILE_SIZE = 15 * 1024 * 1024; // 15 MB
    const MAX_STORED_TEXT = 6000;
    const MEDIUM_RISK_THRESHOLD = 40;
    const HIGH_RISK_THRESHOLD = 70;

    /* ---------------------------------------------------------
       LANGUAGE SUPPORT
       The interface language is chosen by the user. The engine
       localizes warnings, indicator names, next steps and actions.
       Unsupported languages fall back to English.
    --------------------------------------------------------- */
    function normalizeLang(value) {
        const text = String(value || "").trim().toLowerCase();
        if (/^(zh|cmn|chinese|mandarin)\b/.test(text) || text === "中文" || text === "普通话") return "zh";
        if (/^(hi|hin|hindi)\b/.test(text) || text === "हिंदी" || text === "हिन्दी") return "hi";
        if (/^(es|spa|spanish)\b/.test(text) || text === "español") return "es";
        return "en";
    }

    function detectLanguage(text) {
        const value = String(text || "").toLowerCase();
        if (!value.trim()) return "en";
        if (/[\u4e00-\u9fff]/.test(value)) return "zh";
        if (/[\u0900-\u097f]/.test(value)) return "hi";
        let spanish = 0;
        let english = 0;
        spanish += (value.match(/[áéíóúñü¿¡]/g) || []).length * 2;
        english += (value.match(/\b(the|and|your|you|with|this|that|have|will|account|payment|click|please|verify|package|winner)\b/g) || []).length;
        spanish += (value.match(/\b(el|la|los|las|un|una|de|del|que|y|para|con|por|su|sus|es|está|su cuenta|urgente|pago|verificar|haga clic|premio|banco|paquete|envío|gracias|por favor|contraseña|código|tarjeta|regalo|reclama|ganado|hacienda|policía)\b/g) || []).length;
        return spanish > english ? "es" : "en";
    }

    const RULE_ES = {
        urgency: {
            title: "Lenguaje urgente",
            detail: "te presiona para actuar rápido",
            explain: "crea una sensación de urgencia",
            next: "Baja el ritmo. Comprueba la afirmación por un canal oficial antes de actuar."
        },
        payment: {
            title: "Solicitud de pago sospechosa",
            detail: "pide dinero o datos de tarjeta",
            explain: "pide un pago",
            next: "No pagues ni compartas datos de tarjeta hasta verificar la solicitud por tu cuenta."
        },
        untraceable: {
            title: "Método de pago difícil de rastrear",
            detail: "tarjetas regalo, criptomonedas o transferencias",
            explain: "pide pagar con tarjetas regalo, criptomonedas o transferencias, que no se pueden recuperar fácilmente",
            next: "No compres tarjetas regalo ni envíes criptomonedas o transferencias a alguien que no hayas verificado."
        },
        credentials: {
            title: "Solicitud de información personal",
            detail: "pide contraseñas, códigos o datos de la cuenta",
            explain: "pide que verifiques o compartas datos de tu cuenta",
            next: "Usa la app oficial o escribe la dirección tú mismo. Nunca compartas códigos ni contraseñas."
        },
        prize: {
            title: "Oferta demasiado buena para ser verdad",
            detail: "premios, recompensas o dinero inesperados",
            explain: "promete un premio o una recompensa inesperada",
            next: "No pagues ninguna tasa ni compartas datos para reclamar un premio inesperado."
        },
        threat: {
            title: "Amenazas o intimidación",
            detail: "menciona arresto, acciones legales o multas",
            explain: "amenaza con acciones legales o multas",
            next: "Las agencias oficiales no exigen pagos con tarjetas regalo ni amenazan con arrestarte por mensaje. Verifica con su número oficial."
        },
        investment: {
            title: "Promesa de dinero poco realista",
            detail: "ingresos fáciles o rendimientos garantizados",
            explain: "promete dinero fácil o rendimientos garantizados",
            next: "Comprueba si la oferta está registrada y no envíes dinero basándote solo en un mensaje."
        },
        "impersonation-family": {
            title: "Posible suplantación de un familiar",
            detail: "«número nuevo» o emergencia de un pariente",
            explain: "dice ser un familiar que usa un número nuevo",
            next: "Llama a tu familiar al número que ya tienes."
        },
        techsupport: {
            title: "Falsa alerta de soporte técnico",
            detail: "dice que tu dispositivo está infectado o hackeado",
            explain: "afirma que tu dispositivo ha sido infectado o hackeado",
            next: "No llames al número ni permitas acceso remoto a tu dispositivo."
        },
        secrecy: {
            title: "Te pide que lo mantengas en secreto",
            detail: "los estafadores aíslan a la víctima",
            explain: "pide que mantengas la solicitud en secreto",
            next: "El secretismo es una señal de alerta. Habla con alguien de confianza antes de actuar."
        },
        "generic-greeting": {
            title: "Saludo genérico",
            detail: "no usa tu nombre",
            explain: "usa un saludo genérico en lugar de tu nombre",
            next: "Un saludo genérico no prueba que sea una estafa, pero confirma quién lo envía."
        },
        "call-to-action": {
            title: "Te empuja a hacer clic o responder",
            detail: "instrucciones para abrir un enlace o responder",
            explain: "te empuja a hacer clic en un enlace o responder",
            next: "No toques el enlace. Abre la app o el sitio oficial de la empresa."
        },
        "gift-card-pressure": {
            title: "Presión para pagar con tarjeta regalo",
            detail: "menciona una tarjeta regalo junto con pago, urgencia, secreto o una petición",
            explain: "combina una tarjeta regalo con una petición de pago o presión",
            next: "No compres tarjetas regalo ni compartas los códigos."
        },
        formatting: {
            title: "Formato inusual",
            detail: "muchas mayúsculas o signos de exclamación",
            explain: "usa mayúsculas o signos de exclamación para llamar la atención",
            next: "El formato por sí solo no prueba nada. Lee la petición con calma."
        },
        "learned-text-pattern": {
            title: "Patrón aprendido de mensajes de estafa",
            detail: "coincide con un patrón lingüístico de los datos de entrenamiento locales",
            explain: "coincide con un patrón aprendido en datos de texto etiquetados",
            next: "Es un patrón estadístico, no una cita concreta. Verifica por tu cuenta."
        },
        "qr-dangerous-scheme": {
            title: "Esquema peligroso en el código QR",
            detail: "puede ejecutar código o abrir una app",
            explain: "usa un tipo de enlace que puede ejecutar código",
            next: "No lo abras. Este tipo de código QR puede ejecutar código o abrir una app de forma inesperada."
        }
    };

    const RULE_NEXT_EN = {
        urgency: "Slow down. Check the claim through an official channel before acting.",
        payment: "Don't pay or share card details until you verify the request independently.",
        untraceable: "Gift cards, crypto, and wire transfers are hard to reverse. Don't send them to someone you haven't verified.",
        credentials: "Use the official app or type the address yourself. Never share codes or passwords.",
        prize: "Don't pay a fee or share details to claim an unexpected prize.",
        threat: "Government agencies don't demand gift-card payment or threaten arrest by text. Verify with the agency's official number.",
        investment: "Check whether the offer is registered and never send money based on a message alone.",
        "impersonation-family": "Call the family member on the number you already have for them.",
        techsupport: "Don't call the number or install remote-access software.",
        secrecy: "Secrecy is a warning sign. Talk to someone you trust before acting.",
        "generic-greeting": "A generic greeting alone isn't proof of a scam, but confirm who sent it.",
        "call-to-action": "Don't tap the link. Open the company's official app or website instead.",
        "gift-card-pressure": "Don't buy gift cards or share the codes.",
        formatting: "Formatting alone isn't proof. Read the request carefully.",
        "learned-text-pattern": "This is a statistical pattern, not a specific quote. Verify independently.",
        "qr-dangerous-scheme": "Don't open it. This QR payload can run code or open an app unexpectedly."
    };

    const FLAG_NEXT_EN = {
        "js-link": "Don't open it. A javascript: link can run code in the page.",
        "link": "Don't click. Type the official address yourself or use the company's app.",
        "lookalike": "The address imitates a brand. Close it and go to the official site directly.",
        "ip-link": "A raw IP address is unusual for a legitimate service. Don't open it.",
        "punycode": "The address uses look-alike characters. Don't open it.",
        "shortener": "You can't see the real destination. Expand or avoid the link.",
        "risky-tld": "The domain ending is common in scams. Verify the exact address.",
        "at-link": "The part after @ is the real destination. Don't open it.",
        "host-words": "Words like “verify” in the address are a common trick. Use the official app.",
        "long-host": "Check the domain carefully; scammers add extra words and dashes.",
        "no-https": "HTTP isn't secure. Don't enter any information.",
        "mismatch-link": "The visible text and the real destination differ. Don't click.",
        "sender-mismatch": "Check the sender's real address; the display name can be forged.",
        "reply-to": "Replies go to a different address. Don't reply; contact the company directly.",
        "auth-fail": "The email failed sender verification. Don't trust it.",
        "dangerous-attachment": "Don't open the attachment. Delete it if you weren't expecting it.",
        "html-attachment": "Don't open the web page attachment or type any credentials.",
        "password-form": "Don't type your password. Close the page and use the official app.",
        "external-form": "Don't submit information to this form.",
        "dangerous-file": "Don't open or run the file. Delete it if you weren't expecting it.",
        "double-extension": "The file name hides its real type. Don't open it.",
        "hidden-program": "It is a program in disguise. Don't run it.",
        "macros": "Don't enable macros or editing.",
        "pdf-actions": "Don't run actions or open embedded files.",
        "archive-program": "Don't extract or run the contents.",
        "qr-dangerous-scheme": "Don't open it. This QR payload can run code or open an app unexpectedly."
    };

    const FLAG_ES = {
        "js-link": { title: "El enlace ejecuta código oculto", detail: "un enlace javascript:", explain: "contiene un enlace que ejecuta código oculto", next: "No lo abras. Un enlace javascript: puede ejecutar código en la página." },
        "link": { title: "Enlace sin verificar", detail: "puede llevar a un sitio falso", explain: "incluye un enlace que no puedes verificar", next: "No hagas clic. Escribe tú mismo la dirección oficial o usa la app de la empresa." },
        "lookalike": { title: "Dirección web parecida a una marca", detail: "{host} no es el sitio oficial de {brand}", explain: "enlaza a un sitio que imita a {brand}", next: "La dirección imita una marca. Ciérrala y entra directamente al sitio oficial." },
        "ip-link": { title: "El enlace usa una IP directa", detail: "{host}", explain: "enlaza a una dirección IP en lugar de un sitio con nombre", next: "Una IP directa es poco habitual en un servicio legítimo. No la abras." },
        "punycode": { title: "Caracteres disfrazados en el enlace", detail: "usa letras parecidas", explain: "usa caracteres parecidos para disfrazar una dirección web", next: "La dirección usa caracteres parecidos. No la abras." },
        "shortener": { title: "Enlace acortado", detail: "oculta el destino real", explain: "usa un enlace acortado que oculta el destino real", next: "No ves el destino real. Expándelo o evita el enlace." },
        "risky-tld": { title: "Final de dominio poco habitual", detail: "los dominios .{tld} se usan a menudo en estafas", explain: "enlaza a un dominio .{tld}, habitual en estafas", next: "El final del dominio es común en estafas. Verifica la dirección exacta." },
        "at-link": { title: "Formato de enlace engañoso", detail: "el símbolo @ oculta la dirección real", explain: "usa un formato de enlace engañoso", next: "La parte después de @ es el destino real. No lo abras." },
        "host-words": { title: "Palabras sospechosas en la dirección", detail: "por ejemplo «verificar» o «seguro»", explain: "tiene una dirección cargada de palabras como «seguro» o «verificar»", next: "Palabras como «verificar» en la dirección son un truco habitual. Usa la app oficial." },
        "long-host": { title: "Dirección web demasiado complicada", detail: "{host}", explain: "usa una dirección web inusualmente complicada", next: "Revisa el dominio con cuidado; los estafadores añaden palabras y guiones." },
        "no-https": { title: "Enlace no seguro", detail: "no usa HTTPS", explain: "usa un enlace no seguro (sin HTTPS)", next: "HTTP no es seguro. No introduzcas información." },
        "mismatch-link": { title: "El texto del enlace no coincide con el destino", detail: "muestra {shown} pero abre {target}", explain: "muestra una dirección web pero enlaza a otra", next: "El texto visible y el destino real son distintos. No hagas clic." },
        "sender-mismatch": { title: "El nombre del remitente no coincide con la dirección", detail: "dice ser {name} pero se envió desde {domain}", explain: "llega desde una dirección que no pertenece a la empresa que dice ser", next: "Comprueba la dirección real del remitente; el nombre visible se puede falsificar." },
        "reply-to": { title: "Las respuestas van a otro sitio", detail: "la dirección de respuesta es {reply}, no {from}", explain: "envía tus respuestas a una dirección distinta de la del remitente", next: "Las respuestas van a otra dirección. No respondas; contacta con la empresa directamente." },
        "auth-fail": { title: "Verificación del remitente fallida", detail: "el correo no superó las comprobaciones SPF/DKIM/DMARC", explain: "no superó las comprobaciones de verificación del remitente", next: "El correo no superó la verificación. No confíes en él." },
        "dangerous-attachment": { title: "Adjunto peligroso", detail: "{list}", explain: "incluye un adjunto que podría instalar malware", next: "No abras el adjunto. Bórralo si no lo esperabas." },
        "html-attachment": { title: "Página web enviada como adjunto", detail: "un truco habitual para mostrar formularios de acceso falsos", explain: "incluye una página web adjunta, una forma habitual de mostrar formularios falsos", next: "No abras la página adjunta ni escribas credenciales." },
        "password-form": { title: "Pide la contraseña en un formulario", detail: "{label} contiene un formulario de inicio de sesión", explain: "contiene un formulario que recoge contraseñas", next: "No escribas tu contraseña. Cierra la página y usa la app oficial." },
        "external-form": { title: "El formulario envía datos a otro sitio", detail: "la información que escribas se envía a otro sitio", explain: "contiene un formulario que envía tu información a un sitio externo", next: "No envíes información en este formulario." },
        "dangerous-file": { title: "Tipo de archivo peligroso", detail: "los archivos .{ext} pueden instalar software o ejecutar código", explain: "es un tipo de archivo que puede ejecutar programas en tu dispositivo", next: "No abras ni ejecutes el archivo. Bórralo si no lo esperabas." },
        "double-extension": { title: "Nombre de archivo disfrazado", detail: "«{name}» pretende ser otro tipo de archivo", explain: "usa un nombre disfrazado para ocultar lo que realmente es", next: "El nombre oculta el tipo real. No lo abras." },
        "hidden-program": { title: "Programa oculto dentro", detail: "el archivo es en realidad un programa de Windows", explain: "es en realidad un programa de Windows disfrazado de otro tipo de archivo", next: "Es un programa disfrazado. No lo ejecutes." },
        "macros": { title: "Documento con macros", detail: "las macros pueden ejecutar código oculto", explain: "es un documento con macros que puede ejecutar código oculto", next: "No habilites macros ni la edición." },
        "pdf-actions": { title: "Acciones ocultas en el PDF", detail: "contiene {list}", explain: "contiene acciones ocultas ({list}) que pueden ejecutarse al abrirlo", next: "No ejecutes acciones ni abras archivos incrustados." },
        "archive-program": { title: "El archivo comprimido contiene un programa", detail: "{list}", explain: "es un archivo comprimido que contiene programas", next: "No extraigas ni ejecutes el contenido." },
        "qr-dangerous-scheme": { title: "Esquema peligroso en el código QR", detail: "el código QR usa el esquema {scheme}", explain: "usa un tipo de enlace que puede ejecutar código", next: "No lo abras. Este código QR puede ejecutar código o abrir una app inesperada." }
    };

    const FLAG_HI = {
        "js-link": { title: "छिपा कोड चलाने वाला लिंक", detail: "javascript: लिंक", explain: "ऐसा लिंक है जो छिपा कोड चला सकता है", next: "न खोलें। javascript: लिंक पेज में कोड चला सकता है।" },
        "link": { title: "असत्यापित लिंक", detail: "नकली साइट पर ले जा सकता है", explain: "ऐसा लिंक है जिसे आप सत्यापित नहीं कर सकते", next: "क्लिक न करें। आधिकारिक पता खुद लिखें या कंपनी का ऐप इस्तेमाल करें।" },
        "lookalike": { title: "ब्रांड जैसा दिखने वाला पता", detail: "{host} {brand} की आधिकारिक साइट नहीं है", explain: "{brand} की नकल करने वाली साइट से लिंक करता है", next: "पता ब्रांड की नकल करता है। बंद करें और सीधे आधिकारिक साइट पर जाएँ।" },
        "ip-link": { title: "लिंक सीधे IP इस्तेमाल करता है", detail: "{host}", explain: "नाम वाली साइट के बजाय IP पते से लिंक करता है", next: "वैध सेवा के लिए सीधा IP असामान्य है। न खोलें।" },
        "punycode": { title: "लिंक में छिपे अक्षर", detail: "मिलते-जुलते अक्षर इस्तेमाल करता है", explain: "वेब पता छिपाने के लिए मिलते-जुलते अक्षर इस्तेमाल करता है", next: "पता मिलते-जुलते अक्षरों का उपयोग करता है। न खोलें।" },
        "shortener": { title: "छोटा किया गया लिंक", detail: "असली गंतव्य छिपाता है", explain: "ऐसा छोटा लिंक है जो असली गंतव्य छिपाता है", next: "असली गंतव्य नहीं दिखता। लिंक का असली पता देखें या टालें।" },
        "risky-tld": { title: "असामान्य डोमेन अंत", detail: ".{tld} डोमेन अक्सर घोटालों में इस्तेमाल होते हैं", explain: ".{tld} डोमेन से लिंक करता है, जो घोटालों में आम है", next: "डोमेन अंत घोटालों में आम है। सटीक पता जाँचें।" },
        "at-link": { title: "भ्रामक लिंक प्रारूप", detail: "@ चिह्न असली पता छिपाता है", explain: "भ्रामक लिंक प्रारूप इस्तेमाल करता है", next: "@ के बाद वाला हिस्सा असली गंतव्य है। न खोलें।" },
        "host-words": { title: "पते में संदिग्ध शब्द", detail: "जैसे “verify” या “secure”", explain: "पते में “secure” या “verify” जैसे शब्द हैं", next: "पते में “verify” जैसे शब्द आम चाल है। आधिकारिक ऐप इस्तेमाल करें।" },
        "long-host": { title: "बहुत जटिल वेब पता", detail: "{host}", explain: "असामान्य रूप से जटिल वेब पता इस्तेमाल करता है", next: "डोमेन ध्यान से देखें; घोटालेबाज़ अतिरिक्त शब्द और डैश जोड़ते हैं।" },
        "no-https": { title: "असुरक्षित लिंक", detail: "HTTPS इस्तेमाल नहीं करता", explain: "असुरक्षित (HTTPS रहित) लिंक इस्तेमाल करता है", next: "HTTP सुरक्षित नहीं है। कोई जानकारी न भरें।" },
        "mismatch-link": { title: "लिंक टेक्स्ट और गंतव्य अलग", detail: "{shown} दिखाता है पर {target} खोलता है", explain: "वेब पता दिखाता है पर दूसरी जगह लिंक करता है", next: "दिखने वाला टेक्स्ट और असली गंतव्य अलग हैं। क्लिक न करें।" },
        "sender-mismatch": { title: "प्रेषक का नाम पते से मेल नहीं खाता", detail: "{name} होने का दावा, पर {domain} से भेजा गया", explain: "ऐसे पते से आता है जो कंपनी का नहीं है", next: "प्रेषक का असली पता जाँचें; दिखने वाला नाम नकली हो सकता है।" },
        "reply-to": { title: "जवाब कहीं और जाते हैं", detail: "जवाब पता {reply} है, {from} नहीं", explain: "आपके जवाब प्रेषक से अलग पते पर भेजता है", next: "जवाब अलग पते पर जाते हैं। जवाब न दें; कंपनी से सीधे संपर्क करें।" },
        "auth-fail": { title: "प्रेषक सत्यापन विफल", detail: "ईमेल SPF/DKIM/DMARC जाँच में विफल", explain: "ईमेल प्रेषक सत्यापन जाँच में विफल रहा", next: "ईमेल सत्यापन में विफल रहा। भरोसा न करें।" },
        "dangerous-attachment": { title: "खतरनाक अटैचमेंट", detail: "{list}", explain: "ऐसा अटैचमेंट है जो मैलवेयर इंस्टॉल कर सकता है", next: "अटैचमेंट न खोलें। अप्रत्याशित हो तो हटा दें।" },
        "html-attachment": { title: "अटैचमेंट के रूप में वेब पेज", detail: "नकली लॉगिन फॉर्म दिखाने की आम चाल", explain: "वेब पेज अटैचमेंट है, नकली लॉगिन फॉर्म दिखाने का आम तरीका", next: "अटैचमेंट वेब पेज न खोलें या क्रेडेंशियल न भरें।" },
        "password-form": { title: "फॉर्म में पासवर्ड माँगता है", detail: "{label} में लॉगिन फॉर्म है", explain: "पासवर्ड इकट्ठा करने वाला फॉर्म है", next: "पासवर्ड न भरें। पेज बंद करें और आधिकारिक ऐप इस्तेमाल करें।" },
        "external-form": { title: "फॉर्म डेटा बाहर भेजता है", detail: "आपकी जानकारी कहीं और भेजी जाती है", explain: "आपकी जानकारी बाहरी साइट पर भेजने वाला फॉर्म है", next: "इस फॉर्म में जानकारी न भेजें।" },
        "dangerous-file": { title: "खतरनाक फ़ाइल प्रकार", detail: ".{ext} फ़ाइलें सॉफ़्टवेयर इंस्टॉल या कोड चला सकती हैं", explain: "ऐसी फ़ाइल है जो आपके डिवाइस पर प्रोग्राम चला सकती है", next: "फ़ाइल न खोलें या चलाएँ। अप्रत्याशित हो तो हटा दें।" },
        "double-extension": { title: "छिपा हुआ फ़ाइल नाम", detail: "“{name}” दूसरा फ़ाइल प्रकार होने का दिखावा करता है", explain: "असली फ़ाइल प्रकार छिपाने के लिए नाम का दिखावा", next: "नाम असली प्रकार छिपाता है। न खोलें।" },
        "hidden-program": { title: "अंदर छिपा प्रोग्राम", detail: "फ़ाइल असल में Windows प्रोग्राम है", explain: "दूसरे फ़ाइल प्रकार के रूप में छिपा Windows प्रोग्राम है", next: "यह छिपा प्रोग्राम है। न चलाएँ।" },
        "macros": { title: "मैक्रो वाला दस्तावेज़", detail: "मैक्रो छिपा कोड चला सकते हैं", explain: "मैक्रो वाला दस्तावेज़ है जो छिपा कोड चला सकता है", next: "मैक्रो या एडिटिंग चालू न करें।" },
        "pdf-actions": { title: "PDF में छिपी क्रियाएँ", detail: "{list} शामिल हैं", explain: "खोलने पर चलने वाली छिपी क्रियाएँ ({list}) हैं", next: "क्रियाएँ न चलाएँ या एम्बेडेड फ़ाइलें न खोलें।" },
        "archive-program": { title: "आर्काइव में प्रोग्राम है", detail: "{list}", explain: "ऐसा आर्काइव है जिसमें प्रोग्राम फ़ाइलें हैं", next: "सामग्री न निकालें या चलाएँ।" },
        "qr-dangerous-scheme": { title: "QR कोड में खतरनाक स्कीम", detail: "QR कोड {scheme} स्कीम इस्तेमाल करता है", explain: "ऐसे लिंक प्रकार का उपयोग करता है जो कोड चला सकता है", next: "न खोलें। यह QR कोड कोड चला सकता है या अप्रत्याशित ऐप खोल सकता है।" }
    };

    const FLAG_ZH = {
        "js-link": { title: "隐藏代码链接", detail: "javascript: 链接", explain: "包含可执行隐藏代码的链接", next: "不要打开。javascript: 链接可在页面中执行代码。" },
        "link": { title: "未核实链接", detail: "可能指向假网站", explain: "包含您无法核实的链接", next: "不要点击。请自行输入官方网址或使用公司应用。" },
        "lookalike": { title: "仿冒品牌的网址", detail: "{host} 不是 {brand} 的官方网站", explain: "链接到模仿 {brand} 的网站", next: "该网址模仿品牌。请关闭并直接访问官网。" },
        "ip-link": { title: "链接直接使用 IP", detail: "{host}", explain: "链接到 IP 地址而不是域名", next: "正规服务很少直接使用 IP。不要打开。" },
        "punycode": { title: "链接中的伪装字符", detail: "使用相似字母", explain: "使用相似字符伪装网址", next: "该网址使用相似字符。不要打开。" },
        "shortener": { title: "缩短链接", detail: "隐藏真实目标", explain: "使用隐藏真实目标的缩短链接", next: "您看不到真实目标。请展开或避免点击。" },
        "risky-tld": { title: "异常域名后缀", detail: ".{tld} 域名常用于诈骗", explain: "链接到诈骗中常见的 .{tld} 域名", next: "该域名后缀常见于诈骗。请核实准确地址。" },
        "at-link": { title: "欺骗性链接格式", detail: "@ 符号隐藏真实地址", explain: "使用欺骗性链接格式", next: "@ 后面的部分是真实目标。不要打开。" },
        "host-words": { title: "网址中的可疑词", detail: "例如“verify”或“secure”", explain: "网址中包含“secure”或“verify”等词", next: "网址中的“verify”等词是常见伎俩。请使用官方应用。" },
        "long-host": { title: "过于复杂的网址", detail: "{host}", explain: "使用异常复杂的网址", next: "仔细检查域名；骗子会添加额外单词和连字符。" },
        "no-https": { title: "不安全链接", detail: "未使用 HTTPS", explain: "使用不安全（无 HTTPS）链接", next: "HTTP 不安全。不要输入任何信息。" },
        "mismatch-link": { title: "链接文字与目标不符", detail: "显示 {shown} 但打开 {target}", explain: "显示一个网址却链接到另一个", next: "显示文字与真实目标不同。不要点击。" },
        "sender-mismatch": { title: "发件人名称与地址不符", detail: "声称是 {name}，但来自 {domain}", explain: "来自不属于该公司的地址", next: "检查发件人真实地址；显示名称可以伪造。" },
        "reply-to": { title: "回复发往别处", detail: "回复地址是 {reply}，不是 {from}", explain: "将您的回复发送到与发件人不同的地址", next: "回复会发往其他地址。不要回复；请直接联系公司。" },
        "auth-fail": { title: "发件人验证失败", detail: "邮件未通过 SPF/DKIM/DMARC 检查", explain: "未通过邮件系统发件人验证", next: "该邮件未通过验证。不要信任。" },
        "dangerous-attachment": { title: "危险附件", detail: "{list}", explain: "包含可能安装恶意软件的附件", next: "不要打开附件。如果不是您预期的，请删除。" },
        "html-attachment": { title: "作为附件发送的网页", detail: "展示假登录页的常见伎俩", explain: "包含网页附件，这是展示假登录表单的常见方式", next: "不要打开网页附件或输入凭据。" },
        "password-form": { title: "表单索要密码", detail: "{label} 包含登录表单", explain: "包含收集密码的表单", next: "不要输入密码。关闭页面并使用官方应用。" },
        "external-form": { title: "表单将数据发送到别处", detail: "您输入的信息会发送到其他地方", explain: "包含将信息发送到外部网站的表单", next: "不要向此表单提交信息。" },
        "dangerous-file": { title: "危险文件类型", detail: ".{ext} 文件可能安装软件或执行代码", explain: "是一种可在您设备上运行程序的文件", next: "不要打开或运行。如果不是您预期的，请删除。" },
        "double-extension": { title: "伪装的文件名", detail: "“{name}”伪装成其他文件类型", explain: "使用伪装文件名隐藏真实类型", next: "文件名隐藏了真实类型。不要打开。" },
        "hidden-program": { title: "内部隐藏程序", detail: "该文件实际上是 Windows 程序", explain: "实际上是伪装成其他文件类型的 Windows 程序", next: "这是伪装的程序。不要运行。" },
        "macros": { title: "启用宏的文档", detail: "宏可运行隐藏代码", explain: "是启用宏的文档，可运行隐藏代码", next: "不要启用宏或编辑。" },
        "pdf-actions": { title: "PDF 中的隐藏操作", detail: "包含 {list}", explain: "包含打开时可能运行的隐藏操作（{list}）", next: "不要运行操作或打开嵌入文件。" },
        "archive-program": { title: "压缩包内含程序", detail: "{list}", explain: "是包含程序文件的压缩包", next: "不要解压或运行内容。" },
        "qr-dangerous-scheme": { title: "二维码中的危险协议", detail: "二维码使用 {scheme} 协议", explain: "使用可能执行代码的链接类型", next: "不要打开。该二维码可能执行代码或意外打开应用。" }
    };

    const CATEGORY_ES = {        prize: { title: "Mensaje de premio", tactic: "estafas de premios y recompensas" },
        techsupport: { title: "Alerta de soporte técnico", tactic: "estafas de soporte técnico" },
        government: { title: "Aviso del gobierno o de impuestos", tactic: "estafas de suplantación de organismos" },
        family: { title: "Mensaje de emergencia familiar", tactic: "estafas de suplantación de familiares" },
        investment: { title: "Oferta de inversión o criptomonedas", tactic: "estafas de inversión y criptomonedas" },
        job: { title: "Mensaje de oferta de trabajo", tactic: "estafas de falsas ofertas de trabajo" },
        delivery: { title: "Mensaje de entrega de paquete", tactic: "estafas de entrega y phishing" },
        bank: { title: "Aviso de cuenta bancaria", tactic: "estafas bancarias y phishing" },
        shopping: { title: "Mensaje de compra en línea", tactic: "estafas de compras en línea" },
        login: { title: "Alerta de seguridad de la cuenta", tactic: "phishing de credenciales" },
        email: { title: "Mensaje de correo", tactic: "estafas de phishing" },
        message: { title: "Mensaje de texto", tactic: "estafas de phishing" },
        qr: { title: "Código QR", tactic: "phishing con códigos QR (quishing)" },
        file: { title: "Archivo subido", tactic: "estafas de malware y phishing" }
    };

    const CATEGORY_HI = {
        prize: { title: "इनाम का संदेश", tactic: "इनाम और पुरस्कार घोटाले" },
        techsupport: { title: "तकनीकी सहायता चेतावनी", tactic: "तकनीकी सहायता घोटाले" },
        government: { title: "सरकारी या कर सूचना", tactic: "सरकारी एजेंसी की नकल" },
        family: { title: "परिवार की आपात संदेश", tactic: "परिवार की नकल घोटाले" },
        investment: { title: "निवेश या क्रिप्टो प्रस्ताव", tactic: "निवेश और क्रिप्टो घोटाले" },
        job: { title: "नौकरी प्रस्ताव संदेश", tactic: "नकली नौकरी घोटाले" },
        delivery: { title: "पैकेज डिलीवरी संदेश", tactic: "डिलीवरी और फ़िशिंग घोटाले" },
        bank: { title: "बैंक खाता सूचना", tactic: "बैंक और फ़िशिंग घोटाले" },
        shopping: { title: "ऑनलाइन खरीद संदेश", tactic: "ऑनलाइन खरीद घोटाले" },
        login: { title: "खाता सुरक्षा चेतावनी", tactic: "क्रेडेंशियल फ़िशिंग" },
        email: { title: "ईमेल संदेश", tactic: "फ़िशिंग घोटाले" },
        message: { title: "टेक्स्ट संदेश", tactic: "फ़िशिंग घोटाले" },
        qr: { title: "QR कोड", tactic: "QR कोड फ़िशिंग (क्यूशिंग)" },
        file: { title: "अपलोड की गई फ़ाइल", tactic: "मैलवेयर और फ़िशिंग घोटाले" }
    };

    const CATEGORY_ZH = {
        prize: { title: "奖品消息", tactic: "奖品和奖励诈骗" },
        techsupport: { title: "技术支持警报", tactic: "技术支持诈骗" },
        government: { title: "政府或税务通知", tactic: "冒充政府机构诈骗" },
        family: { title: "家庭紧急消息", tactic: "冒充家人诈骗" },
        investment: { title: "投资或加密货币提议", tactic: "投资和加密货币诈骗" },
        job: { title: "工作机会消息", tactic: "虚假工作机会诈骗" },
        delivery: { title: "包裹派送消息", tactic: "派送和网络钓鱼诈骗" },
        bank: { title: "银行账户通知", tactic: "银行和网络钓鱼诈骗" },
        shopping: { title: "在线购物消息", tactic: "在线购物诈骗" },
        login: { title: "账户安全警报", tactic: "凭据网络钓鱼" },
        email: { title: "电子邮件", tactic: "网络钓鱼诈骗" },
        message: { title: "短信", tactic: "网络钓鱼诈骗" },
        qr: { title: "二维码", tactic: "二维码网络钓鱼（quishing）" },
        file: { title: "上传的文件", tactic: "恶意软件和网络钓鱼诈骗" }
    };

    const KIND_ES = {
        archive: "Archivo comprimido", program: "Archivo de programa", pdf: "Documento PDF",
        document: "Documento de Word", image: "Captura o imagen", html: "Página web",
        text: "Documento de texto"
    };

    const KIND_HI = {
        archive: "संपीड़ित फ़ाइल", program: "प्रोग्राम फ़ाइल", pdf: "PDF दस्तावेज़",
        document: "Word दस्तावेज़", image: "स्क्रीनशॉट या छवि", html: "वेब पेज",
        text: "टेक्स्ट दस्तावेज़"
    };

    const KIND_ZH = {
        archive: "压缩文件", program: "程序文件", pdf: "PDF 文档",
        document: "Word 文档", image: "截图或图片", html: "网页",
        text: "文本文件"
    };

    const ACTION_ES = {
        fileDanger: "No abras, ejecutes ni habilites contenido de este archivo. Bórralo si no lo esperabas.",
        linkPayment: "No hagas clic en el enlace ni proporciones información de pago.",
        link: "No hagas clic en el enlace: escribe tú mismo la dirección oficial de la empresa.",
        payment: "No envíes dinero, tarjetas regalo ni datos de tarjeta.",
        credentials: "Nunca compartas contraseñas, códigos de un solo uso ni datos personales en respuesta a un mensaje.",
        family: "Llama a tu familiar al número que ya tienes.",
        techsupport: "No llames al número ni permitas que nadie acceda a tu dispositivo de forma remota.",
        verify: "Verifica el mensaje en el sitio web o el teléfono oficial de la empresa.",
        reportFile: "Repórtalo a tu proveedor de correo o al equipo de TI, y a la autoridad de fraude de tu país.",
        reportMessage: "Reporta el mensaje si puedes (por ejemplo, reenvía SMS sospechosos al 7726 en EE. UU. o repórtalo en reportfraud.ftc.gov).",
        none1: "No se requiere ninguna acción, pero mantente alerta ante peticiones inesperadas de dinero o información.",
        none2: "Si algo no te cuadra, contacta con el remitente por un canal que ya conozcas.",
        qrDangerous: "No abras este destino. El código QR usa un tipo de enlace peligroso.",
        qrLink: "No abras este destino desde el código QR. Escribe la dirección oficial tú mismo.",
        qrText: "Trata el contenido del código QR como un mensaje no verificado.",
        qrWifi: "Comprueba el nombre de la red Wi-Fi antes de conectarte. No guardamos la contraseña en el historial."
    };

    const ACTION_HI = {
        fileDanger: "इस फ़ाइल की सामग्री न खोलें, न चलाएँ, न चालू करें। अप्रत्याशित हो तो हटा दें।",
        linkPayment: "लिंक पर क्लिक न करें और भुगतान जानकारी न दें।",
        link: "लिंक पर क्लिक न करें — कंपनी का आधिकारिक पता खुद लिखें।",
        payment: "पैसे, गिफ़्ट कार्ड या कार्ड विवरण न भेजें।",
        credentials: "संदेश के जवाब में पासवर्ड, वन-टाइम कोड या व्यक्तिगत विवरण कभी साझा न करें।",
        family: "अपने परिवार के सदस्य को उनके पुराने नंबर पर कॉल करें।",
        techsupport: "नंबर पर कॉल न करें और किसी को दूर से आपके डिवाइस तक पहुँचने न दें।",
        verify: "कंपनी की आधिकारिक वेबसाइट या फ़ोन नंबर से संदेश की पुष्टि करें।",
        reportFile: "इसकी रिपोर्ट अपने ईमेल प्रदाता या IT टीम को और reportfraud.ftc.gov पर करें।",
        reportMessage: "संदेश की रिपोर्ट करें (जैसे संदिग्ध SMS को 7726 पर भेजें या reportfraud.ftc.gov पर रिपोर्ट करें)।",
        none1: "कोई कार्रवाई ज़रूरी नहीं — लेकिन पैसे या जानकारी के अप्रत्याशित अनुरोधों पर सतर्क रहें।",
        none2: "अगर कुछ ठीक न लगे, तो भेजने वाले से उसी भरोसेमंद माध्यम से संपर्क करें जो आप पहले से जानते हैं।",
        qrDangerous: "इस गंतव्य को न खोलें। QR कोड खतरनाक लिंक प्रकार का उपयोग करता है।",
        qrLink: "QR कोड से इस गंतव्य को न खोलें। आधिकारिक पता खुद लिखें।",
        qrText: "QR कोड की सामग्री को असत्यापित संदेश मानें।",
        qrWifi: "कनेक्ट करने से पहले Wi-Fi नेटवर्क का नाम जाँचें। हम पासवर्ड इतिहास में नहीं रखते।"
    };

    const ACTION_ZH = {
        fileDanger: "不要打开、运行或启用此文件中的内容。如果不是您预期的，请删除。",
        linkPayment: "不要点击链接或提供任何付款信息。",
        link: "不要点击链接——请自行输入公司的官方网址。",
        payment: "不要发送金钱、礼品卡或银行卡信息。",
        credentials: "切勿在回复消息时分享密码、一次性验证码或个人信息。",
        family: "拨打您原本保存的家人号码。",
        techsupport: "不要拨打该号码，也不要让任何人远程访问您的设备。",
        verify: "通过公司官方网站或电话核实该消息。",
        reportFile: "向您的电子邮件提供商或 IT 团队举报，并在 reportfraud.ftc.gov 举报。",
        reportMessage: "尽可能举报该消息（例如将可疑短信转发至 7726，或在 reportfraud.ftc.gov 举报）。",
        none1: "无需采取行动——但仍要对意外的金钱或信息请求保持警惕。",
        none2: "如果感觉不对劲，请通过您原本信任的渠道联系发件人。",
        qrDangerous: "不要打开此目标。该二维码使用危险链接类型。",
        qrLink: "不要从二维码打开此目标。请自行输入官方网址。",
        qrText: "将二维码内容视为未核实消息。",
        qrWifi: "连接前检查 Wi-Fi 网络名称。我们不会将密码保存在历史记录中。"
    };

    const JOINERS = {
        en: { two: " and ", many: ", and " },
        es: { two: " y ", many: ", y " },
        hi: { two: " और ", many: ", और " },
        zh: { two: "、", many: "、" }
    };

    const EXPLANATIONS = {
        en: {
            qr: "This QR code", email: "This email", file: "This file", message: "The message",
            noText: "We couldn't find any readable text to analyze, and the file type itself didn't raise any red flags. If you weren't expecting this file, check with the sender before opening it.",
            high: "{subject} {phrases}. These are common tactics used in {tactic}.",
            medium: "{subject} {phrases}. This could be legitimate, but these are also patterns seen in {tactic}, so verify it independently before you act.",
            low: "{subject} has only minor warning signs: it {phrases}. It's probably fine, but stay cautious if you weren't expecting it."
        },
        es: {
            qr: "El código QR", email: "Este correo", file: "Este archivo", message: "El mensaje",
            noText: "No encontramos texto legible que analizar y el tipo de archivo no mostró señales de alerta. Si no esperabas este archivo, confirma con quien lo envió antes de abrirlo.",
            high: "{subject} {phrases}. Son tácticas habituales en {tactic}.",
            medium: "{subject} {phrases}. Podría ser legítimo, pero también son patrones vistos en {tactic}; verifícalo por tu cuenta antes de actuar.",
            low: "{subject} solo tiene señales menores: {phrases}. Probablemente esté bien, pero mantén la cautela si no lo esperabas."
        },
        hi: {
            qr: "यह QR कोड", email: "यह ईमेल", file: "यह फ़ाइल", message: "यह संदेश",
            noText: "हमें विश्लेषण के लिए कोई पठनीय टेक्स्ट नहीं मिला और फ़ाइल प्रकार में कोई चेतावनी संकेत नहीं दिखा। अगर यह फ़ाइल अप्रत्याशित थी, तो खोलने से पहले भेजने वाले से पुष्टि करें।",
            high: "{subject} में ये संकेत मिले: {phrases}। ये {tactic} में आम हैं।",
            medium: "{subject} में ये संकेत मिले: {phrases}। यह वैध हो सकता है, लेकिन {tactic} में भी ऐसे पैटर्न देखे जाते हैं; कार्रवाई से पहले स्वतंत्र रूप से पुष्टि करें।",
            low: "{subject} में केवल छोटे संकेत मिले: {phrases}। शायद यह ठीक है, लेकिन अप्रत्याशित हो तो सतर्क रहें।"
        },
        zh: {
            qr: "该二维码", email: "该电子邮件", file: "该文件", message: "该消息",
            noText: "我们未找到可分析的可读文本，文件类型本身也未显示警示信号。如果该文件不是您预期的，打开前请向发件人核实。",
            high: "{subject}显示出以下信号：{phrases}。这些是{tactic}中常见的手法。",
            medium: "{subject}显示出以下信号：{phrases}。它可能是合法的，但这些也是{tactic}中常见的模式；行动前请独立核实。",
            low: "{subject}只有轻微警示信号：{phrases}。它可能没问题，但如果不是您预期的，请保持谨慎。"
        }
    };

    const RULE_HI = {
        urgency: { title: "तत्काल भाषा", detail: "आपको जल्दी कार्रवाई के लिए दबाव डालता है", explain: "तत्काल कार्रवाई का दबाव बनाता है", next: "रुकें। कार्रवाई से पहले दावे को आधिकारिक माध्यम से जाँचें।" },
        payment: { title: "संदिग्ध भुगतान अनुरोध", detail: "पैसे या कार्ड विवरण माँगता है", explain: "भुगतान माँगता है", next: "स्वतंत्र रूप से पुष्टि किए बिना भुगतान या कार्ड विवरण साझा न करें।" },
        untraceable: { title: "मुश्किल से ट्रेस होने वाला भुगतान", detail: "गिफ़्ट कार्ड, क्रिप्टो या वायर ट्रांसफर", explain: "गिफ़्ट कार्ड, क्रिप्टो या वायर ट्रांसफर माँगता है, जिन्हें वापस पाना मुश्किल है", next: "जिसे आपने सत्यापित न किया हो उसे गिफ़्ट कार्ड, क्रिप्टो या ट्रांसफर न भेजें।" },
        credentials: { title: "व्यक्तिगत जानकारी का अनुरोध", detail: "पासवर्ड, कोड या खाता विवरण माँगता है", explain: "खाते की जानकारी सत्यापित या साझा करने के लिए कहता है", next: "आधिकारिक ऐप इस्तेमाल करें या पता खुद लिखें। कोड या पासवर्ड कभी साझा न करें।" },
        prize: { title: "सच होने के लिए बहुत अच्छा प्रस्ताव", detail: "अप्रत्याशित इनाम या पैसा", explain: "अप्रत्याशित इनाम या लाभ का वादा करता है", next: "अप्रत्याशित इनाम पाने के लिए शुल्क न दें या विवरण साझा न करें।" },
        threat: { title: "धमकी या डराना", detail: "गिरफ्तारी, कानूनी कार्रवाई या जुर्माने का ज़िक्र", explain: "कानूनी कार्रवाई या जुर्माने की धमकी देता है", next: "सरकारी एजेंसियाँ गिफ़्ट कार्ड से भुगतान नहीं माँगतीं और संदेश से गिरफ्तारी की धमकी नहीं देतीं। आधिकारिक नंबर पर पुष्टि करें।" },
        investment: { title: "अवास्तविक कमाई का वादा", detail: "आसान कमाई या गारंटीड रिटर्न", explain: "आसान पैसे या गारंटीड रिटर्न का वादा करता है", next: "देखें कि प्रस्ताव पंजीकृत है या नहीं और सिर्फ संदेश के आधार पर पैसे न भेजें।" },
        "impersonation-family": { title: "परिवार के सदस्य की नकल", detail: "नया नंबर या रिश्तेदार की आपात स्थिति", explain: "खुद को नए नंबर वाला परिवार का सदस्य बताता है", next: "अपने परिवार के सदस्य को उसी नंबर पर कॉल करें जो आपके पास पहले से है।" },
        techsupport: { title: "नकली तकनीकी सहायता चेतावनी", detail: "कहता है कि आपका डिवाइस संक्रमित या हैक है", explain: "दावा करता है कि आपका डिवाइस संक्रमित या हैक हुआ है", next: "नंबर पर कॉल न करें और रिमोट एक्सेस न दें।" },
        secrecy: { title: "गुप्त रखने के लिए कहता है", detail: "घोटालेबाज़ पीड़ित को अलग करते हैं", explain: "अनुरोध गुप्त रखने के लिए कहता है", next: "गोपनीयता एक चेतावनी संकेत है। कार्रवाई से पहले किसी भरोसेमंद से बात करें।" },
        "generic-greeting": { title: "सामान्य अभिवादन", detail: "आपका नाम इस्तेमाल नहीं करता", explain: "आपके नाम की जगह सामान्य अभिवादन करता है", next: "सिर्फ सामान्य अभिवादन घोटाले का प्रमाण नहीं है, लेकिन भेजने वाले की पुष्टि करें।" },
        "call-to-action": { title: "क्लिक या जवाब देने के लिए दबाव", detail: "लिंक खोलने या जवाब देने के निर्देश", explain: "लिंक पर क्लिक करने या जवाब देने के लिए दबाव डालता है", next: "लिंक न दबाएँ। कंपनी का आधिकारिक ऐप या वेबसाइट खोलें।" },
        "gift-card-pressure": { title: "गिफ़्ट कार्ड से भुगतान का दबाव", detail: "गिफ़्ट कार्ड के साथ भुगतान, तात्कालिकता, गोपनीयता या अनुरोध", explain: "गिफ़्ट कार्ड को भुगतान अनुरोध या दबाव के साथ जोड़ता है", next: "गिफ़्ट कार्ड न खरीदें और कोड साझा न करें।" },
        formatting: { title: "असामान्य स्वरूप", detail: "बहुत सारे अपरकेस या विस्मयादिबोधक चिह्न", explain: "ध्यान खींचने के लिए अपरकेस या विस्मयादिबोधक चिह्न इस्तेमाल करता है", next: "सिर्फ स्वरूप प्रमाण नहीं है। अनुरोध शांति से पढ़ें।" },
        "learned-text-pattern": { title: "सीखा हुआ घोटाला पैटर्न", detail: "स्थानीय प्रशिक्षण डेटा के भाषाई पैटर्न से मेल", explain: "लेबल किए गए टेक्स्ट डेटा में सीखे गए पैटर्न से मेल खाता है", next: "यह सांख्यिकीय पैटर्न है, कोई विशिष्ट उद्धरण नहीं। स्वतंत्र रूप से पुष्टि करें।" },
        "qr-dangerous-scheme": { title: "QR कोड में खतरनाक स्कीम", detail: "कोड चला सकता है या ऐप खोल सकता है", explain: "ऐसे लिंक प्रकार का उपयोग करता है जो कोड चला सकता है", next: "इसे न खोलें। यह QR कोड कोड चला सकता है या अप्रत्याशित ऐप खोल सकता है।" }
    };

    const RULE_ZH = {
        urgency: { title: "紧急用语", detail: "催促您快速行动", explain: "制造紧迫感", next: "放慢速度。行动前通过官方渠道核实。" },
        payment: { title: "可疑付款请求", detail: "索要金钱或银行卡信息", explain: "要求付款", next: "独立核实前不要付款或提供银行卡信息。" },
        untraceable: { title: "难以追踪的付款方式", detail: "礼品卡、加密货币或电汇", explain: "要求用礼品卡、加密货币或电汇付款，这些很难追回", next: "不要向未核实的人发送礼品卡、加密货币或电汇。" },
        credentials: { title: "索取个人信息", detail: "索要密码、验证码或账户信息", explain: "要求您验证或分享账户信息", next: "使用官方应用或自行输入网址。切勿分享验证码或密码。" },
        prize: { title: "好得不像真的", detail: "意外奖品、奖励或金钱", explain: "承诺意外的奖品或奖励", next: "不要为领取意外奖品付费或提供信息。" },
        threat: { title: "威胁或恐吓", detail: "提及逮捕、法律行动或罚款", explain: "威胁采取法律行动或罚款", next: "政府机构不会要求用礼品卡付款，也不会通过短信威胁逮捕。请拨打官方电话核实。" },
        investment: { title: "不切实际的赚钱承诺", detail: "轻松收入或保证回报", explain: "承诺轻松赚钱或保证回报", next: "核实该提议是否已注册，不要仅凭一条消息就汇款。" },
        "impersonation-family": { title: "可能冒充家人", detail: "“新号码”或亲属紧急求助", explain: "声称是使用新号码的家人", next: "拨打您原本保存的家人号码。" },
        techsupport: { title: "假技术支持警报", detail: "声称您的设备被感染或被黑", explain: "声称您的设备已被感染或被黑", next: "不要拨打该号码，也不要允许远程访问。" },
        secrecy: { title: "要求您保密", detail: "骗子会孤立受害者", explain: "要求您对请求保密", next: "保密是警示信号。行动前请与可信的人商量。" },
        "generic-greeting": { title: "通用称呼", detail: "没有使用您的名字", explain: "使用通用称呼而不是您的名字", next: "仅有通用称呼不能证明是诈骗，但请确认发件人。" },
        "call-to-action": { title: "催促点击或回复", detail: "指示打开链接或回复", explain: "催促您点击链接或回复", next: "不要点链接。请打开公司的官方应用或网站。" },
        "gift-card-pressure": { title: "礼品卡付款压力", detail: "礼品卡与付款、紧急、保密或请求同时出现", explain: "将礼品卡与付款请求或压力结合", next: "不要购买礼品卡，也不要分享卡号。" },
        formatting: { title: "异常格式", detail: "大量大写字母或感叹号", explain: "用大写字母或感叹号吸引注意", next: "仅格式不能证明什么。请冷静阅读请求。" },
        "learned-text-pattern": { title: "已学习的诈骗模式", detail: "与本地训练数据的语言模式匹配", explain: "与标注文本数据中的学习模式匹配", next: "这是统计模式，不是具体引用。请独立核实。" },
        "qr-dangerous-scheme": { title: "二维码中的危险协议", detail: "可能执行代码或打开应用", explain: "使用可能执行代码的链接类型", next: "不要打开。该二维码可能执行代码或意外打开应用。" }
    };

    const RULE_LOCALES = { es: RULE_ES, hi: RULE_HI, zh: RULE_ZH };
    const FLAG_LOCALES = { es: FLAG_ES, hi: FLAG_HI, zh: FLAG_ZH };
    const CATEGORY_LOCALES = { es: CATEGORY_ES, hi: CATEGORY_HI, zh: CATEGORY_ZH };
    const KIND_LOCALES = { es: KIND_ES, hi: KIND_HI, zh: KIND_ZH };
    const ACTION_LOCALES = { en: null, es: ACTION_ES, hi: ACTION_HI, zh: ACTION_ZH };

    function fillTemplate(template, vars) {
        return String(template || "").replace(/\{(\w+)\}/g, function (_, key) {
            return vars && vars[key] != null ? String(vars[key]) : "…";
        });
    }

    function joinedPhrases(list, lang) {
        if (list.length <= 1) return list.join("");
        const join = JOINERS[lang] || JOINERS.en;
        if (list.length === 2) return list[0] + join.two + list[1];
        const separator = lang === "zh" ? "、" : ", ";
        return list.slice(0, -1).join(separator) + join.many + list[list.length - 1];
    }

    const LIBS = {
        tesseract: "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js",
        pdfjs: "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js",
        pdfWorker: "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js",
        mammoth: "https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js"
    };

    /* ---------------------------------------------------------
       TEXT RULES
       weight = how much the sign adds to the risk score
       explain = phrase used to build the written explanation
    --------------------------------------------------------- */
    const TEXT_RULES = [
        {
            id: "urgency",
            title: "Urgent language",
            detail: "pressures you to act quickly",
            weight: 22,
            explain: "creates a sense of urgency",
            patterns: [
                /\b(urgent(ly)?|immediately|right away|act now|asap|as soon as possible|today only|time[- ]sensitive|don'?t delay|before it'?s too late|last chance|final (notice|warning|reminder|attempt))\b/i,
                /\bwithin \d+\s?(hours?|hrs?|minutes?|mins?|days?)\b/i,
                /\b(expires?|expiring|will expire) (today|soon|tonight|in)\b/i,
                /\b(is|was|has been|have been) (delayed|on hold|suspended|locked|disabled|restricted|deactivated|frozen|blocked)\b/i,
                /\b(avoid|prevent) (interruption|suspension|closure|deactivation|cancellation|penalt(y|ies))\b/i,
                /\bwill be (closed|cancelled|canceled|terminated|deleted|suspended|locked|returned to sender)\b/i,
                /\b(urgente(mente)?|inmediat(amente|o)|ahora mismo|cuanto antes|hoy mismo|solo por hoy|última (oportunidad|advertencia|aviso))\b/i,
                /\bdentro de \d+\s?(horas?|minutos?|días?)\b/i,
                /\b(expira|vence|caduca) (hoy|pronto|esta noche|en)\b/i,
                /\b(está|ha sido|fue) (bloquead[oa]|suspendid[oa]|cancelad[oa]|desactivad[oa]|congelad[oa]|restringid[oa])\b/i,
                /\b(evita|evite) (la )?(interrupción|suspensión|cierre|cancelación|penalización)\b/i,
                /\bserá (cerrad[oa]|cancelad[oa]|eliminad[oa]|bloquead[oa])\b/i,
                /(तुरंत|तत्काल|फौरन|जल्दी|अभी|आज ही|अंतिम (चेतावनी|मौका|सूचना)|समय सीमा|देरी न करें|बंद हो जाएगा|निलंबित|ब्लॉक)/,
                /(紧急|立即|马上|尽快|立刻|今天内|最后机会|最后通知|限时|即将(关闭|过期|停用)|账户.{0,6}(冻结|停用|封锁)|逾期)/
            ]
        },
        {
            id: "payment",
            title: "Suspicious payment request",
            detail: "asks for money or card details",
            weight: 26,
            explain: "asks for a payment",
            patterns: [
                /\b(pay|payment|repay|remit)\b.{0,40}?(\$|€|£|usd|fee|now|here|today|below|online)/i,
                /(\$|€|£)\s?\d+([.,]\d{2})?\b.{0,40}\b(fee|charge|pay|payment|due|owed|outstanding|reschedul|release|redeliver)/i,
                /\b(processing|delivery|shipping|customs|release|redelivery|handling|small|admin(istration)?) (fee|charge|duty|payment)\b/i,
                /\b(send|transfer|lend|wire|need)\b.{0,25}(\$|€|£)\s?\d/i,
                /\b(bank transfer|money transfer|send (me )?(the )?money)\b/i,
                /\b(card (details|number|info(rmation)?)|cvv|cvc|expiry date|bank details|routing number|sort code|billing (details|information))\b/i,
                /\b(paga|pagar|pague|abona|abonar|transfiere|transferir)\b.{0,40}?(\$|€|£|usd|eur|tasa|cargo|ahora|aquí|hoy|en línea)/i,
                /(\$|€|£)\s?\d+([.,]\d{2})?\b.{0,40}\b(tasa|cargo|pago|deuda|pendiente|reenvío|entrega|liberación)\b/i,
                /\b(tasa|cargo|comisión|gastos) (de )?(procesamiento|entrega|envío|aduana|gestión|administración|reenvío)\b/i,
                /\b(datos|número) (de la )?tarjeta\b|\bcódigo de seguridad\b|\bdatos bancarios\b|\bcuenta bancaria\b/i,
                /(भुगतान|पेमेंट|शुल्क|फीस|पैसे (भेजें|दें)|ट्रांसफर|बैंक विवरण|कार्ड (विवरण|नंबर)|सीवीवी|ओटीपी|₹\s?\d+|रुपये)/,
                /(付款|支付|转账|汇款|手续费|运费|关税|付款信息|银行卡|卡号|验证码|立即支付|付款链接|¥\s?\d+|人民币)/
            ]
        },
        {
            id: "untraceable",
            title: "Untraceable payment method",
            detail: "gift cards, crypto, or wire transfers",
            weight: 30,
            explain: "asks to be paid with gift cards, crypto, or wire transfers, which can't be refunded",
            patterns: [
                /\b(buy|purchase|send|pay (with|in|using|via)|in the form of)\b.{0,30}\b(bitcoin|btc|crypto(currency)?|usdt|ethereum)\b/i,
                /\b(wire transfer|western union|moneygram|bitcoin atm|crypto wallet|wallet address)\b/i,
                /\b(zelle|venmo|cash ?app)\b.{0,40}\b(send|pay|transfer)\b/i,
                /\b(compra|comprar|envía|enviar|paga (con|en|usando|mediante)|en forma de)\b.{0,30}\b(bitcoin|btc|criptomoneda|usdt|ethereum)\b/i,
                /\b(transferencia bancaria|western union|moneygram|monedero cripto|dirección de wallet)\b/i,
                /\b(bizum|zelle|venmo|cash ?app)\b.{0,40}\b(envía|paga|transfiere)\b/i,
                /(गिफ़्ट कार्ड|गिफ्ट कार्ड|बिटकॉइन|क्रिप्टो|क्रिप्टोकरेंसी|वेस्टर्न यूनियन|मनीग्राम|वॉलेट पता|USDT)/,
                /(礼品卡|比特币|加密货币|虚拟货币|泰达币|USDT|钱包地址|西联汇款|速汇金)/
            ]
        },
        {
            id: "credentials",
            title: "Request for personal information",
            detail: "asks for passwords, codes, or account details",
            weight: 26,
            explain: "asks you to verify or share personal account information",
            patterns: [
                /\b(verify|confirm|validate|update|re-?activate|unlock|restore|secure)\b.{0,15}\b(your )?(account|identity|information|details|payment|billing|profile|login|credentials)\b/i,
                /\b(requires?|needs?|pending) (verification|validation|confirmation)\b/i,
                /\bverification (required|needed)\b/i,
                /\b(password|passcode|\bpin\b|one[- ]time (code|password|passcode)|\botp\b|verification code|security code|2fa code|login code)\b/i,
                /\b(social security( number)?|\bssn\b|date of birth|mother'?s maiden name|account number|online banking (login|details))\b/i,
                /\b(verifica|verificar|confirma|confirmar|valida|validar|actualiza|actualizar|reactiva|reactivar|desbloquea|desbloquear|restaura|restaurar|protege|proteger)\b.{0,20}\b(tu |su )?(cuenta|identidad|información|datos|pago|facturación|perfil|acceso|credenciales)\b/i,
                /\b(requiere|necesita|pendiente) (de )?(verificación|validación|confirmación)\b/i,
                /\b(verificación|validación) (requerida|necesaria)\b/i,
                /\b(contraseña|clave de acceso|\bpin\b|código de un solo uso|\botp\b|código de verificación|código de seguridad|código 2fa|código de acceso)\b/i,
                /\b(número de seguro social|\bssn\b|fecha de nacimiento|apellido de soltera|número de cuenta|acceso a la banca en línea)\b/i,
                /(पासवर्ड|पासकोड|ओटीपी|वन-टाइम|सत्यापन कोड|सुरक्षा कोड|खाता संख्या|आधार|पैन|जन्म तिथि|बैंक लॉगिन|सत्यापित करें|पुष्टि करें|अपडेट करें|अनलॉक)/,
                /(密码|口令|验证码|动态码|一次性密码|短信验证码|安全码|账号|卡号|身份证|出生日期|验证身份|确认账户|更新信息|解锁账户|登录信息)/
            ]
        },
        {
            id: "prize",
            title: "Too-good-to-be-true offer",
            detail: "unexpected prizes, rewards, or free money",
            weight: 30,
            explain: "promises an unexpected prize or reward",
            patterns: [
                /\bcongratulations\b/i,
                /\byou('ve| have)? (won|been selected|been chosen|qualified)\b/i,
                /\b(winner|lottery|sweepstakes|jackpot|cash prize|grand prize)\b/i,
                /\bclaim (your|the|a)? ?(free )?(prize|reward|gift|money|refund|bonus|winnings)\b/i,
                /\bfree (gift(?![\s-]*cards?\b)|iphone|ipad|prize|money|vacation|trip|cruise)\b/i,
                /\b(unclaimed (funds|money|inheritance)|inheritance|beneficiary of)\b/i,
                /\b(enhorabuena|felicidades)\b/i,
                /\b(has|ha) (ganado|sido seleccionad[oa]|sido elegid[oa])\b/i,
                /\b(ganador|loteria|lotería|sorteo|premio mayor|premio en efectivo)\b/i,
                /\breclama (tu|el|un)? ?(premio|recompensa|regalo|dinero|reembolso|bono|ganancias)\b/i,
                /\b(regalo|iphone|ipad|premio|dinero|viaje|crucero) gratis\b/i,
                /\b(fondos sin reclamar|dinero sin reclamar|herencia|beneficiario de)\b/i,
                /(बधाई हो|बधाई|आपने जीता|इनाम|लॉटरी|लकी ड्रॉ|स्वीपस्टेक|नकद पुरस्कार|मुफ्त उपहार|दावा करें|जैकपॉट|किस्मत)/,
                /(恭喜|中奖|获奖|奖金|奖品|彩票|抽奖|一等奖|现金奖励|免费领取|领取奖品|幸运用户|仅需支付)/
            ]
        },
        {
            id: "threat",
            title: "Threats or intimidation",
            detail: "mentions arrest, legal action, or penalties",
            weight: 25,
            explain: "threatens legal action or penalties",
            patterns: [
                /\b(arrest(ed)?|warrant|lawsuit|legal action|prosecut(e|ion)|police|sheriff|court (date|order|summons))\b/i,
                /\b(irs|tax (refund|debt|evasion)|back taxes|social security administration)\b/i,
                /\b(penalt(y|ies)|fines?|late fee)\b.{0,30}\b(if|unless|will)\b/i,
                /\b(detención|detenid[oa]|orden de arresto|demanda|acción legal|proces[oa]|policía|juzgado|citación judicial)\b/i,
                /\b(hacienda|agencia tributaria|deuda fiscal|impuestos atrasados|seguridad social)\b/i,
                /\b(multa|sanción|recargo)\b.{0,30}\b(si|a menos que|será)\b/i,
                /(गिरफ्तारी|वारंट|मुकदमा|कानूनी कार्रवाई|पुलिस|अदालत|जुर्माना|कर बकाया|आयकर|सामाजिक सुरक्षा)/,
                /(逮捕|通缉|法院|起诉|法律行动|警察|罚款|欠税|税务|税务局|传票|刑事责任)/
            ]
        },
        {
            id: "investment",
            title: "Unrealistic money-making promise",
            detail: "easy income or guaranteed returns",
            weight: 22,
            explain: "promises easy money or guaranteed returns",
            patterns: [
                /\b(guaranteed (returns?|profits?|income)|double your (money|investment)|risk[- ]free (investment|returns?)|passive income|get rich)\b/i,
                /\bearn (up to )?(\$|€|£)?\s?\d[\d,]*\s?(\+|k)?\s?(per|a|an|\/)\s?(day|week|hour|month)\b/i,
                /\b(work from home|no experience (needed|required)|easy money|be your own boss)\b/i,
                /\b(rendimientos? garantizados?|ganancias? garantizadas?|duplica tu (dinero|inversión)|inversión sin riesgo|ingresos pasivos|hazte rico)\b/i,
                /\bgana (hasta )?(\$|€|£)?\s?\d[\d,]*\s?(\+|k)?\s?(por|al|a la|\/)\s?(día|semana|hora|mes)\b/i,
                /\b(trabaja desde casa|sin experiencia|dinero fácil|sé tu propio jefe)\b/i,
                /(गारंटीड रिटर्न|गारंटीड मुनाफा|डबल|जोखिम मुक्त|निवेश|पैसिव इनकम|घर से काम|आसान पैसा|अमीर बनें|हर दिन कमाएँ|महीने में कमाएँ)/,
                /(保证收益|稳赚|高回报|翻倍|无风险|被动收入|在家工作|轻松赚钱|日入|月入|暴富|投资群)/
            ]
        },
        {
            id: "impersonation-family",
            title: "Possible family impersonation",
            detail: "\"new number\" or emergency from a relative",
            weight: 22,
            explain: "claims to be a family member using a new number",
            patterns: [
                /\b(hi|hey|hello) (mum|mom|dad|mother|father|grandma|grandpa)\b/i,
                /\b(this is|it'?s) my new (number|phone)\b/i,
                /\bi (lost|broke|dropped) my phone\b/i,
                /\b(este|éste) es mi (nuevo )?(número|teléfono)\b/i,
                /\b(perdí|se me rompió|se me cayó) (mi )?(teléfono|móvil|celular)\b/i,
                /(माँ|मां|पापा|पिताजी|नया नंबर|फोन खो गया|फोन टूट गया|मेरा नंबर|यह मैं हूँ|मैं फंस गया|मुझे पैसे चाहिए)/,
                /(妈|妈妈|爸|爸爸|我换了.{0,4}号码|新号码|手机丢了|手机坏了|这是我的新号|我遇到麻烦|急需用钱)/
            ]
        },
        {
            id: "techsupport",
            title: "Fake tech-support alert",
            detail: "claims your device is infected or hacked",
            weight: 25,
            explain: "claims your device has been infected or hacked",
            patterns: [
                /\b(virus|malware|trojan|spyware)\b.{0,30}\b(detected|found|infected)\b/i,
                /\byour (computer|device|pc|phone|mac) (is|has been) (infected|locked|hacked|compromised)\b/i,
                /\b(call|contact) (microsoft|apple|windows|norton|mcafee|geek squad) (support|help ?desk|technician)\b/i,
                /\b(virus|malware|troyano|spyware)\b.{0,30}\b(detectad[oa]|encontrad[oa]|infectad[oa])\b/i,
                /\btu (computadora|ordenador|dispositivo|pc|teléfono|móvil|mac) (está|ha sido) (infectad[oa]|bloquead[oa]|hackead[oa]|comprometid[oa])\b/i,
                /\b(llama|contacta) (a )?(microsoft|apple|windows|norton|mcafee|soporte técnico)\b/i,
                /(वायरस|मैलवेयर|हैक|संक्रमित|डिवाइस.{0,20}(ब्लॉक|हैक)|माइक्रोसॉफ्ट|एप्पल|विंडोज|तकनीकी सहायता|रिमोट एक्सेस)/,
                /(病毒|恶意软件|木马|间谍软件|电脑.{0,10}(感染|中毒|被黑)|设备.{0,10}(感染|锁定)|微软|苹果|技术支持|远程协助)/
            ]
        },
        {
            id: "secrecy",
            title: "Asks you to keep it secret",
            detail: "scammers isolate victims from help",
            weight: 15,
            explain: "asks you to keep the request secret",
            patterns: [
                /\b(don'?t|do not) (tell|inform|share this with) (anyone|anybody|your (bank|family|friends|parents)|(mum|mom|dad|my (mum|mom|dad)|the bank))\b/i,
                /\bkeep (this|it) (secret|confidential|between us)\b/i,
                /\b(no|nunca) (se lo )?(digas|cuentes|compartas) (a nadie|con nadie|a tu (banco|familia|amigos|padres)|a (mamá|papá))\b/i,
                /\bmantén (esto|esto entre nosotros|en secreto|confidencial)\b/i,
                /(किसी को न बताएं|किसी को न बताएँ|राज़|गुप्त|गोपनीय|हमारे बीच|बैंक को न बताएं|परिवार को न बताएं)/,
                /(不要告诉|别告诉|保密|秘密|不要声张|别让.{0,6}知道|只有我们知道)/
            ]
        },
        {
            id: "generic-greeting",
            title: "Generic greeting",
            detail: "doesn't use your name",
            weight: 8,
            explain: "uses a generic greeting instead of your name",
            patterns: [
                /\bdear (customer|user|client|member|account ?holder|sir\s?(\/|or)\s?madam|valued|friend|beneficiary)\b/i,
                /\bvalued (customer|member|client)\b/i,
                /\bestimad[oa] (cliente|usuario|socio|miembro|titular|señor|señora|amigo|beneficiario)\b/i,
                /\bapreciad[oa] (cliente|miembro)\b/i,
                /(प्रिय ग्राहक|प्रिय उपयोगकर्ता|प्रिय सदस्य|आदरणीय ग्राहक|प्रिय लाभार्थी)/,
                /(尊敬的客户|亲爱的用户|尊敬的用户|亲爱的会员|尊敬的业主)/
            ]
        },
        {
            id: "call-to-action",
            title: "Pushes you to click or reply",
            detail: "instructions to tap a link or respond",
            weight: 10,
            explain: "pushes you to click a link or reply",
            patterns: [
                /\b(click|tap|press) (here|the link|this link|below|on the link|to (claim|verify|confirm|pay|update|reschedule))\b/i,
                /\b(follow|visit|use) (this|the) link\b/i,
                /\breply (yes|y|stop|with your)\b/i,
                /\b(download|open|enable) (the |this )?(attached|attachment|file|macros?|content|editing)\b/i,
                /\b(haz|haga|pulsa|pulse|toca|toque) (clic )?(aquí|en el enlace|este enlace|abajo|en el botón|para (reclamar|verificar|confirmar|pagar|actualizar))\b/i,
                /\b(sigue|visita|usa) (este|el) enlace\b/i,
                /\bresponde (sí|si|s|alto|con tu)\b/i,
                /\b(descarga|abre|habilita) (el |este )?(archivo|adjunto|macros|contenido|edición)\b/i,
                /(यहाँ क्लिक|लिंक पर क्लिक|नीचे क्लिक|टैप करें|दबाएँ|जवाब दें|हाँ लिखें|डाउनलोड करें|लिंक खोलें)/,
                /(点击这里|点击链接|点击下方|立即点击|轻触|回复是|下载附件|打开链接|扫码|扫描二维码|点击领取)/
            ]
        }
    ];

    /* ---------------------------------------------------------
       LINK DATA
    --------------------------------------------------------- */
    const BRANDS = {
        usps: ["usps.com"], fedex: ["fedex.com"], ups: ["ups.com"], dhl: ["dhl.com", "dhl.de"],
        amazon: ["amazon.com", "amazon.co.uk", "amazon.ca", "amazon.de", "amazon.in", "amzn.to", "amazon.jobs"],
        paypal: ["paypal.com", "paypal.me"], apple: ["apple.com", "icloud.com"],
        icloud: ["icloud.com", "apple.com"], microsoft: ["microsoft.com", "live.com", "office.com", "microsoftonline.com", "outlook.com"],
        office365: ["office.com", "microsoft.com"], outlook: ["outlook.com", "live.com", "microsoft.com"],
        netflix: ["netflix.com"], google: ["google.com", "goo.gl", "youtube.com"], gmail: ["google.com", "gmail.com"],
        facebook: ["facebook.com", "fb.com", "meta.com"], instagram: ["instagram.com"], whatsapp: ["whatsapp.com", "wa.me"],
        chase: ["chase.com"], wellsfargo: ["wellsfargo.com"], bankofamerica: ["bankofamerica.com", "bofa.com"], boa: ["bankofamerica.com"],
        citi: ["citi.com", "citibank.com"], capitalone: ["capitalone.com"], amex: ["americanexpress.com", "amex.com"],
        irs: ["irs.gov"], coinbase: ["coinbase.com"], binance: ["binance.com"], venmo: ["venmo.com"], zelle: ["zellepay.com"],
        walmart: ["walmart.com"], ebay: ["ebay.com"], dropbox: ["dropbox.com"], docusign: ["docusign.com", "docusign.net"],
        steam: ["steampowered.com", "steamcommunity.com"], att: ["att.com"], verizon: ["verizon.com"], tmobile: ["t-mobile.com"],
        bbva: ["bbva.com", "bbva.es", "bbva.mx"], santander: ["santander.com", "santander.es", "santander.com.mx"],
        caixabank: ["caixabank.com", "caixabank.es"], correos: ["correos.es"], mercadolibre: ["mercadolibre.com", "mercadolibre.com.mx", "mercadolibre.com.ar"],
        n26: ["n26.com"], revolut: ["revolut.com"], idealista: ["idealista.com"], wallapop: ["wallapop.com"],
        dhl: ["dhl.com", "dhl.de", "dhl.es"], seur: ["seur.com"], gls: ["gls-group.com", "gls-spain.es"]
    };

    const BRAND_NAMES = {
        usps: "USPS", fedex: "FedEx", ups: "UPS", dhl: "DHL", amazon: "Amazon", paypal: "PayPal", apple: "Apple", icloud: "iCloud",
        microsoft: "Microsoft", office365: "Office 365", outlook: "Outlook", netflix: "Netflix", google: "Google", gmail: "Gmail",
        facebook: "Facebook", instagram: "Instagram", whatsapp: "WhatsApp", chase: "Chase", wellsfargo: "Wells Fargo",
        bankofamerica: "Bank of America", boa: "Bank of America", citi: "Citi", capitalone: "Capital One", amex: "American Express",
        irs: "IRS", coinbase: "Coinbase", binance: "Binance", venmo: "Venmo", zelle: "Zelle", walmart: "Walmart", ebay: "eBay",
        dropbox: "Dropbox", docusign: "DocuSign", steam: "Steam", att: "AT&T", verizon: "Verizon", tmobile: "T-Mobile",
        bbva: "BBVA", santander: "Santander", caixabank: "CaixaBank", correos: "Correos",
        mercadolibre: "Mercado Libre", n26: "N26", revolut: "Revolut", idealista: "Idealista",
        wallapop: "Wallapop", seur: "SEUR", gls: "GLS"
    };

    const SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly", "cutt.ly",
        "shorturl.at", "tiny.cc", "rb.gy", "s.id", "t.ly", "bl.ink", "short.io", "v.gd", "lnkd.in", "qrco.de"];

    const RISKY_TLDS = ["xyz", "top", "click", "link", "ru", "cn", "tk", "ml", "ga", "cf", "gq", "online", "site", "shop",
        "live", "icu", "buzz", "vip", "cyou", "sbs", "lol", "rest", "fit", "support", "zip", "mov", "work", "quest", "monster", "cam"];

    const SUSPICIOUS_HOST_WORDS = /(login|log-in|signin|sign-in|verify|verification|secure|account|update|confirm|billing|wallet|unlock|redeliver|reschedule|track-?update|refund|support|verificar|verificacion|seguridad|cuenta|actualizar|confirmar|banca|pago|envio|paquete|reembolso|soporte)/i;

    const DANGEROUS_EXT = ["exe", "scr", "bat", "cmd", "com", "pif", "msi", "msp", "vbs", "vbe", "js", "jse", "wsf", "wsh",
        "ps1", "jar", "apk", "app", "dmg", "pkg", "hta", "lnk", "reg", "cpl", "iso", "img", "vhd", "xll", "sh", "run"];
    const MACRO_EXT = ["docm", "xlsm", "pptm", "dotm", "xltm", "potm", "xlam", "ppam"];
    const ARCHIVE_EXT = ["zip", "rar", "7z", "gz", "tar", "tgz", "cab"];
    const IMAGE_EXT = ["png", "jpg", "jpeg", "gif", "bmp", "webp", "tif", "tiff"];
    const TEXT_EXT = ["txt", "text", "md", "csv", "json", "xml", "log", "rtf", "vcf", "ics"];
    const HTML_EXT = ["html", "htm", "xhtml", "shtml", "svg"];

    /* ---------------------------------------------------------
       CATEGORIES (title + icon used on Results and History)
    --------------------------------------------------------- */
    const CATEGORIES = [
        { id: "prize", title: "Prize Claim Message", icon: "fa-gift", tactic: "prize and reward scams", test: /\b(congratulations|you('ve| have)? won|winner|prize|lottery|sweepstakes|reward|free gift|enhorabuena|felicidades|has ganado|premio|sorteo|loteria|lotería|recompensa|regalo)\b|(बधाई|इनाम|लॉटरी|पुरस्कार|जीता|恭喜|中奖|奖品|奖金|彩票)/i },
        { id: "techsupport", title: "Tech Support Alert", icon: "fa-laptop-medical", tactic: "tech-support scams", test: /\b(virus|malware|infected|hacked|tech support|technician|infectad[oa]|hackead[oa]|soporte técnico)\b|(वायरस|हैक|तकनीकी सहायता|病毒|技术支持|被黑|恶意软件)/i },
        { id: "government", title: "Government or Tax Notice", icon: "fa-landmark", tactic: "government impersonation scams", test: /\b(irs|tax|social security|government|department of|court|warrant|police|hacienda|impuestos|seguridad social|gobierno|ministerio|policía|juzgado)\b|(सरकार|कर विभाग|पुलिस|अदालत|जुर्माना|政府|税务|警察|法院|罚款)/i },
        { id: "family", title: "Family Emergency Message", icon: "fa-people-roof", tactic: "family impersonation scams", test: /\b(hi|hey|hello) (mum|mom|dad)\b|\bmy new (number|phone)\b|\b(hola|hey) (mamá|papá)\b|\bmi nuevo (número|teléfono)\b|(नया नंबर|माँ|मां|पापा|新号码|妈妈|爸爸|手机丢了)/i },
        { id: "investment", title: "Investment or Crypto Offer", icon: "fa-chart-line", tactic: "investment and crypto scams", test: /\b(invest(ment)?|crypto|bitcoin|trading|returns?|profit|inversión|cripto|rendimientos?|ganancias?)\b|(निवेश|क्रिप्टो|मुनाफा|投资|加密货币|比特币|收益)/i },
        { id: "job", title: "Job Offer Message", icon: "fa-briefcase", tactic: "fake job offer scams", test: /\b(job|position|hiring|recruit(er|ment)?|salary|work from home|interview|trabajo|puesto|empleo|contratación|reclutador|salario|entrevista)\b|(नौकरी|वेतन|साक्षात्कार|工作|招聘|薪资|面试)/i },
        { id: "delivery", title: "Package Delivery Message", icon: "fa-envelope", tactic: "phishing and delivery scams", test: /\b(package|parcel|delivery|deliver|courier|usps|fedex|dhl|redeliver|tracking number|paquete|envío|entrega|mensajero|correos|seur|seguimiento)\b|(पैकेज|डिलीवरी|कूरियर|ट्रैकिंग|包裹|快递|派送|物流|运单)/i },
        { id: "bank", title: "Bank Account Notification", icon: "fa-building-columns", tactic: "banking and phishing scams", test: /\b(bank|account|card|transaction|credit union|debit|statement|paypal|zelle|venmo|banco|cuenta|tarjeta|transacción|débito|extracto|bizum)\b|(बैंक|खाता|कार्ड|लेनदेन|银行|账户|银行卡|交易)/i },
        { id: "shopping", title: "Online Shopping Message", icon: "fa-cart-shopping", tactic: "online shopping scams", test: /\b(order|shipped|purchase|cart|amazon|ebay|walmart|refund|invoice|receipt|subscription|netflix|pedido|compra|carrito|reembolso|factura|recibo|suscripción)\b|(ऑर्डर|खरीद|कार्ट|रिफंड|订单|购物|退款|发票)/i },
        { id: "login", title: "Account Security Alert", icon: "fa-user-lock", tactic: "credential phishing", test: /\b(password|log ?in|sign ?in|security alert|verify|contraseña|iniciar sesión|acceso|alerta de seguridad|verificar)\b|(पासवर्ड|लॉग इन|सत्यापन|सुरक्षा चेतावनी|密码|登录|验证|安全警报)/i }
    ];

    /* ---------------------------------------------------------
       HELPERS
    --------------------------------------------------------- */
    function uid() {
        return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }

    function extOf(name) {
        const m = /\.([a-z0-9]+)$/i.exec(name || "");
        return m ? m[1].toLowerCase() : "";
    }

    function formatBytes(bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
        return (bytes / (1024 * 1024)).toFixed(1) + " MB";
    }

    function escapeHtml(str) {
        return String(str == null ? "" : str)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }

    function loadScript(src) {
        return new Promise(function (resolve, reject) {
            const existing = document.querySelector('script[data-src="' + src + '"]');
            if (existing) {
                if (existing.dataset.loaded) return resolve();
                existing.addEventListener("load", function () { resolve(); });
                existing.addEventListener("error", function () { reject(new Error("Failed to load " + src)); });
                return;
            }
            const s = document.createElement("script");
            s.src = src;
            s.async = true;
            s.dataset.src = src;
            s.onload = function () { s.dataset.loaded = "1"; resolve(); };
            s.onerror = function () { reject(new Error("Failed to load " + src)); };
            document.head.appendChild(s);
        });
    }

    function readAsArrayBuffer(file) {
        if (file.arrayBuffer) return file.arrayBuffer();
        return new Promise(function (resolve, reject) {
            const r = new FileReader();
            r.onload = function () { resolve(r.result); };
            r.onerror = function () { reject(r.error); };
            r.readAsArrayBuffer(file);
        });
    }

    function bytesToText(bytes) {
        try {
            return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
        } catch (e) {
            return "";
        }
    }

    // latin1 view of bytes: safe for searching ASCII markers inside binary files
    function bytesToLatin1(bytes, limit) {
        const n = Math.min(bytes.length, limit || bytes.length);
        let out = "";
        const CHUNK = 0x8000;
        for (let i = 0; i < n; i += CHUNK) {
            out += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CHUNK, n)));
        }
        return out;
    }

    function looksBinary(bytes) {
        const n = Math.min(bytes.length, 4096);
        if (!n) return false;
        let odd = 0;
        for (let i = 0; i < n; i++) {
            const b = bytes[i];
            if (b === 0) return true;
            if (b < 9 || (b > 13 && b < 32)) odd++;
        }
        return odd / n > 0.1;
    }

    function htmlToText(html, links) {
        const doc = new DOMParser().parseFromString(html, "text/html");
        doc.querySelectorAll("script, style, noscript, head").forEach(function (el) { el.remove(); });
        doc.querySelectorAll("a[href]").forEach(function (a) {
            links.push({ href: a.getAttribute("href") || "", text: (a.textContent || "").trim() });
        });
        doc.querySelectorAll("br, p, div, li, tr, h1, h2, h3, h4, h5, h6").forEach(function (el) {
            el.insertAdjacentText("afterend", "\n");
        });
        const text = (doc.body ? doc.body.textContent : doc.documentElement.textContent) || "";
        return {
            text: text.replace(/[ \t ]+/g, " ").replace(/\n\s*\n+/g, "\n\n").trim(),
            hasPasswordField: !!doc.querySelector('input[type="password"]'),
            hasForm: !!doc.querySelector("form"),
            formActions: Array.from(doc.querySelectorAll("form[action]")).map(function (f) { return f.getAttribute("action"); })
        };
    }

    /* ---------------------------------------------------------
       EMAIL (.eml) PARSING
    --------------------------------------------------------- */
    function decodeQuotedPrintable(str) {
        const s = str.replace(/=\r?\n/g, "");
        const bytes = [];
        for (let i = 0; i < s.length; i++) {
            if (s[i] === "=" && /^[0-9A-F]{2}$/i.test(s.substr(i + 1, 2))) {
                bytes.push(parseInt(s.substr(i + 1, 2), 16));
                i += 2;
            } else {
                bytes.push(s.charCodeAt(i) & 0xff);
            }
        }
        return bytesToText(new Uint8Array(bytes));
    }

    function decodeBase64(str) {
        try {
            const bin = atob(str.replace(/[^A-Za-z0-9+/=]/g, ""));
            const bytes = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
            return bytesToText(bytes);
        } catch (e) {
            return "";
        }
    }

    function decodeEncodedWords(str) {
        return String(str || "").replace(/=\?([^?]+)\?([BQ])\?([^?]*)\?=/gi, function (_, charset, enc, data) {
            if (enc.toUpperCase() === "B") return decodeBase64(data);
            return decodeQuotedPrintable(data.replace(/_/g, " "));
        });
    }

    function parseHeaders(block) {
        const headers = {};
        block.replace(/\r?\n[ \t]+/g, " ").split(/\r?\n/).forEach(function (line) {
            const i = line.indexOf(":");
            if (i > 0) {
                const key = line.slice(0, i).trim().toLowerCase();
                const val = line.slice(i + 1).trim();
                headers[key] = headers[key] ? headers[key] + "\n" + val : val;
            }
        });
        return headers;
    }

    function headerParam(value, name) {
        const re = new RegExp(name + '\\*?=\\s*"?([^";]+)"?', "i");
        const m = re.exec(value || "");
        return m ? decodeEncodedWords(m[1].trim()) : "";
    }

    function parseMimePart(raw, out, depth) {
        if (depth > 8) return;
        const split = raw.search(/\r?\n\r?\n/);
        const headerBlock = split >= 0 ? raw.slice(0, split) : raw;
        const body = split >= 0 ? raw.slice(split).replace(/^\r?\n\r?\n/, "") : "";
        const headers = parseHeaders(headerBlock);
        const ctype = (headers["content-type"] || "text/plain").toLowerCase();
        const encoding = (headers["content-transfer-encoding"] || "").toLowerCase();
        const disposition = headers["content-disposition"] || "";
        const filename = headerParam(disposition, "filename") || headerParam(headers["content-type"], "name");

        if (ctype.indexOf("multipart/") === 0) {
            const boundary = headerParam(headers["content-type"], "boundary");
            if (!boundary) return;
            const parts = body.split("--" + boundary);
            parts.slice(1).forEach(function (p) {
                if (p.indexOf("--") === 0) return; // closing boundary
                parseMimePart(p.replace(/^\r?\n/, ""), out, depth + 1);
            });
            return;
        }

        if (filename || /attachment/i.test(disposition)) {
            out.attachments.push(filename || "unnamed attachment");
            if (/\.html?$/i.test(filename) || ctype.indexOf("text/html") === 0) {
                let decoded = body;
                if (encoding === "base64") decoded = decodeBase64(body);
                else if (encoding === "quoted-printable") decoded = decodeQuotedPrintable(body);
                out.htmlAttachments.push(decoded);
            }
            return;
        }

        if (ctype.indexOf("message/rfc822") === 0) {
            parseMimePart(body, out, depth + 1);
            return;
        }

        let decoded = body;
        if (encoding === "base64") decoded = decodeBase64(body);
        else if (encoding === "quoted-printable") decoded = decodeQuotedPrintable(body);

        if (ctype.indexOf("text/html") === 0) out.html.push(decoded);
        else if (ctype.indexOf("text/") === 0) out.plain.push(decoded);
    }

    function parseEml(raw) {
        const split = raw.search(/\r?\n\r?\n/);
        const headers = parseHeaders(split >= 0 ? raw.slice(0, split) : raw);
        const out = { plain: [], html: [], attachments: [], htmlAttachments: [] };
        parseMimePart(raw, out, 0);
        return {
            headers: {
                from: decodeEncodedWords(headers["from"] || ""),
                replyTo: decodeEncodedWords(headers["reply-to"] || ""),
                returnPath: headers["return-path"] || "",
                subject: decodeEncodedWords(headers["subject"] || ""),
                auth: headers["authentication-results"] || headers["arc-authentication-results"] || "",
                spf: headers["received-spf"] || ""
            },
            plain: out.plain.join("\n\n"),
            html: out.html.join("\n"),
            attachments: out.attachments,
            htmlAttachments: out.htmlAttachments
        };
    }

    function emailDomain(addr) {
        const m = /@([a-z0-9.-]+\.[a-z]{2,})/i.exec(addr || "");
        return m ? m[1].toLowerCase() : "";
    }

    function displayName(addr) {
        const m = /^\s*"?([^"<]*?)"?\s*</.exec(addr || "");
        return m ? m[1].trim() : "";
    }

    /* ---------------------------------------------------------
       FILE EXTRACTION
       Returns { text, links:[{href,text}], kind, flags:[indicator], notes:[], email }
    --------------------------------------------------------- */
    async function extractFromFile(file, onProgress, lang) {
        const ext = extOf(file.name);
        const tr = function (english, spanish, hindi, chinese) {
            if (lang === "es") return spanish;
            if (lang === "hi") return hindi || english;
            if (lang === "zh") return chinese || english;
            return english;
        };
        const result = { text: "", links: [], kind: "file", flags: [], notes: [], email: null };
        const report = function (msg) { if (onProgress) onProgress(msg); };

        if (file.size > MAX_FILE_SIZE) {
            result.notes.push(tr(
                "This file is larger than " + formatBytes(MAX_FILE_SIZE) + ", so only its type was checked.",
                "Este archivo supera " + formatBytes(MAX_FILE_SIZE) + ", así que solo se comprobó su tipo.",
                "यह फ़ाइल " + formatBytes(MAX_FILE_SIZE) + " से बड़ी है, इसलिए केवल इसका प्रकार जाँचा गया।",
                "该文件大于 " + formatBytes(MAX_FILE_SIZE) + "，因此仅检查了文件类型。"
            ));
            fileTypeChecks(file, ext, new Uint8Array(0), result);
            return result;
        }

        report(tr("Reading " + file.name + "…", "Leyendo " + file.name + "…", "पढ़ा जा रहा है " + file.name + "…", "正在读取 " + file.name + "…"));
        const buffer = await readAsArrayBuffer(file);
        const bytes = new Uint8Array(buffer);

        fileTypeChecks(file, ext, bytes, result);

        try {
            if (IMAGE_EXT.indexOf(ext) >= 0 || /^image\//.test(file.type)) {
                result.kind = "image";
                report(tr("Reading text from image (this can take a few seconds)…", "Leyendo el texto de la imagen (puede tardar unos segundos)…", "छवि से टेक्स्ट पढ़ा जा रहा है (कुछ सेकंड लग सकते हैं)…", "正在从图片中读取文字（可能需要几秒钟）…"));
                result.text = await ocrImage(file, report, lang);
                if (!result.text.trim()) result.notes.push(tr("No readable text was found in this image.", "No se encontró texto legible en esta imagen.", "इस छवि में कोई पठनीय टेक्स्ट नहीं मिला।", "此图片中未找到可读文本。"));
            } else if (ext === "pdf" || file.type === "application/pdf") {
                result.kind = "pdf";
                pdfChecks(bytes, result);
                report(tr("Extracting text from PDF…", "Extrayendo el texto del PDF…", "PDF से टेक्स्ट निकाला जा रहा है…", "正在从 PDF 提取文本…"));
                const pdf = await extractPdf(buffer);
                result.text = pdf.text;
                result.links = result.links.concat(pdf.links);
            } else if (ext === "docx" || ext === "docm" || ext === "dotx") {
                result.kind = "document";
                report(tr("Extracting text from Word document…", "Extrayendo el texto del documento de Word…", "Word दस्तावेज़ से टेक्स्ट निकाला जा रहा है…", "正在从 Word 文档提取文本…"));
                const doc = await extractDocx(buffer);
                result.text = doc.text;
                result.links = result.links.concat(doc.links);
            } else if (ext === "eml" || file.type === "message/rfc822") {
                result.kind = "email";
                report(tr("Parsing email…", "Analizando el correo…", "ईमेल का विश्लेषण हो रहा है…", "正在解析电子邮件…"));
                emailExtract(bytesToText(bytes), result);
            } else if (HTML_EXT.indexOf(ext) >= 0 || file.type === "text/html") {
                result.kind = "html";
                const parsed = htmlToText(bytesToText(bytes), result.links);
                result.text = parsed.text;
                htmlFormChecks(parsed, result, tr("This web page", "Esta página web", "यह वेब पेज", "该网页"));
            } else if (ARCHIVE_EXT.indexOf(ext) >= 0) {
                result.kind = "archive";
                archiveChecks(bytes, result, lang);
            } else if (DANGEROUS_EXT.indexOf(ext) >= 0) {
                result.kind = "program";
                result.notes.push(tr("Program files aren't opened or run — only their type was checked.", "Los archivos de programa no se abren ni se ejecutan; solo se comprobó su tipo.", "प्रोग्राम फ़ाइलें नहीं खोली या चलाई जाती हैं — केवल उनका प्रकार जाँचा गया।", "程序文件不会被打开或运行——仅检查了文件类型。"));
            } else if (TEXT_EXT.indexOf(ext) >= 0 || /^text\//.test(file.type) || !looksBinary(bytes)) {
                result.kind = "text";
                const raw = bytesToText(bytes);
                // A text file might actually be a saved email
                if (/^(received|from|return-path|delivered-to|message-id|mime-version):/im.test(raw.slice(0, 2000)) && /\r?\n\r?\n/.test(raw)) {
                    result.kind = "email";
                    emailExtract(raw, result);
                } else if (ext === "rtf") {
                    result.text = raw.replace(/\\par[d]?/g, "\n").replace(/\{\\[^{}]*\}|\\[a-z]+-?\d* ?|[{}]/gi, "").trim();
                } else {
                    result.text = raw;
                }
            } else {
                result.notes.push(tr("This file type can't be read as text, so only its type and structure were checked.", "Este tipo de archivo no se puede leer como texto; solo se comprobaron su tipo y estructura.", "इस फ़ाइल प्रकार को टेक्स्ट के रूप में नहीं पढ़ा जा सकता, इसलिए केवल इसका प्रकार और संरचना जाँची गई।", "此文件类型无法作为文本读取，因此仅检查了类型和结构。"));
            }
        } catch (err) {
            console.warn("[ScamShield] extraction failed:", err);
            result.notes.push(tr(
                "We couldn't read the contents of this file (" + (err && err.message ? err.message : "unknown error") + "). Only its type was checked.",
                "No pudimos leer el contenido de este archivo (" + (err && err.message ? err.message : "error desconocido") + "). Solo se comprobó su tipo.",
                "हम इस फ़ाइल की सामग्री नहीं पढ़ सके (" + (err && err.message ? err.message : "अज्ञात त्रुटि") + "). केवल इसका प्रकार जाँचा गया।",
                "我们无法读取该文件的内容（" + (err && err.message ? err.message : "未知错误") + "）。仅检查了文件类型。"
            ));
        }

        return result;
    }

    function emailExtract(raw, result) {
        const email = parseEml(raw);
        result.email = email.headers;
        let text = email.plain;
        if (email.html) {
            const parsed = htmlToText(email.html, result.links);
            if (!text.trim()) text = parsed.text;
            htmlFormChecks(parsed, result, "This email");
        }
        email.htmlAttachments.forEach(function (h) {
            const parsed = htmlToText(h, result.links);
            htmlFormChecks(parsed, result, "An attached web page");
        });
        result.text = (email.headers.subject ? email.headers.subject + "\n\n" : "") + text;
        result.attachments = email.attachments;

        // Sender checks
        const from = email.headers.from;
        const fromDomain = emailDomain(from);
        const name = displayName(from).toLowerCase().replace(/[^a-z0-9]/g, "");
        if (fromDomain && name) {
            Object.keys(BRANDS).forEach(function (brand) {
                if (brand.length >= 4 && name.indexOf(brand) >= 0 && !hostMatches(fromDomain, BRANDS[brand]) && !result.flags.some(function (f) { return f.id === "sender-mismatch"; })) {
                    result.flags.push(indicator("sender-mismatch", "Sender name doesn't match address",
                        "claims to be " + displayName(from) + " but was sent from " + fromDomain, 28,
                        "comes from an address that doesn't belong to the company it claims to be",
                        { name: displayName(from), domain: fromDomain }, fromDomain));
                }
            });
        }
        const replyDomain = emailDomain(email.headers.replyTo);
        if (fromDomain && replyDomain && replyDomain !== fromDomain) {
            result.flags.push(indicator("reply-to", "Replies go somewhere else",
                "reply-to address is " + replyDomain + ", not " + fromDomain, 15,
                "sends your replies to a different address than the sender",
                { reply: replyDomain, from: fromDomain }, replyDomain));
        }
        const auth = (email.headers.auth + " " + email.headers.spf).toLowerCase();
        if (/\b(spf=(fail|softfail)|dkim=fail|dmarc=fail)\b|^\s*(fail|softfail)\b/.test(auth)) {
            result.flags.push(indicator("auth-fail", "Failed sender verification",
                "the email didn't pass SPF/DKIM/DMARC checks", 25,
                "failed the email system's sender verification checks", null, "SPF/DKIM/DMARC fail"));
        }

        const badAttachments = email.attachments.filter(function (a) {
            const e = extOf(a);
            return DANGEROUS_EXT.indexOf(e) >= 0 || MACRO_EXT.indexOf(e) >= 0 || /\.(pdf|docx?|xlsx?|jpe?g|png|txt)\.[a-z0-9]{2,4}$/i.test(a);
        });
        if (badAttachments.length) {
            result.flags.push(indicator("dangerous-attachment", "Dangerous attachment",
                badAttachments.slice(0, 3).join(", "), 40,
                "includes an attachment that could install malware",
                { list: badAttachments.slice(0, 3).join(", ") }, badAttachments.slice(0, 3).join(", ")));
        } else if (email.htmlAttachments.length) {
            result.flags.push(indicator("html-attachment", "Web page sent as attachment",
                "a common trick to show fake login pages", 18,
                "includes a web page attachment, a common way to show fake login forms", null, "HTML attachment"));
        }
    }

    function htmlFormChecks(parsed, result, label) {
        if (parsed.hasPasswordField) {
            result.flags.push(indicator("password-form", "Asks for a password in a form",
                label.toLowerCase() + " contains a login form", 30,
                "contains a form that collects passwords", { label: label.toLowerCase() }, label));
        } else if (parsed.hasForm && parsed.formActions.some(function (a) { return /^https?:/i.test(a || ""); })) {
            result.flags.push(indicator("external-form", "Form sends data to another site",
                "information you type is sent elsewhere", 18,
                "contains a form that sends your information to an outside website", { label: label.toLowerCase() }, parsed.formActions[0] || label));
        }
    }

    function fileTypeChecks(file, ext, bytes, result) {
        const name = file.name || "";
        if (DANGEROUS_EXT.indexOf(ext) >= 0) {
            result.flags.push(indicator("dangerous-file", "Dangerous file type",
                "." + ext + " files can install software or run code", 55,
                "is a type of file that can run programs on your device", { ext: ext }, "." + ext));
        }
        if (/\.(pdf|docx?|xlsx?|pptx?|jpe?g|png|gif|txt|mp3|mp4|zip)\s*\.[a-z0-9]{2,4}$/i.test(name) && DANGEROUS_EXT.indexOf(ext) >= 0) {
            result.flags.push(indicator("double-extension", "Disguised file name",
                "\"" + name + "\" pretends to be a different file type", 35,
                "uses a disguised file name to hide what it really is", { name: name }, name));
        }
        if (bytes.length > 2 && bytes[0] === 0x4d && bytes[1] === 0x5a && ["exe", "dll", "scr", "com", "msi", "sys", "cpl"].indexOf(ext) < 0) {
            result.flags.push(indicator("hidden-program", "Hidden program inside",
                "the file is really a Windows program", 55,
                "is really a Windows program disguised as another file type", null, "MZ program header"));
        }
        if (MACRO_EXT.indexOf(ext) >= 0) {
            result.flags.push(indicator("macros", "Macro-enabled document",
                "macros can run hidden code when enabled", 35,
                "is a macro-enabled document that can run hidden code", { ext: ext }, "." + ext));
        } else if (bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && ["docx", "xlsx", "pptx"].indexOf(ext) >= 0) {
            if (bytesToLatin1(bytes, 4 * 1024 * 1024).indexOf("vbaProject.bin") >= 0) {
                result.flags.push(indicator("macros", "Contains hidden macros",
                    "this document includes macro code", 35,
                    "contains hidden macro code", null, "vbaProject.bin"));
            }
        }
    }

    function pdfChecks(bytes, result) {
        const raw = bytesToLatin1(bytes, 8 * 1024 * 1024);
        const found = [];
        if (/\/JavaScript|\/JS\s*[(<\[]/.test(raw)) found.push("JavaScript");
        if (/\/Launch\b/.test(raw)) found.push("launch actions");
        if (/\/EmbeddedFile\b/.test(raw)) found.push("embedded files");
        if (/\/SubmitForm\b/.test(raw)) found.push("form submission");
        if (found.length) {
            result.flags.push(indicator("pdf-actions", "Hidden actions inside PDF",
                "contains " + found.join(", "), 30,
                "contains hidden actions (" + found.join(", ") + ") that can run when opened",
                { list: found.join(", ") }, found.join(", ")));
        }
    }

    function archiveChecks(bytes, result, lang) {
        const t = function (en, es, hi, zh) {
            if (lang === "es") return es;
            if (lang === "hi") return hi;
            if (lang === "zh") return zh;
            return en;
        };
        // Zip central directories store file names as plain text, so we can list them without unzipping.
        const names = zipFileNames(bytes);
        const risky = DANGEROUS_EXT.concat(MACRO_EXT);
        const list = names.filter(function (n) { return risky.indexOf(extOf(n)) >= 0; });
        if (names.length) {
            result.text = t("Files inside this archive:\n", "Archivos dentro de este comprimido:\n", "इस आर्काइव के अंदर की फ़ाइलें:\n", "此压缩包内的文件：\n") +
                names.slice(0, 40).join("\n") +
                (names.length > 40 ? t("\n…and " + (names.length - 40) + " more", "\n…y " + (names.length - 40) + " más", "\n…और " + (names.length - 40) + " और", "\n……以及另外 " + (names.length - 40) + " 个") : "");
        }
        if (list.length) {
            result.flags.push(indicator("archive-program", "Archive contains a program",
                list.slice(0, 3).join(", "), 45,
                "is an archive that contains program files",
                { list: list.slice(0, 3).join(", ") }, list.slice(0, 3).join(", ")));
        } else {
            result.notes.push(names.length
                ? t(
                    "No program files were found among the " + names.length + " file(s) inside. Files inside an archive aren't opened, so scan them separately after extracting if unsure.",
                    "No se encontraron programas entre los " + names.length + " archivos internos. El contenido de un comprimido no se abre; si dudas, extráelo y escanéalo por separado.",
                    "अंदर की " + names.length + " फ़ाइलों में कोई प्रोग्राम फ़ाइल नहीं मिली। आर्काइव के अंदर की फ़ाइलें नहीं खोली जातीं, इसलिए संदेह हो तो निकालकर अलग से स्कैन करें।",
                    "在内部的 " + names.length + " 个文件中未发现程序文件。压缩包内的文件不会被打开，如有疑问请解压后单独扫描。"
                )
                : t(
                    "This archive's contents couldn't be listed (it may be a non-zip or password-protected archive), so only its type was checked.",
                    "No se pudo listar el contenido de este comprimido (puede no ser ZIP o estar protegido con contraseña), así que solo se comprobó su tipo.",
                    "इस आर्काइव की सामग्री सूचीबद्ध नहीं हो सकी (यह ZIP नहीं हो सकता या पासवर्ड से सुरक्षित हो सकता है), इसलिए केवल इसका प्रकार जाँचा गया।",
                    "无法列出此压缩包的内容（可能不是 ZIP 或受密码保护），因此仅检查了文件类型。"
                ));
        }
    }

    // Reads the file names listed in a .zip without unzipping it
    function zipFileNames(bytes) {
        const names = {};
        const n = bytes.length;
        for (let i = 0; i + 46 < n; i++) {
            if (bytes[i] !== 0x50 || bytes[i + 1] !== 0x4b) continue;
            let len = 0, start = 0;
            if (bytes[i + 2] === 0x01 && bytes[i + 3] === 0x02) { // central directory entry
                len = bytes[i + 28] | (bytes[i + 29] << 8);
                start = i + 46;
            } else if (bytes[i + 2] === 0x03 && bytes[i + 3] === 0x04) { // local file header
                len = bytes[i + 26] | (bytes[i + 27] << 8);
                start = i + 30;
            } else {
                continue;
            }
            if (len > 0 && len < 512 && start + len <= n) {
                const name = bytesToText(bytes.subarray(start, start + len));
                if (!/\/$/.test(name) && !/[\u0000-\u001f]/.test(name)) names[name] = true;
            }
            if (Object.keys(names).length >= 500) break;
        }
        return Object.keys(names);
    }

    /* ---------------------------------------------------------
       LIBRARY-BACKED EXTRACTORS (loaded only when needed)
    --------------------------------------------------------- */
    async function ocrImage(file, report, lang) {
        await loadScript(LIBS.tesseract);
        const languages = lang === "es" ? "eng+spa" : lang === "hi" ? "eng+hin" : lang === "zh" ? "eng+chi_sim" : "eng";
        const worker = await window.Tesseract.createWorker(languages, 1, {
            logger: function (m) {
                if (m.status === "recognizing text" && report) {
                    const prefix = lang === "es" ? "Leyendo el texto de la imagen… "
                        : lang === "hi" ? "छवि से टेक्स्ट पढ़ा जा रहा है… "
                            : lang === "zh" ? "正在从图片中读取文字… "
                                : "Reading text from image… ";
                    report(prefix + Math.round((m.progress || 0) * 100) + "%");
                }
            }
        });
        try {
            const res = await worker.recognize(file);
            return (res && res.data && res.data.text) || "";
        } finally {
            worker.terminate();
        }
    }

    async function extractPdf(buffer) {
        await loadScript(LIBS.pdfjs);
        const lib = window.pdfjsLib;
        lib.GlobalWorkerOptions.workerSrc = LIBS.pdfWorker;
        const pdf = await lib.getDocument({ data: new Uint8Array(buffer), isEvalSupported: false }).promise;
        const pages = Math.min(pdf.numPages, 30);
        const parts = [];
        const links = [];
        for (let i = 1; i <= pages; i++) {
            const page = await pdf.getPage(i);
            const content = await page.getTextContent();
            parts.push(content.items.map(function (it) { return it.str; }).join(" "));
            try {
                const annots = await page.getAnnotations();
                annots.forEach(function (a) {
                    if (a.url) links.push({ href: a.url, text: "" });
                });
            } catch (e) { /* ignore */ }
        }
        return { text: parts.join("\n\n"), links: links };
    }

    async function extractDocx(buffer) {
        await loadScript(LIBS.mammoth);
        const res = await window.mammoth.convertToHtml({ arrayBuffer: buffer });
        const links = [];
        const parsed = htmlToText(res.value || "", links);
        return { text: parsed.text, links: links };
    }

    /* ---------------------------------------------------------
       LINK ANALYSIS
    --------------------------------------------------------- */
    const URL_RE = /(?:https?:\/\/|www\.)[^\s<>"'`)\]}]+|\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:com|net|org|info|xyz|top|click|link|co|io|ru|cn|tk|ml|ga|cf|gq|online|site|shop|live|app|me|us|biz|cc|vip|icu|buzz|support|help|club|work|rest|fit|cyou|sbs|lol|mobi|ly|gl|gd|at|to|zip|mov|quest|monster|cam|gov|edu|uk|ca|de|in|es|mx|ar|cl|pe|uy|ec|bo|ve|py|do|gt|sv|hn|ni|cr|pa|pr|eu|fr|it|pt|nl|be|ch|se|no|dk|fi|pl|ro|ie|nz|au|jp|kr|br|za)(?:\/[^\s<>"'`)\]}]*)?/gi;

    function findUrls(text) {
        const out = [];
        let m;
        URL_RE.lastIndex = 0;
        while ((m = URL_RE.exec(text))) {
            const prev = text[m.index - 1];
            if (prev === "@" || /[a-z0-9]/i.test(prev || "")) continue; // email address or part of a word
            out.push(m[0].replace(/[.,;:!?]+$/, ""));
        }
        return out;
    }

    function parseHost(url) {
        let u = url.trim();
        if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = "http://" + u;
        try {
            const parsed = new URL(u);
            return { host: parsed.hostname.toLowerCase(), protocol: parsed.protocol, raw: url, hasAt: /^[a-z]+:\/\/[^/]*@/i.test(u) };
        } catch (e) {
            return null;
        }
    }

    function hostMatches(host, domains) {
        return domains.some(function (d) { return host === d || host.slice(-(d.length + 1)) === "." + d; });
    }

    function analyzeLinks(urls, anchorLinks) {
        const flags = [];
        const seen = {};
        const add = function (f) {
            if (!seen[f.id]) { seen[f.id] = true; flags.push(f); }
        };

        const hosts = [];
        urls.forEach(function (url) {
            if (/^(mailto|tel|sms|#|javascript:)/i.test(url)) {
                if (/^javascript:/i.test(url)) add(indicator("js-link", "Link runs hidden code", "a javascript: link", 25, "contains a link that runs hidden code", { scheme: "javascript:" }, "javascript:"));
                return;
            }
            const info = parseHost(url);
            if (info && info.host) hosts.push(info);
        });

        if (!hosts.length) return { flags: flags, hosts: [] };

        add(indicator("link", "Unverified link", "may lead to a fake website", 12, "includes a link you can't verify", null, hosts[0].host));

        hosts.forEach(function (h) {
            const host = h.host;
            const tokens = host.split(/[.-]/);
            const tld = tokens[tokens.length - 1];

            // brand name in the address, but not the brand's real website
            Object.keys(BRANDS).forEach(function (brand) {
                const inHost = tokens.indexOf(brand) >= 0 || (brand.length >= 5 && host.replace(/[.-]/g, "").indexOf(brand) >= 0);
                if (inHost && !hostMatches(host, BRANDS[brand])) {
                    const brandName = BRAND_NAMES[brand] || brand;
                    add(indicator("lookalike", "Lookalike website address",
                        host + " is not the official " + brandName + " website", 30,
                        "links to a website that imitates " + brandName,
                        { host: host, brand: brandName }, host));
                }
            });

            if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || /^\[[0-9a-f:]+\]$/.test(host)) {
                add(indicator("ip-link", "Link uses a raw IP address", host, 25, "links to a bare IP address instead of a named website", { host: host }, host));
            }
            if (host.indexOf("xn--") >= 0) {
                add(indicator("punycode", "Disguised characters in link", "uses look-alike letters", 25, "uses look-alike characters to disguise a web address", { host: host }, host));
            }
            if (hostMatches(host, SHORTENERS)) {
                add(indicator("shortener", "Shortened link", "hides the real destination", 16, "uses a shortened link that hides where it really goes", { host: host }, host));
            }
            if (RISKY_TLDS.indexOf(tld) >= 0) {
                add(indicator("risky-tld", "Unusual domain ending", "." + tld + " sites are often used by scammers", 15, "links to a domain ending (." + tld + ") that scammers often use", { tld: tld }, evidenceSnippet(h.raw)));
            }
            if (h.hasAt) {
                add(indicator("at-link", "Misleading link format", "an @ sign hides the real address", 22, "uses a misleading link format", { host: host }, evidenceSnippet(h.raw)));
            }
            if (SUSPICIOUS_HOST_WORDS.test(host) && !Object.keys(BRANDS).some(function (b) { return hostMatches(host, BRANDS[b]); })) {
                add(indicator("host-words", "Suspicious words in web address", "e.g. \"verify\", \"secure\", \"login\"", 10, "has a web address stuffed with words like \"secure\" or \"verify\"", { host: host }, host));
            }
            if ((host.match(/-/g) || []).length >= 3 || host.split(".").length > 5) {
                add(indicator("long-host", "Overly complicated web address", host, 8, "uses an unusually complicated web address", { host: host }, host));
            }
            if (h.protocol === "http:" && /^http:/i.test(h.raw)) {
                add(indicator("no-https", "Insecure link", "doesn't use HTTPS", 6, "uses an insecure (non-HTTPS) link", null, evidenceSnippet(h.raw)));
            }
        });

        // Visible link text shows one site but the link goes to another
        (anchorLinks || []).forEach(function (a) {
            const shown = findUrls(a.text || "")[0];
            if (!shown || !a.href) return;
            const s = parseHost(shown);
            const t = parseHost(a.href);
            if (s && t && s.host && t.host && s.host.replace(/^www\./, "") !== t.host.replace(/^www\./, "")) {
                add(indicator("mismatch-link", "Link text doesn't match destination",
                    "shows " + s.host + " but opens " + t.host, 28,
                    "shows one web address but actually links to another",
                    { shown: s.host, target: t.host }, s.host + " → " + t.host));
            }
        });

        return { flags: flags, hosts: hosts.map(function (h) { return h.host; }) };
    }

    /* ---------------------------------------------------------
       CORE ANALYSIS
    --------------------------------------------------------- */
    function indicator(id, title, detail, weight, explain, vars, evidence) {
        return {
            id: id,
            title: title,
            detail: detail,
            weight: weight,
            explain: explain,
            severity: weight >= 25 ? "high" : weight >= 12 ? "medium" : "low",
            vars: vars || null,
            evidence: evidence || ""
        };
    }

    function localizeIndicator(item, lang) {
        const copy = Object.assign({}, item);
        const text = (FLAG_LOCALES[lang] && FLAG_LOCALES[lang][copy.id]) ||
            (RULE_LOCALES[lang] && RULE_LOCALES[lang][copy.id]);
        if (text) {
            copy.title = text.title;
            copy.detail = fillTemplate(text.detail, copy.vars);
            copy.explain = fillTemplate(text.explain, copy.vars);
            copy.nextStep = text.next;
        } else {
            copy.nextStep = RULE_NEXT_EN[copy.id] || FLAG_NEXT_EN[copy.id] || "";
        }
        copy.severity = copy.weight >= 25 ? "high" : copy.weight >= 12 ? "medium" : "low";
        return copy;
    }

    function localizeCategory(category, lang, meta) {
        const out = { id: category.id, title: category.title, icon: category.icon, tactic: category.tactic };
        const translated = CATEGORY_LOCALES[lang] && CATEGORY_LOCALES[lang][category.id];
        if (translated) {
            out.title = translated.title;
            out.tactic = translated.tactic;
        }
        const kinds = KIND_LOCALES[lang];
        if (category.id === "file" && meta && kinds && kinds[meta.kind]) out.title = kinds[meta.kind];
        return out;
    }

    function riskLevelFor(score) {
        return score >= HIGH_RISK_THRESHOLD ? "high" : score >= MEDIUM_RISK_THRESHOLD ? "medium" : "low";
    }

    function evidenceSnippet(value) {
        const text = String(value || "").replace(/\s+/g, " ").trim();
        return text.length > 120 ? text.slice(0, 117) + "…" : text;
    }

    function firstRuleMatch(text, patterns) {
        for (let i = 0; i < patterns.length; i++) {
            const match = patterns[i].exec(text);
            if (match && match[0]) return evidenceSnippet(match[0]);
        }
        return "";
    }

    function giftCardEvidence(text) {
        const giftCard = /\b(?:gift[\s-]*(?:cards?|crad|caard)|google\s*play\s*cards?|(?:itunes|steam|apple)\s+cards?|gift\s+certificates?|tarjetas? (?:de )?regalo|tarjetas? (?:de )?google play|tarjetas? (?:de )?itunes|tarjetas? (?:de )?steam)\b|(?:गिफ़्ट कार्ड|गिफ्ट कार्ड|礼品卡)/i;
        const pressure = /\b(?:urgent(?:ly)?|immediately|act now|asap|secret|confidential|don't tell|do not tell|urgente|inmediatamente|ahora mismo|secreto|confidencial|no se lo digas|no lo cuentes)\b|(?:तुरंत|तत्काल|जल्दी|गुप्त|गोपनीय|किसी को न बताएं|紧急|立即|马上|保密|不要告诉)/i;
        const untraceablePayment = /\b(?:wire|bitcoin|btc|crypto(?:currency)?|wallet|transferencia|criptomoneda)\b|(?:बिटकॉइन|क्रिप्टो|वॉलेट|比特币|加密货币|钱包)/i;
        const directPayment = /\b(?:pay\s+(?:with|using|via|in)|paga\s+(?:con|usando|mediante))\b|(?:भुगतान करें|付款|支付)/i;
        const pricedRequest = /\$\s?\d.{0,35}\b(?:ask(?:ed|d|s|ing)?|request(?:ed|ing)?|pide|solicita)\b|\b(?:ask(?:ed|d|s|ing)?|request(?:ed|ing)?|pide|solicita)\b.{0,35}\$\s?\d|(?:₹|¥)\s?\d.{0,35}(?:माँग|अनुरोध|要求|索要)|(?:माँग|अनुरोध|要求|索要).{0,35}(?:₹|¥)\s?\d/i;
        const pressuredAction = /\b(?:please|you must|you need to|you have to|i need you to|por favor|debes|tienes que|necesito que)\b.{0,35}\b(?:buy|purchase|send|pay|compra|envía|paga)\b|(?:कृपया|आपको|मुझे चाहिए).{0,35}(?:खरीद|भेज|भुगतान)|(?:请|你必须|我需要).{0,35}(?:购买|发送|付款)/i;
        const sentences = text.split(/(?:[.!?]+\s+)|(?:\r?\n+)/);
        for (let i = 0; i < sentences.length; i++) {
            const sentence = sentences[i];
            if (giftCard.test(sentence) && (
                pressure.test(sentence) ||
                untraceablePayment.test(sentence) ||
                directPayment.test(sentence) ||
                pricedRequest.test(sentence) ||
                pressuredAction.test(sentence)
            )) {
                return evidenceSnippet(sentence);
            }
        }
        return "";
    }

    function hasGiftCardPressure(text) {
        return !!giftCardEvidence(text);
    }

    function scoreIndicators(indicators) {
        const total = indicators.reduce(function (sum, item) { return sum + item.weight; }, 0);
        let score = Math.round(100 * (1 - Math.exp(-total / 45)));
        score = Math.max(score, indicators.length ? 8 : 3);
        score = Math.min(score, 99);
        if (indicators.some(function (item) { return item.weight >= 45; })) score = Math.max(score, 85);
        return score;
    }

    function predictTextModel(text) {
        const model = window.ScamShieldTextModel;
        if (!model) return null;
        if (
            !model.weights ||
            typeof model.weights !== "object" ||
            !Number.isFinite(model.intercept) ||
            !Number.isFinite(model.threshold) ||
            model.threshold <= 0 ||
            model.threshold >= 1
        ) {
            throw new Error("The local text model is malformed. Regenerate scamshield-text-model.js.");
        }

        const normalized = text.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
        const words = normalized.match(/[a-z0-9]{2,}/g) || [];
        const seen = Object.create(null);
        let logit = model.intercept;
        function addFeature(feature) {
            if (seen[feature]) return;
            seen[feature] = true;
            if (Object.prototype.hasOwnProperty.call(model.weights, feature)) {
                const weight = model.weights[feature];
                if (!Number.isFinite(weight)) {
                    throw new Error("The local text model contains an invalid feature weight. Regenerate scamshield-text-model.js.");
                }
                logit += weight;
            }
        }
        words.forEach(function (word, index) {
            addFeature(word);
            if (index > 0) addFeature(words[index - 1] + " " + word);
        });

        const boundedLogit = Math.max(-30, Math.min(30, logit));
        const score = 1 / (1 + Math.exp(-boundedLogit));
        return { score: score, triggered: score >= model.threshold };
    }

    function detectCategory(text, meta) {
        if (meta && meta.kind === "qr") {
            return { id: "qr", title: "QR Code", icon: "fa-qrcode", tactic: "QR-code phishing (quishing)" };
        }
        for (let i = 0; i < CATEGORIES.length; i++) {
            if (CATEGORIES[i].test.test(text)) return CATEGORIES[i];
        }
        if (meta && meta.kind === "email") return { id: "email", title: "Email Message", icon: "fa-envelope-open-text", tactic: "phishing scams" };
        const KIND = {
            archive: ["Archive File", "fa-file-zipper"], program: ["Program File", "fa-file-circle-exclamation"],
            pdf: ["PDF Document", "fa-file-pdf"], document: ["Word Document", "fa-file-word"], image: ["Screenshot / Image", "fa-file-image"],
            html: ["Web Page File", "fa-file-code"], text: ["Text Document", "fa-file-lines"]
        };
        if (meta && meta.fileName) {
            const k = KIND[meta.kind] || ["Uploaded File", "fa-file-shield"];
            return { id: "file", title: k[0], icon: k[1], tactic: "malware and phishing scams" };
        }
        return { id: "message", title: "Text Message", icon: "fa-comment-dots", tactic: "phishing scams" };
    }

    function buildExplanation(level, indicators, category, meta, hasText, lang) {
        const copy = EXPLANATIONS[lang] || EXPLANATIONS.en;
        const subject = meta && meta.kind === "qr"
            ? copy.qr
            : meta && meta.kind === "email"
                ? copy.email
                : meta && meta.fileName
                    ? copy.file
                    : copy.message;
        const top = indicators.slice().sort(function (a, b) { return b.weight - a.weight; }).slice(0, 4).map(function (i) { return i.explain; });

        if (!indicators.length) {
            if (!hasText) return copy.noText;
            return lang === "es"
                ? subject + " no muestra señales habituales de estafa: no te presiona, no pide dinero ni datos personales y no incluye enlaces de riesgo. Aun así, si no lo esperabas, confírmalo con el remitente por un canal que ya conozcas."
                : lang === "hi"
                    ? subject + " में घोटाले के सामान्य चेतावनी संकेत नहीं दिखे — यह दबाव नहीं डालता, पैसे या व्यक्तिगत जानकारी नहीं माँगता और जोखिम भरे लिंक शामिल नहीं करता। फिर भी अप्रत्याशित हो तो भेजने वाले से भरोसेमंद माध्यम से पुष्टि करें।"
                    : lang === "zh"
                        ? subject + "未显示常见的诈骗警示信号——没有施压、没有索要金钱或个人信息，也没有风险链接。不过，如果不是您预期的，请通过您信任的渠道向发件人确认。"
                        : subject + " doesn't show common scam warning signs — it doesn't pressure you, ask for money or personal details, or include risky links. Still, if it was unexpected, confirm with the sender through a channel you already trust.";
        }
        const phrases = joinedPhrases(top, lang);
        return fillTemplate(copy[level] || copy.low, {
            subject: subject,
            phrases: phrases,
            tactic: category.tactic
        });
    }

    function buildActions(level, indicators, meta, lang) {
        const actionsCopy = ACTION_LOCALES[lang];
        const text = function (key, english) { return (actionsCopy && actionsCopy[key]) || english; };
        const ids = {};
        indicators.forEach(function (i) { ids[i.id] = true; });
        const actions = [];
        const isFile = !!(meta && meta.fileName);
        const isQr = !!(meta && meta.kind === "qr");
        const fileDanger = ids["dangerous-file"] || ids["hidden-program"] || ids["macros"] || ids["archive-program"] || ids["pdf-actions"] || ids["dangerous-attachment"] || ids["double-extension"];

        if (isQr) {
            if (ids["qr-dangerous-scheme"]) actions.push(text("qrDangerous", "Don't open this destination. The QR code uses a dangerous link type."));
            else if (meta.qrType === "url") actions.push(text("qrLink", "Don't open this destination from the QR code. Type the official address yourself."));
            else if (meta.qrType === "wifi") actions.push(text("qrWifi", "Check the Wi-Fi network name before connecting. We don't keep the password in history."));
            else actions.push(text("qrText", "Treat the QR code content as an unverified message."));
        }
        if (fileDanger) actions.push(text("fileDanger", "Do not open, run, or enable content in this file. Delete it if you weren't expecting it."));
        if (ids["link"] || ids["lookalike"] || ids["shortener"] || ids["mismatch-link"]) {
            actions.push(ids["payment"] || ids["untraceable"]
                ? text("linkPayment", "Do not click the link or provide any payment information.")
                : text("link", "Do not click the link — type the company's web address yourself instead."));
        } else if (ids["payment"] || ids["untraceable"]) {
            actions.push(text("payment", "Do not send money, gift cards, or card details."));
        }
        if (ids["credentials"] || ids["password-form"]) actions.push(text("credentials", "Never share passwords, one-time codes, or personal details in response to a message."));
        if (ids["impersonation-family"]) actions.push(text("family", "Call your family member on the number you already have for them."));
        if (ids["techsupport"]) actions.push(text("techsupport", "Don't call the number or let anyone remotely access your device."));

        if (level !== "low" || indicators.length) {
            actions.push(text("verify", "Verify the message through the company's official website or phone number."));
        }
        if (level === "high") {
            actions.push(isFile
                ? text("reportFile", "Report it to your email provider or IT team, and at reportfraud.ftc.gov.")
                : text("reportMessage", "Report the message if possible (e.g., forward scam texts to 7726, or report at reportfraud.ftc.gov)."));
        }
        if (!actions.length) {
            actions.push(text("none1", "No action needed — but stay alert for unexpected requests for money or information."));
            actions.push(text("none2", "If anything feels off, contact the sender through a channel you already trust."));
        }
        return actions.filter(function (value, index, list) { return list.indexOf(value) === index; }).slice(0, 4);
    }

    function analyze(input) {
        const text = (input.text || "").slice(0, 200000);
        const meta = input.meta || {};
        const lang = normalizeLang(input.lang || detectLanguage(text));
        const indicators = [];

        TEXT_RULES.forEach(function (rule) {
            const evidence = firstRuleMatch(text, rule.patterns);
            if (evidence) {
                indicators.push(indicator(rule.id, rule.title, rule.detail, rule.weight, rule.explain, null, evidence));
            }
        });
        const giftCard = giftCardEvidence(text);
        if (giftCard) {
            indicators.push(indicator(
                "gift-card-pressure",
                "Gift-card payment pressure",
                "mentions a gift card together with payment, urgency, secrecy, or a request",
                40,
                "pairs a gift card with a payment request or pressure",
                null,
                giftCard
            ));
        }

        // Shouting / excessive punctuation
        const letters = text.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g, "");
        const caps = text.replace(/[^A-ZÁÉÍÓÚÜÑ]/g, "");
        const shouting = letters.length > 30 && caps.length / letters.length > 0.6;
        if (shouting || /!{3,}/.test(text)) {
            const capsRun = /[A-ZÁÉÍÓÚÜÑ]{4,}/.exec(text);
            indicators.push(indicator(
                "formatting",
                "Unusual formatting",
                "lots of capitals or exclamation marks",
                6,
                "uses attention-grabbing capitals or exclamation marks",
                null,
                /!{3,}/.test(text) ? "!!!" : (capsRun ? evidenceSnippet(capsRun[0]) : "")
            ));
        }

        const anchorLinks = input.links || [];
        const urls = findUrls(text).concat(anchorLinks.map(function (l) { return l.href; }).filter(Boolean));
        const linkResult = analyzeLinks(urls, anchorLinks);
        linkResult.flags.forEach(function (f) { indicators.push(f); });

        (input.flags || []).forEach(function (f) {
            if (!indicators.some(function (i) { return i.id === f.id; })) indicators.push(f);
        });

        const ruleScore = scoreIndicators(indicators);
        const modelPrediction = predictTextModel(text);
        if (modelPrediction && modelPrediction.triggered) {
            indicators.push(indicator(
                "learned-text-pattern",
                "Learned scam-message pattern",
                "matches a language pattern in the local training data",
                20,
                "matches a learned pattern in labeled text data",
                null,
                ""
            ));
        }
        const score = modelPrediction && modelPrediction.triggered
            ? Math.max(ruleScore, 44)
            : ruleScore;

        const level = riskLevelFor(score);
        const localized = indicators.map(function (item) { return localizeIndicator(item, lang); });
        localized.sort(function (a, b) { return b.weight - a.weight; });
        const category = localizeCategory(detectCategory(text, meta), lang, meta);

        return {
            score: score,
            ruleScore: ruleScore,
            textModelMatched: !!(modelPrediction && modelPrediction.triggered),
            level: level,
            lang: lang,
            indicators: localized,
            category: { id: category.id, title: category.title, icon: category.icon },
            explanation: buildExplanation(level, localized, category, meta, !!text.trim(), lang),
            actions: buildActions(level, localized, meta, lang),
            links: linkResult.hosts
        };
    }

    /* ---------------------------------------------------------
       PUBLIC SCAN API
       scan({ text, files }, onProgress) -> Promise<[record]>
       Records are saved unless Privacy Mode is enabled.
    --------------------------------------------------------- */
    async function scanText(text, options, onProgress) {
        const analysis = analyze({ text: text, links: [], flags: [], meta: {}, lang: options.lang });
        const record = buildRecord(analysis, { source: "text", text: text, notes: [] });
        await addAiReview(record, text, options, onProgress);
        return record;
    }

    async function scanFile(file, options, onProgress) {
        const ex = await extractFromFile(file, onProgress, options.lang);
        if (ex.attachments && ex.attachments.length) {
            const prefix = options.lang === "es" ? "Adjuntos: " : options.lang === "hi" ? "अटैचमेंट: " : options.lang === "zh" ? "附件：" : "Attachments: ";
            ex.notes.push(prefix + ex.attachments.join(", "));
        }
        const meta = { fileName: file.name, kind: ex.kind };
        const analysis = analyze({ text: ex.text, links: ex.links, flags: ex.flags, meta: meta, lang: options.lang });
        const record = buildRecord(analysis, {
            source: "file",
            text: ex.text,
            notes: ex.notes,
            file: { name: file.name, size: file.size, type: file.type || extOf(file.name).toUpperCase(), kind: ex.kind },
            email: ex.email
        });
        await addAiReview(record, ex.text, options, onProgress);
        return record;
    }

    function scanQr(input, options) {
        options = options || {};
        const uiLang = normalizeLang(options.lang || "en");
        const payload = String(input.text || "").slice(0, 4000);
        const displayText = String(input.displayText || payload).slice(0, 4000);
        const type = String(input.type || "text");
        const meta = { kind: "qr", qrType: type };
        const flags = [];
        const schemeMatch = /^([a-z][a-z0-9+.-]*:)/i.exec(payload);
        const dangerousSchemes = ["javascript:", "vbscript:", "data:", "file:", "blob:", "intent:", "content:", "chrome:", "about:"];
        if (schemeMatch && dangerousSchemes.indexOf(schemeMatch[1].toLowerCase()) >= 0) {
            flags.push(indicator(
                "qr-dangerous-scheme",
                "Dangerous scheme in QR code",
                "can run code or open an app",
                45,
                "uses a link type that can run code",
                { scheme: schemeMatch[1].toLowerCase() },
                schemeMatch[1].toLowerCase()
            ));
        }
        const scanHref = /^https?:\/\//i.test(payload)
            ? payload
            : /^www\./i.test(payload) ? "http://" + payload : "";
        const links = type === "url" && scanHref ? [{ href: scanHref, text: "" }] : [];
        const analysis = analyze({ text: payload, links: links, flags: flags, meta: meta, lang: options.lang });
        const notes = [];
        if (type === "wifi" && uiLang === "es") notes.push("La contraseña de la red Wi-Fi se oculta en el historial.");
        else if (type === "wifi" && uiLang === "hi") notes.push("Wi-Fi नेटवर्क का पासवर्ड इतिहास में छिपाया जाता है।");
        else if (type === "wifi" && uiLang === "zh") notes.push("Wi-Fi 密码不会显示在历史记录中。");
        else if (type === "wifi") notes.push("The Wi-Fi password is hidden in history.");
        notes.push(uiLang === "es"
            ? "El código QR se decodificó en este dispositivo y el destino no se abrió."
            : uiLang === "hi"
                ? "QR कोड इस डिवाइस पर डिकोड हुआ और गंतव्य नहीं खोला गया।"
                : uiLang === "zh"
                    ? "二维码已在本设备上解码，目标未被打开。"
                    : "The QR code was decoded on this device and the destination was not opened.");
        const record = buildRecord(analysis, {
            source: "qr",
            text: displayText,
            notes: notes,
            qr: { type: type, destination: displayText, localOnly: true }
        });
        if (!options.privacyMode) saveRecord(record);
        return record;
    }

    function buildRecord(analysis, src) {
        const cleanText = (src.text || "").replace(/\s+\n/g, "\n").trim();
        const excerpt = cleanText.replace(/\s+/g, " ").slice(0, 140);
        return {
            id: uid(),
            createdAt: new Date().toISOString(),
            source: src.source,
            title: analysis.category.title,
            icon: analysis.category.icon,
            category: analysis.category.id,
            file: src.file || null,
            email: src.email ? { from: src.email.from, subject: src.email.subject } : null,
            excerpt: excerpt,
            text: cleanText.slice(0, MAX_STORED_TEXT),
            textTruncated: cleanText.length > MAX_STORED_TEXT,
            notes: src.notes || [],
            score: analysis.score,
            ruleScore: analysis.ruleScore,
            triageScore: analysis.score,
            scoreBasis: "rules",
            lang: analysis.lang,
            textModelMatched: analysis.textModelMatched,
            level: analysis.level,
            indicators: analysis.indicators.map(function (i) {
                return {
                    id: i.id,
                    title: i.title,
                    detail: i.detail,
                    severity: i.severity,
                    weight: i.weight,
                    evidence: i.evidence,
                    nextStep: i.nextStep || ""
                };
            }),
            explanation: analysis.explanation,
            actions: analysis.actions,
            links: analysis.links,
            qr: src.qr || null
        };
    }

    async function addAiReview(record, extractedText, options, onProgress) {
        if (!options.aiConsent || !extractedText.trim()) return;

        const maxAiChars = 12000;
        const message = extractedText.slice(0, maxAiChars);
        record.aiTextTruncated = extractedText.length > maxAiChars;
        const uiLang = normalizeLang(options.lang || "en");
        if (onProgress) onProgress(uiLang === "es" ? "Solicitando la segunda opinión opcional con IA…"
            : uiLang === "hi" ? "वैकल्पिक AI दूसरी राय माँगी जा रही है…"
                : uiLang === "zh" ? "正在请求可选的 AI 第二意见…"
                    : "Requesting optional AI second opinion…");

        try {
            const response = await fetch("/api/analyze", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message: message })
            });
            const result = await response.json();
            if (!response.ok) {
                record.aiError = result.error || (uiLang === "es" ? "La revisión con IA no está disponible."
                    : uiLang === "hi" ? "AI समीक्षा उपलब्ध नहीं है।"
                        : uiLang === "zh" ? "AI 审查不可用。"
                            : "AI review is unavailable.");
                return;
            }
            const ai = result.analysis;
            if (
                !ai ||
                !Number.isInteger(ai.risk_score) ||
                ai.risk_score < 0 ||
                ai.risk_score > 100 ||
                !["High", "Medium", "Low"].includes(ai.risk_level) ||
                typeof ai.summary !== "string" ||
                typeof ai.explanation !== "string" ||
                !["low", "medium", "high"].includes(ai.assessment_confidence) ||
                typeof ai.confidence_reason !== "string" ||
                typeof ai.recommendation !== "string" ||
                !Array.isArray(ai.warning_signs) ||
                ai.warning_signs.length > 6 ||
                ai.warning_signs.some(function (sign) {
                    return !sign ||
                        typeof sign.description !== "string" ||
                        typeof sign.quoted_evidence !== "string" ||
                        !sign.quoted_evidence ||
                        message.indexOf(sign.quoted_evidence) < 0;
                }) ||
                !Array.isArray(ai.context_needed) ||
                ai.context_needed.length > 3 ||
                ai.context_needed.some(function (question) { return typeof question !== "string"; })
            ) {
                record.aiError = uiLang === "es"
                    ? "El proveedor de IA devolvió una revisión incompleta."
                    : uiLang === "hi"
                        ? "AI प्रदाता ने अधूरी समीक्षा लौटाई।"
                        : uiLang === "zh"
                            ? "AI 提供商返回了不完整的审查。"
                            : "The AI provider returned an incomplete review.";
                return;
            }
            record.aiAnalysis = ai;
            record.score = ai.risk_score;
            record.scoreBasis = "ai";
            record.level = riskLevelFor(record.score);
        } catch (_error) {
            record.aiError = uiLang === "es"
                ? "No se pudo contactar con el proveedor de IA. El análisis local sigue disponible."
                : uiLang === "hi"
                    ? "AI प्रदाता से संपर्क नहीं हो सका। स्थानीय नियम विश्लेषण अभी भी उपलब्ध है।"
                    : uiLang === "zh"
                        ? "无法联系 AI 提供商。本地规则分析仍可用。"
                        : "The AI provider could not be reached. Local rule analysis is still available.";
        }
    }

    async function scan(input, onProgress) {
        const records = [];
        const options = {
            aiConsent: input.aiConsent === true,
            privacyMode: input.privacyMode === true,
            lang: normalizeLang(input.lang)
        };
        const text = (input.text || "").trim();
        if (text) {
            if (onProgress) {
                const analyzing = options.lang === "es" ? "Analizando el mensaje…"
                    : options.lang === "hi" ? "संदेश का विश्लेषण हो रहा है…"
                        : options.lang === "zh" ? "正在分析消息…"
                            : "Analyzing message…";
                onProgress(analyzing);
            }
            records.push(await scanText(text, options, onProgress));
        }
        const files = Array.from(input.files || []);
        for (let i = 0; i < files.length; i++) {
            const prefix = files.length > 1 ? "(" + (i + 1) + "/" + files.length + ") " : "";
            records.push(await scanFile(files[i], options, function (msg) { if (onProgress) onProgress(prefix + msg); }));
        }
        if (!options.privacyMode) records.forEach(saveRecord);
        return records;
    }

    /* ---------------------------------------------------------
       HISTORY STORAGE
    --------------------------------------------------------- */
    let memoryHistory = [];

    function getHistory() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            const list = raw ? JSON.parse(raw) : [];
            return normalizeHistory(Array.isArray(list) ? list : []);
        } catch (e) {
            return normalizeHistory(memoryHistory.slice());
        }
    }

    function normalizeHistory(list) {
        return list.filter(function (record) {
            return record && typeof record === "object" && !Array.isArray(record);
        }).map(function (record) {
            const score = record.aiAnalysis && typeof record.aiAnalysis.risk_score === "number"
                ? record.aiAnalysis.risk_score
                : typeof record.triageScore === "number"
                    ? record.triageScore
                    : typeof record.ruleScore === "number" ? record.ruleScore : record.score;
            if (typeof score === "number") {
                record.score = score;
                record.level = riskLevelFor(score);
            }
            return record;
        });
    }

    function setHistory(list) {
        memoryHistory = list.slice(0, MAX_HISTORY);
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryHistory));
        } catch (e) {
            // Storage full: drop stored text from older scans and try again
            try {
                const slim = memoryHistory.map(function (r, i) { return i < 20 ? r : Object.assign({}, r, { text: r.excerpt, textTruncated: true }); });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(slim));
            } catch (e2) { /* keep in memory only */ }
        }
    }

    function saveRecord(record) {
        const list = getHistory();
        list.unshift(record);
        setHistory(list);
    }

    function getRecord(id) {
        return getHistory().find(function (r) { return r.id === id; }) || null;
    }

    function deleteRecord(id) {
        const list = getHistory();
        const index = list.findIndex(function (r) { return r.id === id; });
        if (index < 0) return null;
        const removed = list.splice(index, 1)[0];
        setHistory(list);
        return { record: removed, index: index };
    }

    function restoreRecord(record, index) {
        const list = getHistory();
        list.splice(Math.min(index, list.length), 0, record);
        setHistory(list);
    }

    function clearHistory() {
        setHistory([]);
    }

    function formatDate(iso) {
        const d = new Date(iso);
        const date = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
        const time = d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
        return date + " · " + time;
    }

    window.ScamShield = {
        scan: scan,
        scanQr: scanQr,
        analyze: analyze,
        detectLanguage: detectLanguage,
        normalizeLang: normalizeLang,
        findUrls: findUrls,
        getHistory: getHistory,
        getRecord: getRecord,
        deleteRecord: deleteRecord,
        restoreRecord: restoreRecord,
        clearHistory: clearHistory,
        formatDate: formatDate,
        formatBytes: formatBytes,
        escapeHtml: escapeHtml,
        MAX_FILE_SIZE: MAX_FILE_SIZE
    };
})();
