# Verification checklist

Use PASS / FAIL / NOT RUN / BLOCKED with dated evidence. The initial statuses below
reflect the prior remediation session, not an assertion that future changes pass.

## Commands

Run from the project directory. PowerShell must check each native command's exit code.

```powershell
node test_scanner_rules.js
if ($LASTEXITCODE -ne 0) { throw 'Scanner regression failure' }
node test_remediation.js
if ($LASTEXITCODE -ne 0) { throw 'Remediation regression failure' }
Get-ChildItem -File *.js | ForEach-Object {
    node --check $_.FullName
    if ($LASTEXITCODE -ne 0) { throw ('Syntax failure: ' + $_.Name) }
}
```

When a working Python interpreter is available, use its explicit path. Install the
project's requirements in an isolated environment; benchmark tests also need
requirements-model.txt. Do not overwrite .env or print its values.

```powershell
python -m pytest -v
if ($LASTEXITCODE -ne 0) { throw 'Python test failure' }
```

pytest discovers the unittest classes too; a second identical unittest run is optional.
Public benchmarks require network access. For a chosen model and a permitted local
development fixture, use real paths in place of the placeholders:

```powershell
python benchmark_text_model.py --model 'PATH_TO_SELECTED_MODEL.js' --skip-public --user-json 'PATH_TO_DEVELOPMENT_FIXTURE.json'
if ($LASTEXITCODE -ne 0) { throw 'Benchmark failure' }
```

## Acceptance matrix

| Area | Acceptance check | Initial evidence/status |
| --- | --- | --- |
| Model | Default and selected asset returns 200 through Flask; correct content and script order; unknown/private paths remain denied | Python tests added, BLOCKED at runtime |
| Model | Distinct selected models change all model-dependent JS comparison outputs; rules-only stays unchanged | PASS, Node fixture models |
| Model | Missing/invalid model visibly degrades to rules-only without losing findings | NOT RUN; current source gap |
| Model | Training, Python inference and JS inference tokenize equivalent inputs identically | NOT RUN; current source mismatch |
| Coverage | Oversized/unreadable/truncated input cannot be presented as cleared | PASS in engine tests; browser presentation NOT RUN |
| Coverage | OCR English-only and PDF 30-page/image-only limits are explicit | PASS with mocked extractors; actual parsers/browser NOT RUN |
| Coverage | Empty/unsupported/attachment content is disclosed in main, history and batch views | NOT RUN end-to-end |
| Persistence | Same-tab refresh can restore local findings after AI fails | PASS in engine/sessionStorage mocks |
| Persistence | Interrupted AI, navigation, repeated batches and stale callbacks cannot erase/replace newer findings | PARTIAL; broader race cases NOT RUN |
| Persistence | When both stores fail, findings remain visible in memory; refresh limitation is clear | PASS engine fallback; full browser flow NOT RUN |
| Privacy | New scans write no durable history without explicit opt-in | PASS Node test |
| Privacy | Unavailable preference service leaves durable history off | PASS mocked controls |
| Privacy | Temporary recovery content and actual expiry policy match disclosure | NOT RUN; expiry semantics need remediation |
| Learn | No scanner-only script; local navigation resources exist | PASS static checks |
| Learn | Flask-served page has no runtime errors and renders at mobile/desktop sizes | NOT RUN |
| UX | Local findings precede AI and conflicting AI updates only its section | PASS engine and mock renderer; browser NOT RUN |
| UX | Evidence and recommendations precede numeric scores | PASS markup order |
| UX | Keyboard navigation, announcements, focus, contrast, long text, mobile layout | NOT RUN |
| Detection | Eight original and six new contextual cases continue passing | PASS, 14 cases |
| Detection | Evaluate shipped-model combined false positives separately from rules | One residual model false positive reproduced; broader evaluation NOT RUN |
| Provider | Timeouts, malformed output, unsupported evidence and missing key preserve local findings | Partial Node mocks; full Flask suite BLOCKED |

## Browser scenarios

Serve with Flask, not file://. Test both the home scanner and results scanner:
1. Plain text, ordinary benign text, obvious pressure, ambiguous text.
2. Multiple files with one failing; image OCR; text PDF; image-only PDF; more than 30 pages.
3. AI off, mocked success, conflicting AI score, mocked timeout/failure, refresh mid-review.
4. History off/on, blocked localStorage, blocked sessionStorage, both blocked.
5. Start a second scan before the first batch's AI work finishes; use back/forward.
6. Return through Learn/History and resume temporary results. Test expired snapshots.
7. Confirm no message content appears in request URLs or console logs. Inspect only
   fictional fixture content; avoid live provider calls and real private messages.

## Finish criteria

- Record each command and actual result; do not replace NOT RUN with an assumption.
- Fix failed modified-behavior tests before packaging; disclose environmental blockers.
- Update README and REMEDIATION_HANDOFF to describe actual behavior and limitations.
- ZIP only source, model and documentation; exclude .env, instance/, caches, virtual
  environments, uploaded user data and temporary test artifacts. Include .env.example.
- Inspect archive entry names and verify key files before delivery.
- Final response: ISSUE | ROOT CAUSE | FIX | FILES CHANGED | VERIFICATION.
