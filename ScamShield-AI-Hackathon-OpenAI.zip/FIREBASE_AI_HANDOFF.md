# Firebase AI review module handoff

These are two new files in the personal project folder. They are not wired into the team app. Copy `firebase-ai-review.js` and this handoff into the team app directory beside `firebase.js`; no team files or the downloaded ZIP were changed.

## Team integration

1. **Fix the Firebase initializer in the team project first.** Its `firebase.js` currently has duplicate Firestore imports that prevent the ES module from parsing. In that file only, remove the duplicate import binding(s), keeping each required named import once. Keep its existing named `app` export; the review module imports that initialized app and does not initialize another one.

2. **Set up Firebase AI Logic and App Check.** In Firebase Console, enable AI Logic, choose the Gemini Developer API, register the web app with Firebase App Check using reCAPTCHA v3, and enforce App Check for AI Logic. Firebase's current documentation says App Check enforcement is required for Firebase AI Logic starting November 2, 2026. The module initializes App Check once before its first AI request; it requires this public site-key configuration before requesting a review:

   ```html
   <script>
     window.SCAMSHIELD_FIREBASE_APPCHECK_SITE_KEY = "YOUR_PUBLIC_RECAPTCHA_V3_SITE_KEY";
   </script>
   <script type="module" src="./firebase-ai-review.js"></script>
   ```

   Add these tags to each of the three app pages that need the AI review API. The reCAPTCHA **site key** is public; do not put its secret key, Gemini API key, or any other secret in client code. For local testing only, you may additionally set `window.SCAMSHIELD_FIREBASE_APPCHECK_DEBUG = true` before the module script. This enables Firebase's debug-token flow; register the generated debug token in Firebase Console and never ship that setting or token to production.

3. **Require two explicit, unchecked controls.** Use separate checkboxes for adult confirmation and AI data consent; do not pre-check either. Call the module only after the existing local scan has completed, and only for plain text (including text extracted locally from a file):

   ```js
   const aiResult = await window.ScamShieldAIReview.reviewText(extractedText, {
     consent: document.getElementById("aiConsent").checked,
     adultConfirmed: document.getElementById("adultConfirmed").checked
   });
   ```

   Do not pass a `File`, upload file bytes, or call AI before the local scan. The module accepts only a non-empty string and caps it at 12,000 characters.

4. **Keep the assessment sources separate and make AI optional.** The module returns `riskScore`, `riskLevel`, `explanation`, `warningSigns` (objects with `description` and `quotedEvidence`), and `recommendation`. Preserve `ruleScore` and `aiResult.riskScore` as separate values. Label the local result “Initial Triage”; it must not raise, lower, or replace the AI assessment. Both scores are heuristic indicators, not calibrated probabilities. The prompt forbids AI-authorship assessment, and the parser rejects any warning sign whose exact quoted evidence is missing from the submitted text. Wrap the AI call in `try/catch`; if App Check, network, or AI setup fails, show the existing local result and a non-blocking notice. Render every model-provided string only with `textContent` or text nodes, never `innerHTML`. For example:

   ```js
   const list = document.createElement("ul");
   aiResult.warningSigns.forEach(function (sign) {
     const item = document.createElement("li");
     item.textContent = sign.description + " — Quoted evidence: “" + sign.quotedEvidence + "”";
     list.appendChild(item);
   });
   ```

## Eligibility, privacy, and operations

Gemini Developer API's current terms require API users to be at least 18 and prohibit making API clients available in websites, apps, or services directed to or likely accessed by people under 18. An adult checkbox alone does not establish that the app itself meets this restriction. Confirm the app's audience and eligibility before enabling or publishing this feature; if it is directed to or likely accessed by minors, do not enable this Gemini API path.

With the Gemini Developer API unpaid tier, submitted content and generated responses may be used to improve Google's products and services, and human reviewers may process them. Do not send sensitive, confidential, or personal information. Clearly disclose provider data handling before consent. `gemini-3.5-flash-lite` is currently listed by Firebase as not requiring billing, but quotas and terms apply and can change. Firebase AI Logic routes requests through Firebase; this browser module contains no Gemini API key.

The team initializer's duplicate Firestore imports must be repaired before this module can load. Live Firebase/App Check behavior was not exercised because the team's Firebase configuration, public site key, and Firebase Console setup are unavailable here.

## Official references

- [Firebase AI Logic web setup](https://firebase.google.com/docs/ai-logic/get-started)
- [Firebase AI Logic supported models](https://firebase.google.com/docs/ai-logic/models)
- [Structured output and response schemas](https://firebase.google.com/docs/ai-logic/generate-structured-output)
- [Firebase AI Logic App Check](https://firebase.google.com/docs/ai-logic/app-check)
- [Firebase App Check with reCAPTCHA v3](https://firebase.google.com/docs/app-check/web/recaptcha-provider)
- [Firebase AI Logic pricing and billing](https://firebase.google.com/docs/ai-logic/pricing)
- [Gemini API Additional Terms](https://ai.google.dev/gemini-api/terms)
