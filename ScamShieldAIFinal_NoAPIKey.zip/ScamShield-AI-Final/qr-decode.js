/* =========================================================
   ScamShield AI — QR decoding helpers
   Pure functions used by qr-tool.js and by Node tests.
   Decoding happens on the device; nothing is uploaded.
   Exposes: window.ScamShieldQrDecode (or module.exports)
========================================================= */
(function (root, factory) {
    "use strict";
    if (typeof module === "object" && module.exports) {
        module.exports = factory();
    } else {
        root.ScamShieldQrDecode = factory();
    }
})(typeof window !== "undefined" ? window : globalThis, function () {
    "use strict";

    const MAX_PAYLOAD = 4000;
    const DANGEROUS_SCHEMES = ["javascript:", "vbscript:", "data:", "file:", "blob:", "intent:", "content:", "chrome:", "about:"];
    let injectedDecoder = null;

    function setDecoder(fn) {
        injectedDecoder = typeof fn === "function" ? fn : null;
    }

    function resolveDecoder() {
        if (injectedDecoder) return injectedDecoder;
        if (typeof root !== "undefined" && typeof root.jsQR === "function") return root.jsQR;
        if (typeof globalThis !== "undefined" && typeof globalThis.jsQR === "function") return globalThis.jsQR;
        return null;
    }

    function normalizePayload(value) {
        return String(value == null ? "" : value).replace(/\u0000/g, "").trim().slice(0, MAX_PAYLOAD);
    }

    function schemeOf(payload) {
        const match = /^([a-z][a-z0-9+.-]*):/i.exec(payload || "");
        return match ? match[1].toLowerCase() + ":" : "";
    }

    function isUrlLike(payload) {
        const value = (payload || "").trim();
        if (!value || /\s/.test(value)) return false;
        if (/^https?:\/\//i.test(value)) return true;
        if (/^www\.[a-z0-9-]+(\.[a-z0-9-]+)+/i.test(value)) return true;
        return false;
    }

    function safeUrl(payload) {
        const value = (payload || "").trim();
        if (/^https?:\/\//i.test(value)) return value;
        if (/^www\./i.test(value)) return "http://" + value;
        return "";
    }

    // Removes credentials that should not be kept in scan history.
    function redactPayload(payload, type) {
        const value = normalizePayload(payload);
        if (type !== "wifi") return value;
        return value.replace(/(^|;)P:[^;]*/i, "$1P:[hidden]");
    }

    function classifyPayload(rawPayload) {
        const payload = normalizePayload(rawPayload);
        const type = classifyType(payload);
        return {
            payload: payload,
            type: type,
            displayText: redactPayload(payload, type),
            scheme: schemeOf(payload),
            dangerousScheme: DANGEROUS_SCHEMES.indexOf(schemeOf(payload)) >= 0,
            isHttpUrl: /^https?:\/\//i.test(payload)
        };
    }

    function classifyType(rawPayload) {
        const payload = normalizePayload(rawPayload);
        if (!payload) return "empty";
        const lower = payload.toLowerCase();
        if (DANGEROUS_SCHEMES.indexOf(schemeOf(payload)) >= 0) return "dangerous";
        if (isUrlLike(payload)) return "url";
        if (lower.indexOf("mailto:") === 0) return "email";
        if (lower.indexOf("tel:") === 0) return "phone";
        if (lower.indexOf("sms:") === 0 || lower.indexOf("smsto:") === 0) return "sms";
        if (lower.indexOf("wifi:") === 0) return "wifi";
        if (lower.indexOf("begin:vcard") === 0) return "contact";
        if (lower.indexOf("geo:") === 0) return "location";
        if (/^(bitcoin|ethereum|ethereum|monero|bitcoincash|litecoin):/i.test(payload)) return "crypto";
        return "text";
    }

    function imageDataToRgba(imageData) {
        if (!imageData || typeof imageData.width !== "number" || typeof imageData.height !== "number") {
            throw new Error("Invalid image data");
        }
        const expected = imageData.width * imageData.height;
        const data = imageData.data;
        if (!data || data.length === expected * 4) return data;
        if (data.length !== expected) throw new Error("Unsupported image data");
        const rgba = new Uint8ClampedArray(expected * 4);
        for (let i = 0; i < expected; i++) {
            rgba[i * 4] = data[i];
            rgba[i * 4 + 1] = data[i];
            rgba[i * 4 + 2] = data[i];
            rgba[i * 4 + 3] = 255;
        }
        return rgba;
    }

    function decodeImageData(imageData) {
        const decoder = resolveDecoder();
        if (typeof decoder !== "function") {
            throw new Error("The local QR decoder is not available.");
        }
        const rgba = imageDataToRgba(imageData);
        const result = decoder(rgba, imageData.width, imageData.height, {
            inversionAttempts: "attemptBoth"
        });
        if (!result || !result.data) return null;
        return {
            payload: normalizePayload(result.data),
            location: result.location || null,
            binaryData: result.binaryData || null
        };
    }

    function analysisInput(decoded, lang) {
        const info = classifyPayload(decoded && decoded.payload);
        return {
            text: info.payload,
            displayText: info.displayText,
            type: info.type,
            lang: lang || "en",
            links: info.type === "url" && safeUrl(info.payload)
                ? [{ href: safeUrl(info.payload), text: "" }]
                : []
        };
    }

    return {
        MAX_PAYLOAD: MAX_PAYLOAD,
        DANGEROUS_SCHEMES: DANGEROUS_SCHEMES,
        normalizePayload: normalizePayload,
        classifyPayload: classifyPayload,
        classifyType: classifyType,
        redactPayload: redactPayload,
        imageDataToRgba: imageDataToRgba,
        setDecoder: setDecoder,
        decodeImageData: decodeImageData,
        analysisInput: analysisInput,
        safeUrl: safeUrl
    };
});
