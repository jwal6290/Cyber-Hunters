import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app import (
    MAX_REQUESTS_PER_MINUTE,
    _rate_limit_allows,
    _validate_analysis,
    app,
    detect_language,
)


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.provider_patch = patch.dict(os.environ, {"AI_PROVIDER": "gemini"})
        self.provider_patch.start()
        app.config["TESTING"] = True
        app.config["DATABASE_PATH"] = str(Path(self.temp_dir.name) / "test.sqlite3")
        self.client = app.test_client()

    def tearDown(self):
        self.client = None
        self.temp_dir.cleanup()
        self.provider_patch.stop()

    def allow_ai(self):
        age = self.client.post("/api/age-gate", json={"adult_confirmed": True})
        consent = self.client.post("/api/ai-consent", json={"consent": True})
        self.assertEqual(age.status_code, 200)
        self.assertEqual(consent.status_code, 200)

    def test_api_flags_cannot_forge_server_session_state(self):
        response = self.client.post(
            "/api/analyze",
            json={
                "message": "A test message",
                "consent": True,
                "adult_confirmed": True,
            },
        )
        self.assertEqual(response.status_code, 403)

    def test_ai_consent_requires_server_recorded_adult_attestation(self):
        response = self.client.post("/api/ai-consent", json={"consent": True})
        self.assertEqual(response.status_code, 403)

    def test_api_requires_a_configured_key_after_session_consent(self):
        self.allow_ai()
        with patch.dict(os.environ, {"GEMINI_API_KEY": ""}):
            response = self.client.post("/api/analyze", json={"message": "A test message"})
        self.assertEqual(response.status_code, 503)

    def test_api_rejects_long_messages_before_provider_call(self):
        self.allow_ai()
        with patch.dict(os.environ, {"GEMINI_API_KEY": "test-key"}):
            with patch("app._request_gemini") as provider:
                response = self.client.post(
                    "/api/analyze",
                    json={"message": "x" * 12001},
                )
        self.assertEqual(response.status_code, 413)
        provider.assert_not_called()

    def test_server_session_updates_age_consent_and_privacy_state(self):
        state = self.client.get("/api/session").get_json()
        self.assertFalse(state["adult_confirmed"])
        self.assertFalse(state["ai_consent"])

        self.client.post("/api/age-gate", json={"adult_confirmed": True})
        self.client.post("/api/ai-consent", json={"consent": True})
        self.client.post("/api/privacy-mode", json={"enabled": True})
        state = self.client.get("/api/session").get_json()
        self.assertTrue(state["adult_confirmed"])
        self.assertTrue(state["ai_consent"])
        self.assertTrue(state["privacy_mode"])

        self.client.post("/api/age-gate", json={"adult_confirmed": False})
        state = self.client.get("/api/session").get_json()
        self.assertFalse(state["adult_confirmed"])
        self.assertFalse(state["ai_consent"])

    def test_opted_in_api_returns_a_separate_analysis(self):
        self.allow_ai()
        analysis = {
            "risk_score": 76,
            "risk_level": "High",
            "summary": "The message requests an unusual gift-card payment.",
            "explanation": "It requests sensitive information.",
            "assessment_confidence": "medium",
            "confidence_reason": "The payment request is clear, but sender context is unavailable.",
            "warning_signs": [{
                "description": "Unusual payment method",
                "quoted_evidence": "send a gift card",
            }],
            "context_needed": ["Did you expect a payment request from this sender?"],
            "recommendation": "Verify through a trusted channel.",
            "model": "gemini-3.5-flash-lite",
        }
        with patch.dict(os.environ, {"GEMINI_API_KEY": "test-key"}):
            with patch("app._request_gemini", return_value=analysis) as provider:
                response = self.client.post(
                    "/api/analyze",
                    json={"message": "Please send a gift card"},
                )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["analysis"]["risk_score"], 76)
        self.assertEqual(
            response.get_json()["analysis"]["assessment_confidence"],
            "medium",
        )
        provider.assert_called_once_with("Please send a gift card", "test-key")

    def test_api_rejects_malformed_json_and_missing_text(self):
        self.allow_ai()
        self.assertEqual(self.client.post("/api/analyze", data="{").status_code, 400)
        response = self.client.post("/api/analyze", json={"message": "  "})
        self.assertEqual(response.status_code, 400)

    def test_rate_limit_survives_new_database_connections(self):
        client_ip = "203.0.113.7"
        for _ in range(MAX_REQUESTS_PER_MINUTE):
            self.assertTrue(_rate_limit_allows(client_ip))
        self.assertFalse(_rate_limit_allows(client_ip))

    def test_api_persistent_rate_limit_rejects_the_eleventh_request(self):
        self.allow_ai()
        analysis = {"risk_score": 5}
        with patch.dict(os.environ, {"GEMINI_API_KEY": "test-key"}):
            with patch("app._request_gemini", return_value=analysis) as provider:
                responses = [
                    self.client.post("/api/analyze", json={"message": "Test message"})
                    for _ in range(MAX_REQUESTS_PER_MINUTE + 1)
                ]
        self.assertTrue(all(response.status_code == 200 for response in responses[:-1]))
        self.assertEqual(responses[-1].status_code, 429)
        self.assertEqual(provider.call_count, MAX_REQUESTS_PER_MINUTE)

    def test_medium_threshold_is_40_and_evidence_must_be_exact(self):
        base = {
            "summary": "A message summary.",
            "explanation": "A short explanation.",
            "assessment_confidence": "medium",
            "confidence_reason": "There is limited context.",
            "warning_signs": [],
            "context_needed": [],
            "recommendation": "Verify independently.",
        }
        self.assertEqual(
            _validate_analysis(dict(base, risk_score=39), "test-model", "Message")["risk_level"],
            "Low",
        )
        self.assertEqual(
            _validate_analysis(dict(base, risk_score=40), "test-model", "Message")["risk_level"],
            "Medium",
        )
        unsupported = dict(base, risk_score=60, warning_signs=[{
            "description": "Unusual request",
            "quoted_evidence": "not present",
        }])
        with self.assertRaisesRegex(ValueError, "quoted evidence"):
            _validate_analysis(unsupported, "test-model", "Original message")

    def test_secret_and_backend_source_are_not_served(self):
        self.assertEqual(self.client.get("/.env").status_code, 404)
        self.assertEqual(self.client.get("/app.py").status_code, 404)

    def test_home_and_allowlisted_assets_are_served(self):
        home = self.client.get("/")
        controls = self.client.get("/app-controls.js")
        demo = self.client.get("/firebase-ai-review-demo.html")
        model = self.client.get("/scamshield-text-model.js")
        hindi = self.client.get("/i18n-hi.js")
        mandarin = self.client.get("/i18n-zh.js")
        self.assertEqual(home.status_code, 200)
        self.assertEqual(controls.status_code, 200)
        self.assertEqual(demo.status_code, 200)
        self.assertEqual(model.status_code, 200)
        self.assertEqual(hindi.status_code, 200)
        self.assertEqual(mandarin.status_code, 200)
        self.assertIn(b"/api/analyze", demo.data)
        self.assertLess(
            home.data.index(b"scamshield-text-model.js"),
            home.data.index(b"scanner-engine.js"),
        )
        self.assertLess(home.data.index(b"i18n-hi.js"), home.data.index(b"i18n.js"))
        self.assertLess(home.data.index(b"i18n-zh.js"), home.data.index(b"i18n.js"))
        home.close()
        controls.close()
        demo.close()
        model.close()
        hindi.close()
        mandarin.close()

    def test_detect_language_recognizes_hindi_and_mandarin_scripts(self):
        self.assertEqual(detect_language("कृपया अपना OTP साझा करें।"), "hi")
        self.assertEqual(detect_language("请立即验证您的账户。"), "zh")
        self.assertEqual(detect_language("URGENTE: verifica tu cuenta"), "es")
        self.assertEqual(detect_language("Please verify your account"), "en")


if __name__ == "__main__":
    unittest.main()
