"use strict";

const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const context = {
    window: {},
    localStorage: { getItem: function () { return null; }, setItem: function () {} },
    URL: URL
};
vm.runInNewContext(fs.readFileSync(path.join(__dirname, "scamshield-text-model.js"), "utf8"), context);
vm.runInNewContext(fs.readFileSync(path.join(__dirname, "scanner-engine.js"), "utf8"), context);

function metrics(labels, predictions) {
    let tn = 0;
    let fp = 0;
    let fn = 0;
    let tp = 0;
    labels.forEach(function (label, index) {
        if (label && predictions[index]) tp++;
        else if (!label && predictions[index]) fp++;
        else if (label && !predictions[index]) fn++;
        else tn++;
    });
    const precision = tp + fp ? tp / (tp + fp) : 0;
    const recall = tp + fn ? tp / (tp + fn) : 0;
    return {
        accuracy: labels.length ? (tp + tn) / labels.length : 0,
        precision: precision,
        recall: recall,
        f1: precision + recall ? 2 * precision * recall / (precision + recall) : 0,
        true_negatives: tn,
        false_positives: fp,
        false_negatives: fn,
        true_positives: tp
    };
}

let examples;
try {
    examples = JSON.parse(fs.readFileSync(0, "utf8"));
} catch (_error) {
    process.stderr.write("Invalid benchmark input JSON.\n");
    process.exit(1);
}
if (!Array.isArray(examples) || !examples.length) {
    process.stderr.write("Benchmark input must be a non-empty array.\n");
    process.exit(1);
}

const labels = [];
const rulePredictions = [];
const modelPredictions = [];
const triagePredictions = [];
const modelWithStrongRulePredictions = [];
for (const example of examples) {
    if (!example || typeof example.text !== "string" || ![0, 1].includes(example.label)) {
        process.stderr.write("Benchmark input contains a malformed example.\n");
        process.exit(1);
    }
    const analysis = context.window.ScamShield.analyze({ text: example.text });
    labels.push(example.label === 1);
    rulePredictions.push(analysis.ruleScore >= 40);
    modelPredictions.push(analysis.textModelMatched);
    triagePredictions.push(analysis.score >= 40);
    modelWithStrongRulePredictions.push(analysis.textModelMatched || analysis.ruleScore >= 70);
}

console.log(JSON.stringify({
    rules_only: metrics(labels, rulePredictions),
    model_only: metrics(labels, modelPredictions),
    combined_initial_triage: metrics(labels, triagePredictions),
    model_with_strong_rule_override: metrics(labels, modelWithStrongRulePredictions)
}));
