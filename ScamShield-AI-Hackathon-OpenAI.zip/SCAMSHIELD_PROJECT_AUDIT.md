# ScamShield project audit and priorities

This is a handoff snapshot for the hackathon project, not a guarantee that every possible defect has been found or a formal security, legal, or model audit. Keep the team checkout and downloaded ZIP unchanged unless the team explicitly authorizes edits. The personal working folder is:

`C:\Users\SHADO\Downloads\Cyber-Hunters-main\Cyber-Hunters-main`

## Bottom line

ScamShield is a useful hackathon prototype: it has local text/file triage, a Flask Gemini endpoint, explicit consent UI, privacy controls, and an optional browser-side text model. It is not production-ready or established as competitive. The biggest immediate issues are a leaked API credential, a model file that Flask currently refuses to serve, mixed AI integration paths, and weak/biased evaluation data.

## Must resolve before the next public demo

### P0 — Revoke the exposed OpenAI credential

An OpenAI API key was pasted into chat. It is not copied into this document. Treat it as compromised regardless of later repository privacy settings: revoke it, review recent API usage and billing, and use a newly generated key only in a server-side secret store. The current personal Flask app expects `GEMINI_API_KEY`; the Firebase drop-in also uses Gemini. Neither currently uses OpenAI. If choosing OpenAI, implement a backend integration and never put its key in browser code.

### P0 — The local model asset currently returns 404

`index.html`, `results.html`, `history.html`, and the practice page load `scamshield-text-model.js`, but `app.py`'s `PUBLIC_FILES` allowlist omits that file. Verified against Flask's test client: `/scamshield-text-model.js` returns **404**, while `/scanner-engine.js` returns **200**. Therefore the model is not actually loaded through the local Flask-served UI, even though benchmark scripts can load it directly from disk. Fix the asset allowlist (or an equivalent safe static-serving route), then add a test that asserts the model asset is served and loaded before `scanner-engine.js`.

### P0 — Decide whether Gemini is allowed for the actual audience

The UI's 18+ checkbox is only self-attestation. It does not verify age and does not make an app eligible if it is directed to or likely accessed by people under 18. Confirm the hackathon's audience and current provider terms before enabling Gemini. If the audience makes this path ineligible, disable Gemini for that release and demo local-only triage or choose an appropriately reviewed alternative.

## High-priority product and integration decisions

### Choose one AI integration path

There are currently separate Gemini paths:

- The personal app's primary path is `app.py` → Flask `/api/analyze` → Gemini Developer API, with `GEMINI_API_KEY` held server-side.
- `firebase-ai-review.js` is a separate drop-in using Firebase AI Logic + App Check. It is not wired into the main Flask UI and is not in `PUBLIC_FILES`.
- OpenAI is not integrated into either path.

Choose one path for the hackathon, document its secret/configuration requirements, consent behavior, error behavior, provider terms, and deployment. Avoid maintaining two competing AI request paths. The Firebase module checks consent/adult flags in the browser; this is a UI guard, not independent age verification. App Check authenticates app attestation, not age or consent.

The team project was previously inspected read-only. Its app is nested under `Cyber-Hunters-main`; its `firebase.js` was found to have duplicate Firestore imports that prevent module parsing. Verify this finding against the current team checkout before handoff; do not fix team files without authorization. The standalone Firebase module expects the team's existing named `{ app }` export and Firebase JS SDK v13.3.0.

### Do not present current metrics as real-world accuracy

The present model is an uncalibrated unigram/bigram logistic-regression classifier. The fixed `0.7` cutoff and the 0–100 UI scores are heuristics, not probabilities. Evaluation results are not directly comparable to commercial products.

Recorded results from the current benchmark code:

| Evaluation set | Model only F1 | Combined Initial Triage F1 | Important caveat |
|---|---:|---:|---|
| Scam Shield SMS held-out test | 94.6% | 95.5% | One public dataset; label/domain limitations |
| UCI SMS spam domain-shift check | 88.0% | 86.5% | Old spam corpus, not scam-specific |
| GPT-generated 101–300 set | 75.2% | 73.6% | 160 binary-labeled messages; 40 ambiguous messages omitted |
| User file named `scamshield_real_world_examples.json` | 60.9% | 66.7% | Only 17 records: 16 suspicious, 1 benign; source authenticity unverified |

On the 200-message synthetic set, combined triage traded 4 fewer false negatives for 10 more false positives than model-only (20 FN/23 FP versus 24 FN/13 FP). On UCI, combining rules reduced F1. The 17-record set is too small and imbalanced to estimate false-alarm performance; its one benign example is not enough to substantiate the reported 100% precision.

The current browser score uses the combined result whenever the model triggers, with a medium-risk floor; the UI still labels the assessment “Initial Triage.” Compare alternatives on the validation set, but reserve new, untouched data for final reporting. Do not keep adjusting thresholds or rules against a set and then call it a holdout.

## Evaluation/data problems to fix

1. **Get a credible, consented evaluation set.** Collect enough independently labeled legitimate and suspicious messages from the target use case. Record provenance, dates, language, channel, labeler, adjudication, and permission. Remove personal data and avoid publishing raw messages.
2. **Split by source/person/campaign/time, not random near-duplicates.** De-duplicate train, validation, and test sets, including the synthetic supplement. Keep the latest holdout locked until the scanner and threshold are frozen.
3. **Define ambiguous handling.** The current benchmark ignores `ambiguous`; production cannot silently force uncertain cases into safe/scam. Decide whether to abstain, ask for context, or return “uncertain,” and measure that behavior.
4. **Report more than accuracy/F1.** Include per-class precision/recall, false-positive and false-negative counts, confusion matrices, balanced accuracy, coverage/abstention, and confidence intervals. Make label prevalence explicit.
5. **Test domain shift.** Current data is mainly English SMS-like text. Evaluate messaging apps, email, delivery/bank impersonation, marketplace and job scams, conversational oddities, OCR/transcription errors, regional language, and legitimate payment/security warnings.
6. **Keep training data distinct.** The current generated model used the Scam Shield SMS training split plus 80 labeled examples from an earlier local development corpus. Do not use the already evaluated 101–300 or real-world-named set for training without acknowledging that they cease to be independent test data.
7. **Verify source claims and licensing.** The attached “real world” filename does not prove examples are real. UCI is old general SMS spam, not scam. Preserve dataset attribution/license notices and check duplication and license compatibility before redistribution.

## Detector quality and UX

- Rule patterns are brittle, language-dependent, and may match benign discussion or miss novel tactics. Keep them as transparent clues, not a verdict.
- The current combination can lower precision; decide whether rules should affect score or only explain evidence. Any scoring change must be justified on validation data and checked against a new holdout.
- The learned-pattern indicator is not an explanation of the text. Show what matched only if it can be explained safely; otherwise avoid suggesting that the classifier has identified a specific scam tactic.
- Treat “Low Risk” as “no known indicators matched,” never “safe.” Keep report/verify advice visible.
- File checks are local text/metadata heuristics and extraction, not antivirus, malware sandboxing, or proof that a file is safe. State supported formats, extraction failure, size limits, and coverage plainly.
- Preserve the separation between `ruleScore`, local model/triage, and AI assessment. Do not let a local score override an AI result, or imply either is calibrated.

## Privacy, security, and operations

- Normal scans store excerpts/text in browser `localStorage`; Privacy Mode prevents newly scanned text from being saved but does not erase existing history. Explain this before scanning and provide clear/delete controls.
- Opting into AI sends message text to the provider. Disclose exactly what is sent and provider data handling before consent. Never send secrets, credentials, codes, payment details, or private messages without permission.
- SQLite stores visitor consent state for up to 30 days and rate-limit IP rows for the rate window (stale rows are removed on later rate-limit checks). Document retention, deletion behavior, and IP handling.
- The SQLite IP limiter is a useful demo control, not a robust production abuse/cost-control system. Review proxy configuration, shared-IP fairness, concurrency, storage growth, provider quotas, per-account cost limits, and alerting before deployment.
- `SESSION_COOKIE_SECURE` defaults to false unless configured. Set secure cookies behind HTTPS, configure a stable private `FLASK_SECRET_KEY`, use a production WSGI server, and do not expose Flask's development server.
- Keep all API credentials server-side. `.env` is ignored by `.gitignore`, but verify no credentials appear in source, logs, attachments, demo screenshots, or commits. The posted OpenAI key still needs revocation and account-usage review.
- Add accessibility checks for the blocking age modal, keyboard focus management, screen-reader status, color contrast, and mobile layouts.
- Review data protection, consent, retention, provider terms, and hackathon rules with the team; this document is not legal advice.

## Firebase drop-in status

`firebase-ai-review.js` and `FIREBASE_AI_HANDOFF.md` are standalone deliverables in the personal folder, not integrated in the team app. The module uses Gemini through Firebase AI Logic, asks for structured warning signs with exact quotes, validates quotes against the submitted text, caps input to 12,000 characters, and initializes App Check using a configurable public reCAPTCHA v3 site key. Syntax and mocked contract tests passed; live Firebase/App Check behavior was not tested. The team must configure Firebase Console, fix its initializer parse error, make an audience/terms decision, add the module where appropriate, and render model strings with `textContent`.

## Suggested order of work

1. Revoke the exposed OpenAI key and review usage.
2. Verify whether Gemini is appropriate for the hackathon audience; choose Gemini, OpenAI backend, or local-only.
3. Fix the Flask model-asset 404 and add an integration test for actual page asset loading.
4. Lock the 101–300 synthetic set and the current 17-record set as evaluated data; do not train on them if preserving their holdout status.
5. Analyze false positives/negatives using IDs and aggregate categories; keep message text private.
6. Create a new, balanced, consented and independently labeled validation set; define ambiguous/abstention behavior.
7. Evaluate model-only, rules-only, and candidate combined strategies; use the simplest strategy that improves the agreed metric without unacceptable false alarms.
8. Complete privacy, accessibility, provider, rate-limit and production checks, then demonstrate safe failures when AI is unavailable.

## Last known validation

The latest recorded local checks before this audit passed: 24 pytest tests, 17 unittest tests, JavaScript syntax checks, scanner regression cases, and practice-page inline-script parsing. The Firebase module also passed an ES-module syntax check and mocked tests for consent, missing App Check setup/retry, schema/evidence validation, and text truncation. These checks do not prove live provider integration or production readiness. Documentation changes in this audit were not followed by a code test run.
