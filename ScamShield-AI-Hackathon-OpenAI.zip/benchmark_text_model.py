"""Benchmark the generated local model without saving or printing message text."""

import argparse
import csv
import io
import json
import math
import re
import shutil
import subprocess
import sys
import unicodedata
import zipfile
from pathlib import Path

import requests
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score


MODEL_PATH = Path(__file__).with_name("scamshield-text-model.js")
MAX_DATASET_BYTES = 20 * 1024 * 1024
REQUEST_TIMEOUT_SECONDS = 45
UCI_URL = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"
SCAM_SHIELD_URL = "https://huggingface.co/datasets/rasheq/scam-shield-sms/resolve/main/{}.csv"


def load_model(path):
    source = path.read_text(encoding="utf-8")
    prefix = "window.ScamShieldTextModel = Object.freeze("
    start = source.find(prefix)
    if start < 0:
        raise ValueError("The browser model file has an unexpected format")
    start += len(prefix)
    end = source.find(");", start)
    if end < 0 or source[end + 2:].strip():
        raise ValueError("The browser model file has an unexpected format")
    payload = json.loads(source[start:end])
    if (
        not isinstance(payload, dict)
        or not isinstance(payload.get("weights"), dict)
        or not isinstance(payload.get("intercept"), (int, float))
        or not isinstance(payload.get("threshold"), (int, float))
        or not 0 < payload["threshold"] < 1
    ):
        raise ValueError("The browser model is missing valid weights or threshold")
    return payload


def predict(model, text):
    normalized = unicodedata.normalize("NFKD", text)
    normalized = "".join(char for char in normalized if not unicodedata.combining(char)).lower()
    words = re.findall(r"[a-z0-9]{2,}", normalized)
    seen = set()
    logit = float(model["intercept"])
    for index, word in enumerate(words):
        features = [word]
        if index:
            features.append(words[index - 1] + " " + word)
        for feature in features:
            if feature in seen:
                continue
            seen.add(feature)
            weight = model["weights"].get(feature, 0)
            if not isinstance(weight, (int, float)):
                raise ValueError("The browser model contains a malformed feature weight")
            logit += weight
    bounded_logit = max(-30, min(30, logit))
    return 1 / (1 + math.exp(-bounded_logit))


def report_metrics(name, examples, model):
    labels = [label for _, label in examples]
    predictions = [predict(model, text) >= model["threshold"] for text, _ in examples]
    tn, fp, fn, tp = confusion_matrix(labels, predictions, labels=[0, 1]).ravel()
    report = {
        "dataset": name,
        "examples": len(examples),
        "threshold": round(float(model["threshold"]), 4),
        "accuracy": round(accuracy_score(labels, predictions), 4),
        "precision": round(precision_score(labels, predictions, zero_division=0), 4),
        "recall": round(recall_score(labels, predictions, zero_division=0), 4),
        "f1": round(f1_score(labels, predictions, zero_division=0), 4),
        "true_negatives": int(tn),
        "false_positives": int(fp),
        "false_negatives": int(fn),
        "true_positives": int(tp),
    }
    report["scanner_comparison"] = benchmark_scanner(examples)
    return report


def benchmark_scanner(examples):
    node = shutil.which("node")
    if not node:
        raise ValueError("Node.js is required to benchmark the integrated scanner")
    script = Path(__file__).with_name("benchmark_scanner.js")
    payload = json.dumps([
        {"text": text, "label": label}
        for text, label in examples
    ], ensure_ascii=True)
    try:
        result = subprocess.run(
            [node, str(script)],
            input=payload,
            text=True,
            capture_output=True,
            timeout=120,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise ValueError("Integrated scanner benchmark exceeded 120 seconds") from exc
    if result.returncode:
        raise ValueError("Integrated scanner benchmark failed")
    try:
        metrics = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise ValueError("Integrated scanner returned malformed aggregate metrics") from exc
    return metrics


def download(url):
    response = requests.get(url, timeout=REQUEST_TIMEOUT_SECONDS)
    response.raise_for_status()
    if len(response.content) > MAX_DATASET_BYTES:
        raise ValueError("Downloaded dataset exceeds the safety limit")
    return response.content


def load_scam_shield_split(split):
    rows = []
    filename = "val" if split == "validation" else split
    reader = csv.DictReader(io.StringIO(download(SCAM_SHIELD_URL.format(filename)).decode("utf-8-sig")))
    if not {"text", "label"}.issubset(reader.fieldnames or []):
        raise ValueError("Scam Shield SMS split has unexpected columns")
    for row in reader:
        label = (row.get("label") or "").strip().lower()
        text = (row.get("text") or "").strip()
        if label in {"scam", "safe"} and text:
            rows.append((text[:12000], int(label == "scam")))
    if not rows:
        raise ValueError("Scam Shield SMS split contains no usable examples")
    return rows


def load_uci():
    archive = zipfile.ZipFile(io.BytesIO(download(UCI_URL)))
    member = next((name for name in archive.namelist() if name.endswith("SMSSpamCollection")), None)
    if member is None:
        raise ValueError("UCI SMS archive does not contain SMSSpamCollection")
    rows = []
    for line in archive.read(member).decode("utf-8").splitlines():
        label, separator, text = line.partition("\t")
        if not separator or not text.strip():
            continue
        if label not in {"ham", "spam"}:
            continue
        rows.append((text.strip()[:12000], int(label == "spam")))
    if not rows:
        raise ValueError("UCI SMS dataset contains no usable examples")
    return rows


def load_user_json(path):
    if path.stat().st_size > MAX_DATASET_BYTES:
        raise ValueError("User JSON exceeds the safety limit")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        payload = payload.get("examples")
    if not isinstance(payload, list):
        raise ValueError("User JSON must be an array or an object with an examples array")
    rows = []
    for row in payload:
        if not isinstance(row, dict):
            continue
        text = row.get("text")
        label = row.get("expected_label", row.get("label"))
        if not isinstance(text, str) or not text.strip():
            continue
        normalized_label = str(label).strip().lower()
        if normalized_label in {"suspicious", "scam", "spam", "1"}:
            rows.append((text.strip()[:12000], 1))
        elif normalized_label in {"benign", "safe", "ham", "0"}:
            rows.append((text.strip()[:12000], 0))
    if not rows:
        raise ValueError("User JSON contains no labeled suspicious/benign examples")
    return rows


def main():
    parser = argparse.ArgumentParser(description="Evaluate the local classifier using aggregate metrics only.")
    parser.add_argument("--model", type=Path, default=MODEL_PATH, help="Generated browser model file")
    parser.add_argument("--skip-public", action="store_true", help="Do not fetch public benchmark datasets")
    parser.add_argument("--user-json", type=Path, help="Optional labeled JSON array; raw examples are never printed")
    args = parser.parse_args()

    model = load_model(args.model)
    reports = []
    if not args.skip_public:
        reports.append(report_metrics("Scam Shield SMS validation", load_scam_shield_split("validation"), model))
        reports.append(report_metrics("Scam Shield SMS held-out test", load_scam_shield_split("test"), model))
        reports.append(report_metrics("UCI SMS spam domain-shift check", load_uci(), model))
    if args.user_json:
        reports.append(report_metrics("User-provided labeled set", load_user_json(args.user_json), model))
    if not reports:
        parser.error("Choose public datasets or provide --user-json")
    print(json.dumps({
        "score_note": "The logistic output and cutoff are heuristic; they are not calibrated probabilities.",
        "reports": reports,
    }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (requests.RequestException, UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError, zipfile.BadZipFile) as exc:
        print(f"Benchmark failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
