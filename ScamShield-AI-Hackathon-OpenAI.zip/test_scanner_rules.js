"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");

const context = {
    window: {
        ScamShieldTextModel: Object.freeze({
            intercept: -2,
            threshold: 0.7,
            weights: Object.freeze({ "rareword": 5 })
        })
    },
    localStorage: { getItem: function () { return null; }, setItem: function () {} },
    URL: URL
};
vm.runInNewContext(fs.readFileSync("scanner-engine.js", "utf8"), context);

const cases = [
    { name: "birthday gift-card request is not pressured", text: "I asked for a gift card for my birthday.", expected: false },
    { name: "general gift-card payment is not pressured", text: "You can pay for game credits with gift cards.", expected: false },
    { name: "priced gift-card request is flagged", text: "Apple asked for a $5 Google giftcard.", expected: true },
    { name: "urgent gift-card request is flagged", text: "Urgent: buy a Google gift card and send the code now.", expected: true },
    { name: "secret gift-card payment is flagged", text: "Keep this secret and pay with gift cards.", expected: true },
    { name: "context in another sentence does not count", text: "Apple asked for a gift card. This is urgent.", expected: false }
];

for (const testCase of cases) {
    const result = context.window.ScamShield.analyze({ text: testCase.text });
    const found = result.indicators.some(function (item) { return item.id === "gift-card-pressure"; });
    assert.equal(found, testCase.expected, testCase.name);
    console.log("PASS " + testCase.name);
}

const matched = context.window.ScamShield.analyze({ text: "rareword appears in this message" });
assert.equal(matched.textModelMatched, true, "learned text match is surfaced");
assert.equal(matched.ruleScore, 3, "rule score remains separate from the model signal");
assert.equal(matched.score, 44, "model contributes a conservative medium-triage floor");
assert.ok(matched.indicators.some(function (item) { return item.id === "learned-text-pattern"; }));
console.log("PASS model signal remains separate from rule score");

const noMatch = context.window.ScamShield.analyze({ text: "ordinary message text" });
assert.equal(noMatch.textModelMatched, false, "below-threshold model output is not flagged");
assert.equal(noMatch.score, noMatch.ruleScore, "non-matching model does not change triage score");
console.log("PASS below-threshold model output leaves triage unchanged");
