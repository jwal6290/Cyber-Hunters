# Dataset sources and model limits

ScamShield uses a compact, optional browser-side text classifier trained offline. Training and benchmark commands process public datasets in memory and print aggregate counts and metrics only. Raw corpus messages are not saved to the project or included in the generated JavaScript model.

## Sources

- [Scam Shield SMS on Hugging Face](https://huggingface.co/datasets/rasheq/scam-shield-sms), licensed CC BY 4.0. Its train split is used for model fitting; its validation and test splits are kept separate for evaluation. Dataset-card caveats include some potentially mislabeled incident-report examples and a safe-message set that is not representative of the diversity of legitimate service messages. The test split is not used to fit or tune this model.
- [UCI SMS Spam Collection](https://archive.ics.uci.edu/dataset/228/sms+spam+collection), licensed CC BY 4.0. It is an older general spam corpus, not a scam-specific or current-world benchmark. It is used only as a domain-shift check; "spam" is not equivalent to "scam."

The optional supplement format is a JSON array with `text` and `expected_label` fields. Only local examples explicitly labeled `suspicious` or `benign` are accepted. The initial local development examples used to build the current model are not a representative sample and must not be treated as an independent test set. Do not include private messages without their owners' explicit permission.

## Reproducible commands

Install the optional training dependency set and train from the Scam Shield SMS training split:

```powershell
python -m pip install -r requirements-model.txt
python train_text_model.py
```

The trainer reports aggregate validation and held-out test metrics and writes `scamshield-text-model.js`. To include a labeled local development supplement, pass `--supplement-json path\to\examples.json`; this does not change the public validation/test split.

Run the public benchmark and optionally a labeled local holdout:

```powershell
python benchmark_text_model.py
python benchmark_text_model.py --user-json path\to\holdout.json
```

The benchmark fetches the Scam Shield validation and test splits and UCI collection into memory, then evaluates the classifier and actual JavaScript scanner (rules-only, model-only, combined triage, and a stricter rule-override comparison) through a local Node process. `--skip-public --user-json path\to\holdout.json` evaluates only a local labeled set. Ambiguous user examples are excluded. Results contain aggregate metrics only; no message text is printed or stored.

## Interpretation and attribution

The logistic model output is not calibrated. Its fixed threshold is an empirical heuristic; it is not a probability that a message is fraudulent. The browser uses a match only as an additional Initial Triage signal, keeps the rule-only score separate, and never lets this local model override the optional Gemini result. Performance on these datasets does not establish real-world detection rates, and the model should not be marketed as competitive or reliable without representative, consented, independently labeled evaluation.

The source datasets are CC BY 4.0. Preserve attribution to the dataset authors and license if redistributing the generated model or training artifacts. Review each dataset card and current license terms before redistribution.
