/* =========================================================
   ScamShield AI — interface language layer
   English (default), Spanish (es), Hindi (hi), and Mandarin (zh).
   The user's choice is stored locally and applied to static and
   dynamic text. Exposes: window.ScamShieldI18n
========================================================= */
(function () {
    "use strict";

    const STORAGE_KEY = "scamshield-lang";
    const SUPPORTED = ["en", "es", "hi", "zh"];

    // English source text -> Spanish. Also used as keys for dynamic strings.
    const ES = {
        // Navigation and footer
        "Home": "Inicio",
        "Scanner": "Escáner",
        "History": "Historial",
        "Learn": "Aprender",
        "Scan a Message": "Escanear un mensaje",
        "Think Before You Click. Stay Safe Online.": "Piensa antes de hacer clic. Mantente seguro en línea.",
        "© 2026 ScamShield AI. Built for a safer digital world.": "© 2026 ScamShield AI. Creado para un mundo digital más seguro.",
        "Skip to main content": "Saltar al contenido principal",
        "Language": "Idioma",
        "Español": "Español",

        // Home
        "YOUR DIGITAL SAFETY COMPANION": "TU COMPAÑERO DE SEGURIDAD DIGITAL",
        "Think Before": "Piensa",
        "You": "antes de",
        "Click.": "hacer clic.",
        "Not sure if that message is real or a scam? Let ScamShield AI help you spot suspicious messages, emails, and links before it's too late.": "¿No sabes si ese mensaje es real o una estafa? Deja que ScamShield AI te ayude a detectar mensajes, correos y enlaces sospechosos antes de que sea tarde.",
        "Check a Message": "Comprobar un mensaje",
        "Scan a QR code": "Escanear un código QR",
        "QUISHING DEFENSE": "DEFENSA CONTRA QUISHING",
        "Check a QR Code Without Opening It": "Comprueba un código QR sin abrirlo",
        "Upload a QR screenshot or use your camera. We decode it locally and show the destination exactly as written, so you can decide before anyone taps it.": "Sube una captura del QR o usa tu cámara. Lo decodificamos localmente y mostramos el destino tal como está escrito, para que decidas antes de que alguien lo abra.",
        "Learn About Scams": "Aprender sobre estafas",
        "Your safety starts with awareness.": "Tu seguridad empieza por la conciencia.",
        "SECURITY ASSISTANT": "ASISTENTE DE SEGURIDAD",
        "Stay One Step Ahead": "Un paso por delante",
        "Recognize warning signs before you interact with suspicious messages.": "Reconoce las señales de alerta antes de interactuar con mensajes sospechosos.",
        "Spot suspicious messages": "Detecta mensajes sospechosos",
        "Understand potential risks": "Entiende los riesgos potenciales",
        "Make safer online decisions": "Toma decisiones más seguras en línea",
        "Scam awareness made simple": "Concienciación contra estafas, de forma sencilla",
        "MESSAGE ANALYSIS": "ANÁLISIS DE MENSAJES",
        "Something Doesn't Look Right?": "¿Algo no te cuadra?",
        "Paste a suspicious message or upload a file, and let ScamShield help you examine it.": "Pega un mensaje sospechoso o sube un archivo y deja que ScamShield lo examine.",
        "Paste your message here": "Pega tu mensaje aquí",
        "Paste a suspicious text message, email, or other content here...": "Pega aquí un mensaje de texto, correo u otro contenido sospechoso...",
        "Upload File": "Subir archivo",
        "Analyze Message": "Analizar mensaje",
        "Optional AI second opinion": "Segunda opinión opcional con IA",
        "I consent to sending this message text (or extracted text) to the AI provider configured by this site. The provider may retain or review prompts under its terms. Never send passwords, codes, or payment details.": "Doy mi consentimiento para enviar este texto (o el texto extraído) al proveedor de IA configurado por este sitio. El proveedor puede conservar o revisar las solicitudes según sus términos. Nunca envíes contraseñas, códigos ni datos de pago.",
        "— I consent to sending this message text (or extracted text) to the AI provider configured by this site. The provider may retain or review prompts under its terms. Never send passwords, codes, or payment details.": "— Doy mi consentimiento para enviar este texto (o el texto extraído) al proveedor de IA configurado por este sitio. El proveedor puede conservar o revisar las solicitudes según sus términos. Nunca envíes contraseñas, códigos ni datos de pago.",
        "Local analysis stays in your browser. Files are not uploaded; only extracted text is sent when you opt in to AI.": "El análisis local se queda en tu navegador. Los archivos no se suben; solo se envía el texto extraído cuando aceptas usar la IA.",
        "SIMPLE. SMART. SECURE.": "SIMPLE. INTELIGENTE. SEGURO.",
        "How ScamShield Works": "Cómo funciona ScamShield",
        "Three simple steps toward safer online interactions.": "Tres pasos sencillos hacia interacciones más seguras.",
        "Submit": "Envía",
        "Paste a suspicious message or upload a file or screenshot for review.": "Pega un mensaje sospechoso o sube un archivo o captura para revisarlo.",
        "Analyze": "Analizar",
        "Our analysis system examines potential warning signs and suspicious patterns.": "Nuestro sistema examina posibles señales de alerta y patrones sospechosos.",
        "Stay Protected": "Mantente protegido",
        "Understand potential risks and learn how to respond safely.": "Entiende los riesgos potenciales y aprende a responder de forma segura.",
        "STAY INFORMED. STAY PROTECTED.": "MANTENTE INFORMADO. MANTENTE PROTEGIDO.",
        "Don't Let Scams Catch You Off Guard.": "No dejes que las estafas te sorprendan.",
        "Learn how to recognize suspicious messages and protect your digital identity.": "Aprende a reconocer mensajes sospechosos y a proteger tu identidad digital.",
        "Explore Safety Tips": "Explora consejos de seguridad",

        // Scanner page
        "Scan a Message or File": "Escanea un mensaje o archivo",
        "Upload a suspicious file or paste a message, and ScamShield AI will check it for scam warning signs.": "Sube un archivo sospechoso o pega un mensaje y ScamShield AI lo revisará en busca de señales de estafa.",
        "That scan couldn't be found — it may have been deleted from your history.": "No se encontró ese escaneo; puede que se haya eliminado de tu historial.",
        "Upload files to scan": "Subir archivos para escanear",
        "Drop files here or": "Arrastra archivos aquí o",
        "browse": "examina",
        "Emails (.eml), PDFs, Word documents, screenshots, web pages, text files, archives, and more — up to 15 MB each.": "Correos (.eml), PDF, documentos de Word, capturas, páginas web, archivos de texto, comprimidos y más, hasta 15 MB cada uno.",
        "or paste a message": "o pega un mensaje",
        "Message text": "Texto del mensaje",
        "Try an example:": "Prueba un ejemplo:",
        "Package delivery": "Entrega de paquete",
        "Bank alert": "Alerta bancaria",
        "Prize claim": "Reclamo de premio",
        "Order shipped": "Pedido enviado",
        "Rule checks run locally. Only extracted text is sent to the AI provider if you opt in.": "Las comprobaciones se ejecutan localmente. Solo se envía el texto extraído al proveedor de IA si lo aceptas.",
        "Analyzing…": "Analizando…",
        "Looking for warning signs": "Buscando señales de alerta",
        "Scanning…": "Escaneando…",
        "Scan Results": "Resultados del escaneo",
        "Here's what ScamShield AI found in your {thing}.": "Esto es lo que ScamShield AI encontró en tu {thing}.",
        "Upload a suspicious file or paste a message, and ScamShield AI will check it for scam warning signs.": "Sube un archivo sospechoso o pega un mensaje y ScamShield AI lo revisará en busca de señales de estafa.",
        "file": "archivo",
        "message": "mensaje",
        "QR code": "código QR",
        "only the file type will be checked": "solo se comprobará el tipo de archivo",
        "Remove file": "Quitar archivo",
        "From: {sender}": "De: {sender}",
        "Please enter a message or upload a file first.": "Introduce un mensaje o sube un archivo primero.",
        "Please paste a message or upload a file first.": "Pega un mensaje o sube un archivo primero.",
        "Analyzing…": "Analizando…",
        "Something went wrong while scanning. Please try again.": "Algo salió mal durante el escaneo. Inténtalo de nuevo.",
        "Selected file: {name}": "Archivo seleccionado: {name}",
        "Selected files: {names}": "Archivos seleccionados: {names}",
        "Private scan results are no longer available. Run the scan again; Privacy Mode does not retain them.": "Los resultados privados ya no están disponibles. Repite el escaneo; el modo privado no los conserva.",

        // Results
        "Potential Scam Detected": "Posible estafa detectada",
        "Be Careful With This One": "Ten cuidado con esto",
        "No Major Red Flags Found": "No se encontraron señales importantes",
        "Multiple Scam Warning Signs": "Varias señales de estafa",
        "Some Warning Signs — Verify First": "Algunas señales de alerta — verifica primero",
        "No Major Warning Signs Found": "No se encontraron señales de alerta importantes",
        "High Risk": "Riesgo alto",
        "Medium Risk": "Riesgo medio",
        "Low Risk": "Riesgo bajo",
        "This {thing} shows several tactics often used in scams. Pause before you reply, pay, or click.": "Este {thing} muestra varias tácticas habituales en estafas. Pausa antes de responder, pagar o hacer clic.",
        "This {thing} has some warning signs. Verify it through an official channel before you act.": "Este {thing} tiene algunas señales de alerta. Verifícalo por un canal oficial antes de actuar.",
        "We didn't find major warning signs in this {thing}. Stay cautious if it was unexpected.": "No encontramos señales de alerta importantes en este {thing}. Mantén la cautela si no lo esperabas.",
        "This {thing} contains multiple suspicious indicators commonly used in scams.": "Este {thing} contiene varias señales sospechosas habituales en estafas.",
        "This {thing} has some suspicious characteristics. Verify it before you act.": "Este {thing} tiene algunas características sospechosas. Verifícalo antes de actuar.",
        "We didn't find significant warning signs in this {thing}. Still be cautious.": "No encontramos señales de alerta importantes en este {thing}. Aun así, mantén la cautela.",
        "Initial Triage: {level}": "Triaje inicial: {level}",
        "AI Second Opinion: {level}": "Segunda opinión de IA: {level}",
        "Initial Triage · local rules and model": "Triaje inicial · reglas y modelo locales",
        "AI Second Opinion": "Segunda opinión de IA",
        "Initial Triage · heuristic risk indicator, not a calibrated probability": "Triaje inicial · indicador heurístico de riesgo, no una probabilidad calibrada",
        "AI heuristic risk indicator · not a calibrated probability": "Indicador heurístico de riesgo de IA · no es una probabilidad calibrada",
        "Heuristic risk indicator · not a calibrated probability": "Indicador heurístico de riesgo · no es una probabilidad calibrada",
        "Local heuristic score:": "Puntuación heurística local:",
        "/100 · not a calibrated probability": "/100 · no es una probabilidad calibrada",
        "Rule checks run locally. Only extracted text is sent to the configured AI provider if you opt in.": "Las comprobaciones se ejecutan localmente. Solo se envía el texto extraído al proveedor de IA configurado si lo aceptas.",
        "contributes {weight} points": "aporta {weight} puntos",
        "Rule score: {score}/100 — a heuristic sum of the signals shown, not a calibrated probability.": "Puntuación por reglas: {score}/100 — una suma heurística de las señales mostradas, no una probabilidad calibrada.",
        "The statistical text model matched this message.": "El modelo estadístico de texto coincidió con este mensaje.",
        "The statistical text model did not match this message.": "El modelo estadístico de texto no coincidió con este mensaje.",
        "low confidence": "confianza baja",
        "medium confidence": "confianza media",
        "high confidence": "confianza alta",
        "Analysis language: {lang}": "Idioma del análisis: {lang}",
        "English": "inglés",
        "Spanish": "español",
        "Hindi": "hindi",
        "Mandarin": "mandarín",
        "Interface language: {lang}": "Idioma de la interfaz: {lang}",
        "Why Was This Flagged?": "¿Por qué se marcó?",
        "Initial Triage Signals": "Señales del triaje inicial",
        "Initial Triage Checks": "Comprobaciones del triaje inicial",
        "No pressure or urgent language": "Sin lenguaje urgente ni presión",
        "No request for money, gift cards, or card details": "Sin petición de dinero, tarjetas regalo o datos de tarjeta",
        "No request for passwords or personal information": "Sin petición de contraseñas o información personal",
        "Links didn't match known scam patterns": "Los enlaces no coincidieron con patrones de estafa conocidos",
        "No links found": "No se encontraron enlaces",
        "Show {count} more warning signs": "Mostrar {count} señales de alerta más",
        "Show {count} more warning sign": "Mostrar {count} señal de alerta más",
        "Show fewer": "Mostrar menos",
        "Matched text:": "Texto coincidente:",
        "What to do:": "Qué hacer:",
        "Matched a statistical pattern in the local model. This is not a quote and is not proof of a scam.": "Coincide con un patrón estadístico del modelo local. No es una cita ni una prueba de estafa.",
        "Assessment confidence:": "Confianza de la evaluación:",
        "Context questions": "Preguntas de contexto",
        "Recommendation:": "Recomendación:",
        "Only the first 12,000 characters were sent for AI review.": "Solo se enviaron los primeros 12.000 caracteres para la revisión con IA.",
        "AI can be wrong. Treat this as a second opinion, not proof or a calibrated probability.": "La IA puede equivocarse. Trátalo como una segunda opinión, no como una prueba ni una probabilidad calibrada.",
        "The AI replied in {language}.": "La IA respondió en {language}.",
        "Suggested Actions": "Acciones sugeridas",
        "Initial Triage Actions": "Acciones del triaje inicial",
        "Message Analyzed": "Mensaje analizado",
        "File Analyzed": "Archivo analizado",
        "QR Code Analyzed": "Código QR analizado",
        "No readable text.": "No hay texto legible.",
        "… (shortened)": "… (acortado)",
        "Risk Level Guide": "Guía de niveles de riesgo",
        "Strong indicators of a potential scam.": "Indicadores fuertes de una posible estafa.",
        "Some suspicious characteristics. Proceed with caution and verify.": "Algunas características sospechosas. Procede con cautela y verifica.",
        "No significant warning signs identified. Still be cautious.": "No se identificaron señales de alerta importantes. Aun así, mantén la cautela.",
        "Scan Another Message": "Escanear otro mensaje",
        "Scanned {date}": "Escaneado {date}",
        "Quoted evidence:": "Evidencia citada:",
        "{count} items scanned": "{count} elementos escaneados",
        "Pasted message": "Mensaje pegado",
        "QR destination (not opened)": "Destino del QR (no abierto)",
        "This destination was decoded on your device and was not opened.": "Este destino se decodificó en tu dispositivo y no se abrió.",
        "QR checks use local rules only. No QR content is sent to the AI provider.": "Las comprobaciones de QR usan solo reglas locales. No se envía contenido del QR al proveedor de IA.",
        "Website": "Sitio web",
        "Email address": "Correo electrónico",
        "Phone number": "Número de teléfono",
        "SMS": "SMS",
        "Wi-Fi network": "Red Wi-Fi",
        "Contact card": "Tarjeta de contacto",
        "Location": "Ubicación",
        "Crypto payment": "Pago con criptomonedas",
        "Dangerous link": "Enlace peligroso",
        "Plain text": "Texto plano",
        "Empty": "Vacío",

        // QR tool
        "QR CHECK": "COMPROBACIÓN DE QR",
        "Scan a QR code safely": "Escanea un código QR de forma segura",
        "Upload a screenshot or use your camera. The code is decoded on this device; we show the destination but never open it.": "Sube una captura o usa la cámara. El código se decodifica en este dispositivo; mostramos el destino pero nunca lo abrimos.",
        "Use camera": "Usar cámara",
        "Upload QR image": "Subir imagen de QR",
        "Stop camera": "Detener cámara",
        "Point the camera at a QR code. It is scanned on this device.": "Apunta la cámara a un código QR. Se escanea en este dispositivo.",
        "Camera access was blocked. You can upload a screenshot instead.": "Se bloqueó el acceso a la cámara. Puedes subir una captura en su lugar.",
        "No camera was found. You can upload a screenshot instead.": "No se encontró ninguna cámara. Puedes subir una captura en su lugar.",
        "This browser does not support camera capture. You can upload a screenshot instead.": "Este navegador no admite la captura con cámara. Puedes subir una captura en su lugar.",
        "Looking for a QR code…": "Buscando un código QR…",
        "No QR code was found. Try a sharper, closer screenshot or better lighting.": "No se encontró ningún código QR. Prueba con una captura más nítida y cercana o con mejor iluminación.",
        "That image is too large. Use one under 15 MB.": "Esa imagen es demasiado grande. Usa una de menos de 15 MB.",
        "The image could not be read.": "No se pudo leer la imagen.",
        "A QR code was found, but it is empty.": "Se encontró un código QR, pero está vacío.",
        "Decoded destination (not opened)": "Destino decodificado (no abierto)",
        "Copy destination": "Copiar destino",
        "Copied": "Copiado",
        "Check this destination": "Comprobar este destino",
        "Checking the destination locally…": "Comprobando el destino localmente…",
        "The QR code is still being read.": "El código QR todavía se está leyendo.",
        "Decoding happens on this device. Nothing is uploaded and the destination is never opened automatically.": "La decodificación ocurre en este dispositivo. No se sube nada y el destino nunca se abre automáticamente.",

        // History
        "SCAN HISTORY": "HISTORIAL DE ESCANEOS",
        "Your Scan History": "Tu historial de escaneos",
        "Review your previous message analyses and stay informed.": "Revisa tus análisis anteriores y mantente informado.",
        "Total Scans": "Escaneos totales",
        "Previous Analyses": "Análisis anteriores",
        "Search your scans...": "Buscar en tus escaneos...",
        "Search your scans": "Buscar en tus escaneos",
        "All Risk Levels": "Todos los niveles de riesgo",
        "Filter by risk level": "Filtrar por nivel de riesgo",
        "No scans yet": "Aún no hay escaneos",
        "No matching scans": "No hay escaneos coincidentes",
        "Messages and files you scan will appear here so you can review them later.": "Los mensajes y archivos que escanees aparecerán aquí para que puedas revisarlos más tarde.",
        "Try a different search or risk level.": "Prueba otra búsqueda u otro nivel de riesgo.",
        "Scan your first message": "Escanea tu primer mensaje",
        "Showing {start}–{end} of {count} scans": "Mostrando {start}–{end} de {count} escaneos",
        "Showing 0 of 0 scans": "Mostrando 0 de 0 escaneos",
        "Clear history": "Borrar historial",
        "Click again to clear all": "Haz clic de nuevo para borrar todo",
        "Scan deleted": "Escaneo eliminado",
        "History cleared": "Historial borrado",
        "Undo": "Deshacer",
        "View Results": "Ver resultados",
        "Delete scan": "Eliminar escaneo",
        "Previous page": "Página anterior",
        "Next page": "Página siguiente",
        "No readable text": "No hay texto legible",
        "Risk Score:": "Puntuación de riesgo:",

        // Learn
        "KNOWLEDGE IS YOUR BEST DEFENSE": "EL CONOCIMIENTO ES TU MEJOR DEFENSA",
        "Stay Informed.": "Mantente informado.",
        "Stay Protected.": "Mantente protegido.",
        "Scams are becoming harder to recognize. Learn about common online threats, identify warning signs, and discover ways to protect yourself.": "Cada vez es más difícil reconocer las estafas. Aprende sobre amenazas comunes, identifica señales de alerta y descubre cómo protegerte.",
        "Explore Common Scams": "Explorar estafas comunes",
        "Awareness is the first step toward online safety.": "La conciencia es el primer paso hacia la seguridad en línea.",
        "SAFETY GUIDE": "GUÍA DE SEGURIDAD",
        "Think Before You Trust": "Piensa antes de confiar",
        "Knowing what to look for can help you avoid suspicious online activity.": "Saber qué buscar te ayuda a evitar actividad sospechosa en línea.",
        "Recognize scam tactics": "Reconoce tácticas de estafa",
        "Protect personal information": "Protege tu información personal",
        "Browse with confidence": "Navega con confianza",
        "Stay alert. Stay secure.": "Mantente alerta. Mantente seguro.",
        "KNOW WHAT TO LOOK FOR": "SABE QUÉ BUSCAR",
        "Common Types of Scams": "Tipos comunes de estafas",
        "Explore some of the most common ways scammers attempt to deceive people.": "Explora algunas de las formas más comunes en que los estafadores intentan engañar a las personas.",
        "Phishing Scams": "Estafas de phishing",
        "Fraudulent emails or messages designed to steal personal information, passwords, or financial details.": "Correos o mensajes fraudulentos diseñados para robar información personal, contraseñas o datos financieros.",
        "Text Message Scams": "Estafas por mensaje de texto",
        "Suspicious text messages that may pretend to come from banks, delivery services, or government agencies.": "Mensajes sospechosos que pueden hacerse pasar por bancos, servicios de entrega o organismos públicos.",
        "Fake Websites": "Sitios web falsos",
        "Websites created to imitate legitimate businesses and trick visitors into sharing sensitive information.": "Sitios creados para imitar empresas legítimas y engañar a los visitantes para que compartan información sensible.",
        "Prize and Giveaway Scams": "Estafas de premios y sorteos",
        "Messages claiming you have won a prize but requiring payment or personal information to claim it.": "Mensajes que afirman que has ganado un premio pero exigen un pago o datos personales para reclamarlo.",
        "Romance Scams": "Estafas románticas",
        "Scammers create fake online relationships to build trust and eventually request money or financial assistance.": "Los estafadores crean relaciones falsas en línea para ganar confianza y finalmente pedir dinero o ayuda económica.",
        "Job Scams": "Estafas de empleo",
        "Fake employment opportunities that may request upfront payments or sensitive personal information.": "Ofertas de empleo falsas que pueden pedir pagos por adelantado o información personal sensible.",
        "SPOT THE RED FLAGS": "DETECTA LAS SEÑALES",
        "Warning Signs of a Scam": "Señales de alerta de una estafa",
        "Be cautious when a message includes any of these common warning signs.": "Ten cuidado cuando un mensaje incluya alguna de estas señales habituales.",
        "Urgent language:": "Lenguaje urgente:",
        "Messages pressuring you to act immediately.": "Mensajes que te presionan para actuar de inmediato.",
        "Unexpected links:": "Enlaces inesperados:",
        "Links asking you to log in or provide personal information.": "Enlaces que te piden iniciar sesión o dar información personal.",
        "Requests for payment:": "Peticiones de pago:",
        "Unexpected demands for money, gift cards, or cryptocurrency.": "Exigencias inesperadas de dinero, tarjetas regalo o criptomonedas.",
        "Suspicious senders:": "Remitentes sospechosos:",
        "Unfamiliar email addresses, phone numbers, or accounts.": "Direcciones de correo, teléfonos o cuentas desconocidas.",
        "Too good to be true:": "Demasiado bueno para ser verdad:",
        "Offers promising unrealistic rewards or guaranteed results.": "Ofertas que prometen recompensas poco realistas o resultados garantizados.",
        "PROTECT YOURSELF": "PROTÉGETE",
        "Simple Ways to Stay Safe": "Formas sencillas de mantenerte seguro",
        "Build safer online habits with these simple precautions.": "Crea hábitos más seguros con estas sencillas precauciones.",
        "Verify Before You Click": "Verifica antes de hacer clic",
        "Check website addresses and sender information before opening links or attachments.": "Comprueba las direcciones web y los remitentes antes de abrir enlaces o adjuntos.",
        "Protect Your Information": "Protege tu información",
        "Never share passwords, verification codes, or sensitive financial information with unknown sources.": "Nunca compartas contraseñas, códigos de verificación ni información financiera sensible con fuentes desconocidas.",
        "Take Your Time": "Tómate tu tiempo",
        "Do not let unexpected messages pressure you into making rushed decisions.": "No dejes que los mensajes inesperados te presionen para tomar decisiones apresuradas.",
        "PUT YOUR KNOWLEDGE TO THE TEST": "PON A PRUEBA TUS CONOCIMIENTOS",
        "Not Sure About a Message?": "¿No estás seguro de un mensaje?",
        "Let ScamShield AI help you examine suspicious messages and identify potential warning signs.": "Deja que ScamShield AI te ayude a examinar mensajes sospechosos e identificar posibles señales de alerta.",

        // Escalation (new section)
        "IF SOMETHING HAS ALREADY HAPPENED": "SI YA HA PASADO ALGO",
        "Get help quickly": "Busca ayuda rápidamente",
        "A scan is only advice. If you shared information, paid, or feel unsafe, act now and contact a real person.": "Un escaneo solo es un consejo. Si compartiste información, pagaste o te sientes en peligro, actúa ahora y contacta con una persona real.",
        "Campus IT or security": "TI o seguridad del campus",
        "Use your institution's published IT/security help-desk contact. Add the correct local number here before using this demo with real users.": "Usa el contacto publicado del servicio de TI o seguridad de tu institución. Añade aquí el número local correcto antes de usar esta demo con personas reales.",
        "Account or password": "Cuenta o contraseña",
        "Change the password from the official app or website, turn on two-step verification, and sign out other devices. If a code was shared, change the password again.": "Cambia la contraseña desde la app o el sitio oficial, activa la verificación en dos pasos y cierra la sesión en otros dispositivos. Si compartiste un código, vuelve a cambiar la contraseña.",
        "Payment or gift card": "Pago o tarjeta regalo",
        "Contact your bank or card issuer immediately and ask to stop or reverse the payment. Report gift-card codes to the card issuer; once used, they are usually hard to recover.": "Contacta de inmediato con tu banco o emisor de la tarjeta y pide detener o revertir el pago. Reporta los códigos de tarjetas regalo al emisor; una vez usados, suelen ser difíciles de recuperar.",
        "Personal safety": "Seguridad personal",
        "If someone threatens you or you feel in immediate danger, contact local emergency services. Do not meet someone or go to a location because a message told you to.": "Si alguien te amenaza o sientes peligro inmediato, contacta con los servicios de emergencia locales. No quedes con nadie ni vayas a un lugar porque un mensaje te lo indique.",
        "Where to report": "Dónde reportar",
        "Reporting routes differ by country. These are examples, not universal instructions.": "Las vías de reporte varían según el país. Estos son ejemplos, no instrucciones universales.",
        "United States": "Estados Unidos",
        "Forward suspicious SMS to 7726. Report fraud at reportfraud.ftc.gov and identity theft at identitytheft.gov.": "Reenvía los SMS sospechosos al 7726. Reporta fraude en reportfraud.ftc.gov y robo de identidad en identitytheft.gov.",
        "Spain": "España",
        "Report to INCIBE (017) or the Guardia Civil / Policía Nacional. Your bank can also block cards and payments.": "Reporta a INCIBE (017) o a la Guardia Civil / Policía Nacional. Tu banco también puede bloquear tarjetas y pagos.",
        "United Kingdom": "Reino Unido",
        "Forward suspicious emails to report@phishing.gov.uk and report fraud to Action Fraud.": "Reenvía correos sospechosos a report@phishing.gov.uk y reporta fraude a Action Fraud.",
        "Elsewhere": "Otros países",
        "Search for your national cyber-security or consumer-protection authority and your bank's official fraud number.": "Busca la autoridad nacional de ciberseguridad o protección al consumidor y el número oficial de fraude de tu banco.",
        "This demo is not an emergency service and cannot monitor your accounts.": "Esta demo no es un servicio de emergencia y no puede vigilar tus cuentas.",

        // Age gate and privacy
        "Before using the scanner": "Antes de usar el escáner",
        "This scanner includes an optional AI feature. Confirm that you are 18 or older to continue. If you are under 18, scanner access is blocked.": "Este escáner incluye una función opcional de IA. Confirma que tienes 18 años o más para continuar. Si eres menor de 18, el acceso al escáner está bloqueado.",
        "This is a self-attestation, not identity or age verification. Check the configured provider's current terms and your app's audience before enabling AI review.": "Esto es una autodeclaración, no una verificación de identidad ni de edad. Comprueba los términos actuales del proveedor configurado y el público de tu app antes de activar la revisión con IA.",
        "I confirm I am 18 or older": "Confirmo que tengo 18 años o más",
        "I am under 18": "Soy menor de 18",
        "Visit safety resources": "Ver recursos de seguridad",
        "Saving your confirmation…": "Guardando tu confirmación…",
        "Could not save your confirmation. Scanner access remains blocked.": "No se pudo guardar tu confirmación. El acceso al escáner sigue bloqueado.",
        "Scanner access is unavailable because you did not confirm that you are 18 or older.": "El acceso al escáner no está disponible porque no confirmaste que tienes 18 años o más.",
        "The server session could not be verified. Scanner access remains blocked until the server is available.": "No se pudo verificar la sesión del servidor. El acceso al escáner sigue bloqueado hasta que el servidor esté disponible.",
        "Privacy Mode": "Modo privado",
        "Do not save new scan text to local history. Private results use a one-time tab transfer and are removed after loading.": "No guardes el texto de los nuevos escaneos en el historial local. Los resultados privados usan una transferencia única entre pestañas y se eliminan al cargarse.",
        "Could not update Privacy Mode.": "No se pudo actualizar el modo privado.",
        "AI consent could not be saved; local scanning remains available.": "No se pudo guardar el consentimiento de IA; el escaneo local sigue disponible.",
        "Confirm that you are 18 or older first.": "Confirma primero que tienes 18 años o más.",

        // Providers and errors
        "Gemini AI Second Opinion": "Segunda opinión de IA",
        "The AI provider returned an incomplete review.": "El proveedor de IA devolvió una revisión incompleta.",
        "The AI provider could not be reached. Local rule analysis is still available.": "No se pudo contactar con el proveedor de IA. El análisis local sigue disponible.",
        "AI review is unavailable.": "La revisión con IA no está disponible.",

        // Dynamic result fragments
        "contains multiple suspicious indicators commonly used in scams.": "contiene varias señales sospechosas habituales en estafas.",
        "has some suspicious characteristics.": "tiene algunas características sospechosas."
    };

    const HI = window.ScamShieldI18nHi || {};
    const ZH = window.ScamShieldI18nZh || {};
    const DICTS = { es: ES, hi: HI, zh: ZH };
    const LANGUAGE_NAMES = { en: "English", es: "Español", hi: "हिंदी", zh: "中文" };

    const ES_ATTRS = {
        "placeholder": {
            "Paste a suspicious text message, email, or other content here...": "Pega aquí un mensaje de texto, correo u otro contenido sospechoso...",
            "Search your scans...": "Buscar en tus escaneos..."
        },
        "aria-label": {
            "Upload files to scan": "Subir archivos para escanear",
            "Search your scans": "Buscar en tus escaneos",
            "Filter by risk level": "Filtrar por nivel de riesgo",
            "Scan summary": "Resumen de escaneos",
            "Pages": "Páginas",
            "Language": "Idioma"
        }
    };

    const HI_ATTRS = {
        "placeholder": {
            "Paste a suspicious text message, email, or other content here...": "कोई संदिग्ध टेक्स्ट संदेश, ईमेल या अन्य सामग्री यहाँ पेस्ट करें...",
            "Search your scans...": "अपने स्कैन खोजें..."
        },
        "aria-label": {
            "Upload files to scan": "स्कैन करने के लिए फ़ाइलें अपलोड करें",
            "Search your scans": "अपने स्कैन खोजें",
            "Filter by risk level": "जोखिम स्तर से फ़िल्टर करें",
            "Scan summary": "स्कैन सारांश",
            "Pages": "पृष्ठ",
            "Language": "भाषा"
        }
    };

    const ZH_ATTRS = {
        "placeholder": {
            "Paste a suspicious text message, email, or other content here...": "在此粘贴可疑短信、电子邮件或其他内容...",
            "Search your scans...": "搜索您的扫描记录..."
        },
        "aria-label": {
            "Upload files to scan": "上传要扫描的文件",
            "Search your scans": "搜索您的扫描记录",
            "Filter by risk level": "按风险等级筛选",
            "Scan summary": "扫描摘要",
            "Pages": "页面",
            "Language": "语言"
        }
    };

    const ATTRS = { es: ES_ATTRS, hi: HI_ATTRS, zh: ZH_ATTRS };

    const originalTitle = document.title;

    const ES_TITLES = {
        "ScamShield AI | Think Before You Click": "ScamShield AI | Piensa antes de hacer clic",
        "Scanner | ScamShield AI": "Escáner | ScamShield AI",
        "Learn About Scams | ScamShield AI": "Aprende sobre estafas | ScamShield AI",
        "Scan History | ScamShield AI": "Historial de escaneos | ScamShield AI"
    };

    const HI_TITLES = {
        "ScamShield AI | Think Before You Click": "ScamShield AI | क्लिक करने से पहले सोचें",
        "Scanner | ScamShield AI": "स्कैनर | ScamShield AI",
        "Learn About Scams | ScamShield AI": "घोटालों के बारे में जानें | ScamShield AI",
        "Scan History | ScamShield AI": "स्कैन इतिहास | ScamShield AI"
    };

    const ZH_TITLES = {
        "ScamShield AI | Think Before You Click": "ScamShield AI | 点击前先思考",
        "Scanner | ScamShield AI": "扫描器 | ScamShield AI",
        "Learn About Scams | ScamShield AI": "了解诈骗 | ScamShield AI",
        "Scan History | ScamShield AI": "扫描历史 | ScamShield AI"
    };

    const TITLES = { es: ES_TITLES, hi: HI_TITLES, zh: ZH_TITLES };

    let lang = "en";

    function normalize(value) {
        const text = String(value || "").trim().toLowerCase();
        if (/^(zh|cmn|chinese|mandarin)\b/.test(text) || /^zh-/.test(text)) return "zh";
        if (/^(hi|hin|hindi)\b/.test(text) || text === "हिंदी" || text === "हिन्दी") return "hi";
        if (/^(es|spa|spanish)\b/.test(text) || text === "español") return "es";
        return "en";
    }

    function initialLanguage() {
        try {
            const params = new URLSearchParams(window.location.search);
            const requested = normalize(params.get("lang"));
            if (params.get("lang")) return requested;
            const stored = normalize(window.localStorage.getItem(STORAGE_KEY));
            if (window.localStorage.getItem(STORAGE_KEY)) return stored;
        } catch (_error) { /* ignore */ }
        return "en";
    }

    function fill(template, vars) {
        return String(template == null ? "" : template).replace(/\{(\w+)\}/g, function (_, key) {
            return vars && vars[key] != null ? String(vars[key]) : "";
        });
    }

    function translate(english, vars) {
        const dictionary = DICTS[lang];
        const value = dictionary && Object.prototype.hasOwnProperty.call(dictionary, english) ? dictionary[english] : english;
        return fill(value, vars);
    }

    function translateNode(node) {
        if (!node || node.nodeType !== 3) return;
        const parent = node.parentElement;
        if (!parent || /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/.test(parent.tagName)) return;
        if (!node.__ssOriginal) node.__ssOriginal = node.nodeValue;
        const original = node.__ssOriginal;
        const match = /^(\s*)([\s\S]*?)(\s*)$/.exec(original);
        if (!match || !match[2]) return;
        const key = match[2].replace(/\s+/g, " ");
        node.nodeValue = match[1] + translate(key) + match[3];
    }

    function applyAttributes(root) {
        const attrs = ["placeholder", "aria-label", "title"];
        attrs.forEach(function (attr) {
            const selector = "[" + attr + "]";
            const nodes = root.querySelectorAll ? root.querySelectorAll(selector) : [];
            nodes.forEach(function (element) {
                const storeKey = "ssOriginal" + attr.replace(/-/g, "");
                if (!element.dataset[storeKey]) element.dataset[storeKey] = element.getAttribute(attr);
                const original = element.dataset[storeKey];
                const map = (ATTRS[lang] && ATTRS[lang][attr]) || {};
                element.setAttribute(attr, map[original] || original);
            });
        });
    }

    function apply(root) {
        const scope = root || document.body;
        if (!scope) return;
        if (scope.nodeType === 3) {
            translateNode(scope);
            return;
        }
        const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, null);
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        nodes.forEach(translateNode);
        applyAttributes(scope);
        if (scope === document.body) {
            const titles = TITLES[lang] || {};
            document.title = titles[originalTitle] || originalTitle;
        }
    }

    function updateSwitchers() {
        document.querySelectorAll("[data-lang-switch]").forEach(function (group) {
            group.setAttribute("aria-label", translate("Language"));
            group.querySelectorAll("button[data-lang]").forEach(function (button) {
                const active = button.getAttribute("data-lang") === lang;
                button.setAttribute("aria-pressed", active ? "true" : "false");
                button.classList.toggle("active", active);
            });
        });
    }

    function createSwitcher(className) {
        const group = document.createElement("div");
        group.className = "lang-switch" + (className ? " " + className : "");
        group.setAttribute("data-lang-switch", "");
        group.setAttribute("role", "group");
        group.setAttribute("aria-label", "Language");
        [["en", "EN"], ["es", "ES"], ["hi", "HI"], ["zh", "中文"]].forEach(function (pair) {
            const button = document.createElement("button");
            button.type = "button";
            button.setAttribute("data-lang", pair[0]);
            button.textContent = pair[1];
            button.setAttribute("aria-label", LANGUAGE_NAMES[pair[0]]);
            button.addEventListener("click", function () { setLang(pair[0]); });
            group.appendChild(button);
        });
        return group;
    }

    function injectSwitchers() {
        document.querySelectorAll(".nav-links").forEach(function (nav) {
            if (nav.querySelector("[data-lang-switch]")) return;
            nav.appendChild(createSwitcher());
        });
    }

    function setLang(next) {
        const value = normalize(next);
        if (SUPPORTED.indexOf(value) < 0) return;
        lang = value;
        document.documentElement.lang = value;
        try { window.localStorage.setItem(STORAGE_KEY, value); } catch (_error) { /* ignore */ }
        apply(document.body);
        updateSwitchers();
        try {
            window.dispatchEvent(new CustomEvent("scamshield:langchange", { detail: { lang: value } }));
        } catch (_error) { /* ignore */ }
    }

    function current() {
        return lang;
    }

    window.ScamShieldI18n = {
        get lang() { return lang; },
        supported: SUPPORTED.slice(),
        current: current,
        setLang: setLang,
        translate: translate,
        t: translate,
        apply: apply,
        createSwitcher: createSwitcher
    };

    lang = initialLanguage();
    document.documentElement.lang = lang;

    function boot() {
        injectSwitchers();
        apply(document.body);
        updateSwitchers();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
