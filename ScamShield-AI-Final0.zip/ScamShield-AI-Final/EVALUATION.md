# Bilingual evaluation

This is a small, **test-only** smoke evaluation of the browser scanner. It exists to make false positives, false negatives, and language gaps visible before a demo. It is not a performance claim.

## Dataset and separation

- File: `test/fixtures/eval_bilingual_holdout.json`
- 40 synthetic messages: 20 English and 20 Spanish, with 10 suspicious and 10 benign examples per language.
- Every example is marked `"split": "test"`; the file is marked `"usage": "evaluation_only"`. `evaluate_bilingual.js` refuses input that is not test-only.
- The examples were written down after the current model and rule set were frozen. They were not used to fit or tune either one.
- Labels describe the presence of common scam tactics, not whether a message was written by AI and not whether a real fraud occurred.

The set is hand-authored and tiny, so the authors' knowledge of the product can inflate the results. A result of 20 examples per language also has wide uncertainty. Replace this set with independently labeled, consented, representative messages before using any number in outreach or a report.

## Reproduce

```powershell
node evaluate_bilingual.js
```

The command prints aggregate metrics and the IDs of misclassified examples. It never prints message text and does not change any file. If this set is later used to tune rules or thresholds, it is no longer a holdout and must be replaced before reporting again.

## Results (2026-11-14)

Medium triage flags a message at a heuristic score of 40 or more.

| Slice | Precision | Recall | False-positive rate | TP / FP / FN / TN |
| --- | --- | --- | --- | --- |
| English, initial triage | 81.8% | 90.0% | 20.0% | 9 / 2 / 1 / 8 |
| Spanish, initial triage | 80.0% | 80.0% | 20.0% | 8 / 2 / 2 / 8 |
| Overall, initial triage | 81.0% | 85.0% | 20.0% | 17 / 4 / 3 / 16 |
| English, learned model only | 87.5% | 70.0% | 10.0% | 7 / 1 / 3 / 9 |
| Spanish, learned model only | — | 0.0% | 0.0% | 0 / 0 / 10 / 10 |

The false-positive rate is `FP / (FP + TN)`. Precision, recall, and FPR on 10–20 examples are unstable; approximate 95% Wilson intervals are roughly:

- Overall precision 60–92%, recall 64–95%, FPR 8–42%.
- English precision 52–95%, recall 60–98%, FPR 6–51%.
- Spanish precision and recall 49–94%, FPR 6–51%.

These intervals are wide enough that the English and Spanish results should be treated as inconclusive, not ranked against each other.

### What the errors show

Initial-triage false positives: `en-017`, `en-020`, `es-017`, `es-020`. These are a benign congratulations message and a legitimate verification-code notice in each language. The learned model matched them and the current design lifts a model match to a medium floor of 44. This is a real false-positive risk for routine "congratulations" and one-time-code messages.

Initial-triage false negatives: `en-007`, `es-006`, `es-007`. Each contains one plausible tactic (an investment promise or a family-emergency request) but does not reach 40. Single-signal messages can therefore remain low. This is the intended cautious behavior, but it is a recall limitation, not a clean bill of health.

Spanish learned-model recall is 0/10: the model is trained on English SMS text and does not generalize to Spanish. Spanish triage comes from the local bilingual rules, not from the learned model. The interface, rule explanations, and actions have been translated, but no native reviewer has validated the Spanish wording in this environment.

Hindi and Mandarin are not represented in this holdout at all. Their interface, rule, explanation, and action translations pass key-alignment and placeholder checks, and browser smoke tests show localized analysis, but no detection metrics and no native review exist for either language. Until those exist, treat Hindi and Mandarin support as unvalidated translations backed by the same multilingual local rules, not as evaluated coverage.

## Honest interpretation

- The numeric score is a heuristic sum of visible signals, not a calibrated probability that a message is fraudulent.
- The system identifies scam tactics. It does not determine whether AI wrote a message.
- These rates do not establish real-world detection rates, especially for email, chat, OCR, or languages other than the small English/Spanish sample here.
- Hindi and Mandarin have no detection metrics; only translation coverage and browser localization were checked.
- A low score is not a verdict that a message is safe.
- Do not tune against this file and then present it as an independent holdout. If tuning is needed, create a separate development set, record every change, and evaluate on a fresh, independently labeled test set.

## Next evaluation steps

1. Recruit native English and Spanish reviewers to label a consented, stratified sample of real messages, including legitimate bank, delivery, workplace, family, and one-time-code messages.
2. Add a separate development set for error analysis and threshold work; never reuse the holdout for both.
3. Report precision, recall, and FPR with confidence intervals by language, channel, and message length.
4. Measure whether people make safer decisions with the tool, not just whether the classifier agrees with labels.
5. Keep provider-based AI results in a separate column so rule performance and model performance are never conflated.
