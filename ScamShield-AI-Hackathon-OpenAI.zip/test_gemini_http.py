import json
import logging

import pytest
import responses

from app import GEMINI_API_URL, app


@pytest.fixture
def client(tmp_path, monkeypatch):
    app.config["TESTING"] = True
    app.config["DATABASE_PATH"] = str(tmp_path / "integration.sqlite3")
    monkeypatch.setenv("AI_PROVIDER", "gemini")
    monkeypatch.setenv("GEMINI_API_KEY", "integration-test-key")
    test_client = app.test_client()
    assert test_client.post("/api/age-gate", json={"adult_confirmed": True}).status_code == 200
    assert test_client.post("/api/ai-consent", json={"consent": True}).status_code == 200
    return test_client


def provider_result(message):
    return {
        "risk_score": 74,
        "summary": "The message contains a suspicious payment request.",
        "explanation": "It asks for an unusual payment method.",
        "assessment_confidence": "medium",
        "confidence_reason": "The request is clear, but sender context is unknown.",
        "warning_signs": [{
            "description": "Unusual payment request",
            "quoted_evidence": message,
        }],
        "context_needed": ["Did you expect this request?"],
        "recommendation": "Verify using a trusted contact method.",
    }


def candidate_with_text(value):
    return {
        "candidates": [{
            "content": {
                "parts": [{"text": json.dumps(value)}],
            },
        }],
    }


def test_flask_request_completes_gemini_http_round_trip_and_enforces_schema(client):
    message = "Apple asked for a $5 Google giftcard"
    endpoint = GEMINI_API_URL.format(model="gemini-3.5-flash-lite")
    with responses.RequestsMock() as mocked:
        mocked.add(
            responses.POST,
            endpoint,
            json=candidate_with_text(provider_result(message)),
            status=200,
        )
        response = client.post("/api/analyze", json={"message": message})
        assert len(mocked.calls) == 1
        outbound = mocked.calls[0].request

    assert response.status_code == 200
    result = response.get_json()["analysis"]
    assert result["warning_signs"][0]["quoted_evidence"] == message
    assert result["risk_level"] == "High"
    assert outbound.headers["x-goog-api-key"] == "integration-test-key"
    assert "integration-test-key" not in outbound.url
    payload = json.loads(outbound.body)
    schema = payload["generationConfig"]["responseSchema"]
    assert schema["properties"]["warning_signs"]["items"]["required"] == [
        "description",
        "quoted_evidence",
    ]
    assert "Do not assess AI authorship" in payload["systemInstruction"]["parts"][0]["text"]
    assert "verbatim" in payload["contents"][0]["parts"][0]["text"]


@pytest.mark.parametrize(
    "provider_payload",
    [
        [],
        {"candidates": [{"content": {"parts": "not-a-list"}}]},
        {"candidates": [{"content": {"parts": [{"text": "not JSON"}]}}]},
        candidate_with_text({
            **provider_result("some other text"),
            "warning_signs": [{
                "description": "Unsupported warning",
                "quoted_evidence": "not in the submitted text",
            }],
        }),
        candidate_with_text({
            **provider_result("text"),
            "warning_signs": ["warning without required evidence"],
        }),
    ],
)
def test_malformed_provider_shapes_and_evidence_fail_gracefully(client, provider_payload):
    endpoint = GEMINI_API_URL.format(model="gemini-3.5-flash-lite")
    with responses.RequestsMock() as mocked:
        mocked.add(responses.POST, endpoint, json=provider_payload, status=200)
        response = client.post("/api/analyze", json={"message": "unique private input"})
        assert len(mocked.calls) == 1

    assert response.status_code == 502
    assert response.get_json()["error"] == (
        "Gemini returned an unusable response; local analysis is still available."
    )


def test_provider_failure_does_not_log_submitted_text(client, caplog):
    private_text = "PRIVATE-CONTENT-DO-NOT-LOG-4921"
    endpoint = GEMINI_API_URL.format(model="gemini-3.5-flash-lite")
    caplog.set_level(logging.WARNING)
    with responses.RequestsMock() as mocked:
        mocked.add(responses.POST, endpoint, status=503, json={"error": {"message": "offline"}})
        response = client.post("/api/analyze", json={"message": private_text})
        assert len(mocked.calls) == 1

    assert response.status_code == 502
    assert private_text not in caplog.text
