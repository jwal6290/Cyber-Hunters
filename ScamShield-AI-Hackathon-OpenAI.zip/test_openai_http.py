import json
import logging

import pytest
import responses

from app import OPENAI_API_URL, app


@pytest.fixture
def client(tmp_path, monkeypatch):
    app.config["TESTING"] = True
    app.config["DATABASE_PATH"] = str(tmp_path / "openai-integration.sqlite3")
    monkeypatch.setenv("AI_PROVIDER", "openai")
    monkeypatch.setenv("OPENAI_API_KEY", "integration-test-key")
    monkeypatch.setenv("OPENAI_MODEL", "gpt-4o-mini")
    test_client = app.test_client()
    assert test_client.post("/api/age-gate", json={"adult_confirmed": True}).status_code == 200
    assert test_client.post("/api/ai-consent", json={"consent": True}).status_code == 200
    return test_client


def analysis_for(message):
    return {
        "risk_score": 74,
        "summary": "The message contains a suspicious request.",
        "explanation": "It asks for an unusual payment method.",
        "assessment_confidence": "medium",
        "confidence_reason": "The request is clear, but sender context is unknown.",
        "warning_signs": [{
            "description": "Unusual payment request",
            "quoted_evidence": message,
        }],
        "context_needed": ["Did you expect this request?"],
        "recommendation": "Verify using a trusted contact method.",
    }


def response_with_text(text):
    return {
        "status": "completed",
        "output": [{
            "type": "message",
            "content": [{"type": "output_text", "text": text}],
        }],
    }


def test_flask_request_completes_openai_http_round_trip_and_enforces_schema(client):
    message = "A trusted contact asked me to send money"
    with responses.RequestsMock() as mocked:
        mocked.add(
            responses.POST,
            OPENAI_API_URL,
            json=response_with_text(json.dumps(analysis_for(message))),
            status=200,
        )
        response = client.post("/api/analyze", json={"message": message})
        assert len(mocked.calls) == 1
        outbound = mocked.calls[0].request

    assert response.status_code == 200
    result = response.get_json()["analysis"]
    assert result["warning_signs"][0]["quoted_evidence"] == message
    assert result["risk_level"] == "High"
    assert result["model"] == "openai:gpt-4o-mini"
    assert outbound.headers["Authorization"] == "Bearer integration-test-key"
    assert "integration-test-key" not in outbound.url
    payload = json.loads(outbound.body)
    schema_config = payload["text"]["format"]
    assert schema_config["type"] == "json_schema"
    assert schema_config["strict"] is True
    assert schema_config["schema"]["properties"]["warning_signs"]["items"]["required"] == [
        "description",
        "quoted_evidence",
    ]
    assert payload["store"] is False
    assert "Do not assess AI authorship" in payload["instructions"]
    assert "untrusted message" in payload["input"]


@pytest.mark.parametrize(
    "provider_payload",
    [
        [],
        {"status": "incomplete", "output": []},
        response_with_text("not JSON"),
        response_with_text(json.dumps({
            **analysis_for("different text"),
            "warning_signs": [{
                "description": "Unsupported warning",
                "quoted_evidence": "not in submitted text",
            }],
        })),
        {
            "status": "completed",
            "output": [{
                "type": "message",
                "content": [{"type": "refusal", "refusal": "Cannot analyze"}],
            }],
        },
    ],
)
def test_incomplete_malformed_refusal_and_unsupported_evidence_fail_gracefully(client, provider_payload):
    with responses.RequestsMock() as mocked:
        mocked.add(responses.POST, OPENAI_API_URL, json=provider_payload, status=200)
        response = client.post("/api/analyze", json={"message": "a different text"})
        assert len(mocked.calls) == 1

    assert response.status_code == 502
    assert response.get_json()["error"] == (
        "OpenAI returned an unusable response; local analysis is still available."
    )


def test_openai_provider_failure_does_not_log_submitted_text(client, caplog):
    private_text = "PRIVATE-CONTENT-DO-NOT-LOG-4921"
    caplog.set_level(logging.WARNING)
    with responses.RequestsMock() as mocked:
        mocked.add(
            responses.POST,
            OPENAI_API_URL,
            status=503,
            json={"error": {"message": "offline"}},
        )
        response = client.post("/api/analyze", json={"message": private_text})
        assert len(mocked.calls) == 1

    assert response.status_code == 502
    assert private_text not in caplog.text


def test_openai_provider_requires_a_configured_server_key(client, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "")
    with responses.RequestsMock() as mocked:
        response = client.post("/api/analyze", json={"message": "A fictional test message"})

    assert response.status_code == 503
    assert "OpenAI is not configured" in response.get_json()["error"]
    assert len(mocked.calls) == 0
