/* =========================================================
   ScamShield AI — Scanner / Results page
========================================================= */
(function () {
    "use strict";

    const S = window.ScamShield;
    const I18n = window.ScamShieldI18n;
    const $ = function (id) { return document.getElementById(id); };
    const t = function (text, vars) { return I18n ? I18n.translate(text, vars) : text; };
    const currentLang = function () { return I18n ? I18n.lang : "en"; };

    const scanView = $("scanView");
    const progressView = $("progressView");
    const resultView = $("resultView");
    const dropzone = $("dropzone");
    const fileInput = $("fileInput");
    const fileList = $("fileList");
    const messageInput = $("messageInput");
    const analyzeButton = $("analyzeButton");
    const scanStatus = $("scanStatus");
    const aiConsent = $("aiConsent");

    let selectedFiles = [];
    let currentBatch = [];

    const EXAMPLES = {
        en: {
            delivery: "USPS: Your package is delayed. Pay $2.99 to reschedule delivery here: http://usps-track-update.com",
            bank: "Dear Customer, your account requires verification to avoid interruption. Please confirm your details within 24 hours to keep your online banking active.",
            prize: "Congratulations! You've won a free gift card! Click here to claim your reward before it expires today: bit.ly/claim-gift-now",
            safe: "Hi Sam, your order #4471 has shipped and is on the way. It should arrive Thursday. You can track it anytime in the Amazon app. Thanks for shopping with us!"
        },
        es: {
            delivery: "USPS: Tu paquete está retrasado. Paga 2,99 $ para reprogramar la entrega aquí: http://usps-track-update.com",
            bank: "Estimado cliente: su cuenta requiere verificación para evitar la interrupción del servicio. Confirme sus datos en las próximas 24 horas para mantener activa su banca en línea.",
            prize: "¡Felicidades! ¡Ha ganado una tarjeta regalo! Haga clic aquí para reclamar su premio antes de que expire hoy: bit.ly/claim-gift-now",
            safe: "Hola Sam, tu pedido n.º 4471 se ha enviado y está en camino. Debería llegar el jueves. Puedes seguirlo en cualquier momento en la app de Amazon. ¡Gracias por comprar con nosotros!"
        }
    };

    const LEVEL_TEXT = {
        high: { pill: "High Risk", title: "Multiple Scam Warning Signs", icon: "fa-triangle-exclamation", summary: "This {thing} shows several tactics often used in scams. Pause before you reply, pay, or click." },
        medium: { pill: "Medium Risk", title: "Some Warning Signs — Verify First", icon: "fa-circle-exclamation", summary: "This {thing} has some warning signs. Verify it through an official channel before you act." },
        low: { pill: "Low Risk", title: "No Major Warning Signs Found", icon: "fa-circle-check", summary: "We didn't find major warning signs in this {thing}. Stay cautious if it was unexpected." }
    };

    const QR_TYPES = {
        url: "Website", email: "Email address", phone: "Phone number", sms: "SMS", wifi: "Wi-Fi network",
        contact: "Contact card", location: "Location", crypto: "Crypto payment", dangerous: "Dangerous link",
        text: "Plain text", empty: "Empty"
    };

    function exampleFor(key) {
        const set = EXAMPLES[currentLang()] || EXAMPLES.en;
        return set[key] || EXAMPLES.en[key] || "";
    }

    function levelForScore(score) {
        return score >= 70 ? "high" : score >= 40 ? "medium" : "low";
    }

    function recordThing(r) {
        if (r && r.qr) return "QR code";
        return r && r.file ? "file" : "message";
    }

    const KIND_ICON = {
        image: "fa-file-image", pdf: "fa-file-pdf", document: "fa-file-word", email: "fa-envelope-open-text",
        html: "fa-file-code", archive: "fa-file-zipper", program: "fa-file-circle-exclamation", text: "fa-file-lines", file: "fa-file"
    };

    /* ---------------- VIEWS ---------------- */
    function showView(view) {
        scanView.hidden = view !== "scan";
        progressView.hidden = view !== "progress";
        resultView.hidden = view !== "result";
        const isResult = view === "result";
        $("pageTitle").textContent = isResult ? t("Scan Results") : view === "progress" ? t("Scanning…") : t("Scan a Message or File");
        $("pageSubtitle").textContent = isResult
            ? t("Here's what ScamShield AI found in your {thing}.", { thing: t(recordThing(shownRecord)) })
            : t("Upload a suspicious file or paste a message, and ScamShield AI will check it for scam warning signs.");
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    let shownRecord = null;

    function resetScanner() {
        selectedFiles = [];
        renderFileList();
        messageInput.value = "";
        if (aiConsent.checked) {
            window.ScamShieldControls.setAIConsent(false).catch(function () {});
        }
        aiConsent.checked = false;
        scanStatus.textContent = "";
        $("notFoundNote").hidden = true;
        history.replaceState(null, "", "results.html");
        shownRecord = null;
        showView("scan");
        messageInput.focus({ preventScroll: true });
    }

    /* ---------------- FILE SELECTION ---------------- */
    function addFiles(list) {
        Array.from(list || []).forEach(function (f) {
            const dup = selectedFiles.some(function (s) { return s.name === f.name && s.size === f.size; });
            if (!dup) selectedFiles.push(f);
        });
        scanStatus.textContent = "";
        renderFileList();
    }

    function renderFileList() {
        fileList.innerHTML = "";
        selectedFiles.forEach(function (f, i) {
            const li = document.createElement("li");
            const tooBig = f.size > S.MAX_FILE_SIZE;
            li.innerHTML =
                '<i class="fa-solid fa-file"></i>' +
                '<span class="fl-name"></span>' +
                '<span class="fl-size">' + S.formatBytes(f.size) + (tooBig ? " · " + t("only the file type will be checked") : "") + "</span>" +
                '<button type="button" class="fl-remove" aria-label="' + t("Remove file") + '"><i class="fa-solid fa-xmark"></i></button>';
            li.querySelector(".fl-name").textContent = f.name;
            li.querySelector(".fl-remove").addEventListener("click", function () {
                selectedFiles.splice(i, 1);
                renderFileList();
            });
            fileList.appendChild(li);
        });
    }

    dropzone.addEventListener("click", function () { fileInput.click(); });
    dropzone.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fileInput.click(); }
    });
    fileInput.addEventListener("change", function () {
        addFiles(fileInput.files);
        fileInput.value = "";
    });
    ["dragenter", "dragover"].forEach(function (evt) {
        dropzone.addEventListener(evt, function (e) { e.preventDefault(); dropzone.classList.add("dragging"); });
    });
    ["dragleave", "drop"].forEach(function (evt) {
        dropzone.addEventListener(evt, function (e) { e.preventDefault(); dropzone.classList.remove("dragging"); });
    });
    dropzone.addEventListener("drop", function (e) {
        if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
    });
    // Allow dropping anywhere on the scan panel without the browser opening the file
    window.addEventListener("dragover", function (e) { e.preventDefault(); });
    window.addEventListener("drop", function (e) {
        e.preventDefault();
        if (!scanView.hidden && e.dataTransfer && e.dataTransfer.files.length && !dropzone.contains(e.target)) addFiles(e.dataTransfer.files);
    });
    // Paste an image (e.g. a screenshot) straight into the page
    document.addEventListener("paste", function (e) {
        if (scanView.hidden || !e.clipboardData) return;
        const files = Array.from(e.clipboardData.files || []);
        if (files.length) {
            e.preventDefault();
            addFiles(files.map(function (f, i) {
                return f.name && f.name !== "image.png" ? f : new File([f], "pasted-screenshot-" + (i + 1) + ".png", { type: f.type });
            }));
        }
    });

    document.querySelectorAll("[data-example]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            messageInput.value = exampleFor(btn.dataset.example);
            scanStatus.textContent = "";
            messageInput.focus();
        });
    });

    messageInput.addEventListener("input", function () { scanStatus.textContent = ""; });

    /* ---------------- RUN SCAN ---------------- */
    analyzeButton.addEventListener("click", async function () {
        const text = messageInput.value.trim();
        if (!text && !selectedFiles.length) {
            scanStatus.textContent = t("Please paste a message or upload a file first.");
            return;
        }
        showView("progress");
        try {
            await Promise.all([
                window.ScamShieldControls.waitForConsentSync(),
                window.ScamShieldControls.waitForPrivacySync()
            ]);
            const consented = aiConsent.checked;
            const records = await S.scan({
                text: text,
                files: selectedFiles,
                aiConsent: consented,
                privacyMode: window.ScamShieldControls.isPrivacyMode(),
                lang: currentLang()
            }, function (msg) {
                $("progressText").textContent = msg;
            });
            selectedFiles = [];
            messageInput.value = "";
            renderFileList();
            if (window.ScamShieldControls.isPrivacyMode()) {
                history.replaceState(null, "", "results.html");
            } else {
                const ids = records.map(function (r) { return r.id; });
                history.pushState(null, "", "results.html?ids=" + ids.join(","));
            }
            showBatch(records, 0);
        } catch (err) {
            console.error(err);
            showView("scan");
            scanStatus.textContent = t("Something went wrong while scanning. Please try again.");
        }
    });

    /* ---------------- RENDER RESULTS ---------------- */
    function showBatch(records, index) {
        currentBatch = records;
        renderBatchStrip(index);
        renderRecord(records[index]);
        showView("result");
    }

    function renderBatchStrip(activeIndex) {
        const strip = $("batchStrip");
        if (currentBatch.length < 2) {
            strip.hidden = true;
            return;
        }
        strip.hidden = false;
        strip.innerHTML = '<span class="batch-label">' + t("{count} items scanned", { count: currentBatch.length }) + "</span>";
        currentBatch.forEach(function (r, i) {
            const b = document.createElement("button");
            b.type = "button";
            b.className = "batch-item" + (i === activeIndex ? " active" : "");
            b.innerHTML = '<span class="dot ' + r.level + '"></span><span class="bi-name"></span><span class="bi-score">' + r.score + "</span>";
            b.querySelector(".bi-name").textContent = r.file ? r.file.name : r.qr ? t("QR destination (not opened)") : t("Pasted message");
            b.addEventListener("click", function () {
                renderBatchStrip(i);
                renderRecord(r);
            });
            strip.appendChild(b);
        });
    }

    function renderRecord(r) {
        shownRecord = r;
        const ai = r.aiAnalysis || null;
        const indicators = Array.isArray(r.indicators) ? r.indicators : [];
        const localScore = typeof r.triageScore === "number"
            ? r.triageScore
            : typeof r.ruleScore === "number" ? r.ruleScore : r.score;
        const localLevel = levelForScore(localScore);
        const L = LEVEL_TEXT[localLevel];
        const thing = t(recordThing(r));

        const verdict = $("verdict");
        verdict.className = "verdict " + localLevel;
        $("verdictIcon").className = "fa-solid " + L.icon;
        $("verdictTitle").textContent = t("Initial Triage: {level}", { level: t(L.title) });
        $("verdictSummary").textContent = t(L.summary, { thing: thing });
        const pill = $("riskPill");
        pill.className = "risk-pill " + localLevel;
        pill.textContent = t(L.pill);
        $("scoreValue").textContent = localScore;
        $("scoreLabel").textContent = t("Initial Triage · heuristic risk indicator, not a calibrated probability");

        // Flags with concrete evidence, score weight, and a next step
        const flagList = $("flagList");
        flagList.replaceChildren();
        $("flagsTitle").textContent = t(indicators.length ? "Initial Triage Signals" : "Initial Triage Checks");
        if (indicators.length) {
            const MAX_SHOWN = 6;
            indicators.forEach(function (ind, idx) {
                const li = document.createElement("li");
                li.className = "flag " + ind.severity + (idx >= MAX_SHOWN ? " extra" : "");
                li.hidden = idx >= MAX_SHOWN;

                const icon = document.createElement("i");
                icon.className = "fa-solid fa-triangle-exclamation";
                li.appendChild(icon);

                const body = document.createElement("span");
                const strong = document.createElement("strong");
                strong.textContent = ind.title;
                body.appendChild(strong);
                body.appendChild(document.createTextNode(" "));

                const detail = document.createElement("span");
                detail.className = "flag-detail";
                detail.textContent = "(" + ind.detail + ")";
                body.appendChild(detail);

                if (typeof ind.weight === "number") {
                    const weight = document.createElement("span");
                    weight.className = "flag-weight";
                    weight.textContent = "+" + ind.weight;
                    weight.title = t("contributes {weight} points", { weight: ind.weight });
                    weight.setAttribute("aria-label", weight.title);
                    body.appendChild(weight);
                }

                if (ind.evidence) {
                    const evidence = document.createElement("p");
                    evidence.className = "flag-evidence";
                    evidence.textContent = t("Matched text:") + " “" + ind.evidence + "”";
                    body.appendChild(evidence);
                }
                if (ind.nextStep) {
                    const next = document.createElement("p");
                    next.className = "flag-next";
                    next.textContent = t("What to do:") + " " + ind.nextStep;
                    body.appendChild(next);
                }

                li.appendChild(body);
                flagList.appendChild(li);
            });
            if (indicators.length > MAX_SHOWN) {
                const more = document.createElement("li");
                more.innerHTML = '<button type="button" class="text-button show-more"></button>';
                const btn = more.querySelector("button");
                const extra = indicators.length - MAX_SHOWN;
                const label = function () {
                    return t(extra === 1 ? "Show {count} more warning sign" : "Show {count} more warning signs", { count: extra });
                };
                btn.textContent = label();
                btn.addEventListener("click", function () {
                    const open = btn.dataset.open === "1";
                    flagList.querySelectorAll(".flag.extra").forEach(function (el) { el.hidden = open; });
                    btn.dataset.open = open ? "" : "1";
                    btn.textContent = open ? label() : t("Show fewer");
                });
                flagList.appendChild(more);
            }
        } else {
            [
                "No pressure or urgent language",
                "No request for money, gift cards, or card details",
                "No request for passwords or personal information",
                r.links && r.links.length ? "Links didn't match known scam patterns" : "No links found"
            ].forEach(function (text) {
                const li = document.createElement("li");
                li.className = "flag safe";
                li.innerHTML = '<i class="fa-solid fa-circle-check"></i><span></span>';
                li.querySelector("span").textContent = t(text);
                flagList.appendChild(li);
            });
        }

        $("explanationText").textContent = r.explanation;
        $("triageScore").textContent = localScore;
        $("triageBreakdown").textContent =
            t("Rule score: {score}/100 — a heuristic sum of the signals shown, not a calibrated probability.", { score: localScore }) + " " +
            t(r.textModelMatched ? "The statistical text model matched this message." : "The statistical text model did not match this message.");

        $("aiReviewTitle").textContent = t("AI Second Opinion");
        $("aiReviewBlock").hidden = !ai && !r.aiError;
        $("aiReviewError").hidden = !r.aiError;
        $("aiReviewError").textContent = r.aiError || "";
        $("aiTruncatedNote").hidden = !r.aiTextTruncated;
        if (ai) {
            const aiLevel = levelForScore(ai.risk_score);
            $("aiScoreValue").textContent = t("AI Second Opinion: {level}", {
                level: t(LEVEL_TEXT[aiLevel].pill)
            }) + " · " + ai.risk_score + "/100";
            $("aiConfidence").textContent = t(ai.assessment_confidence + " confidence") + ". " + ai.confidence_reason;
            $("aiExplanation").textContent = ai.explanation;
            $("aiRecommendation").textContent = ai.recommendation;
            const signs = $("aiWarningSigns");
            signs.replaceChildren();
            (ai.warning_signs || []).forEach(function (sign) {
                const li = document.createElement("li");
                const description = document.createElement("strong");
                description.textContent = typeof sign === "string" ? sign : sign.description;
                li.appendChild(description);
                if (typeof sign !== "string" && typeof sign.quoted_evidence === "string") {
                    const evidence = document.createElement("p");
                    evidence.className = "ai-evidence";
                    evidence.textContent = t("Quoted evidence:") + " “" + sign.quoted_evidence + "”";
                    li.appendChild(evidence);
                }
                signs.appendChild(li);
            });
            const questions = $("aiContextNeeded");
            questions.replaceChildren();
            (ai.context_needed || []).forEach(function (question) {
                const li = document.createElement("li");
                li.textContent = question;
                questions.appendChild(li);
            });
            $("aiContextBlock").hidden = !(ai.context_needed && ai.context_needed.length);
        } else {
            $("aiScoreValue").textContent = "";
            $("aiConfidence").textContent = "";
            $("aiExplanation").textContent = "";
            $("aiRecommendation").textContent = "";
            $("aiWarningSigns").replaceChildren();
            $("aiContextNeeded").replaceChildren();
            $("aiContextBlock").hidden = true;
        }

        const actionList = $("actionList");
        actionList.replaceChildren();
        $("actionsTitle").textContent = t("Suggested Actions");
        (r.actions || []).forEach(function (action) {
            const li = document.createElement("li");
            li.textContent = action;
            actionList.appendChild(li);
        });

        // Side: what was analyzed
        $("analyzedTitle").textContent = r.qr ? t("QR Code Analyzed") : r.file ? t("File Analyzed") : t("Message Analyzed");
        const chip = $("fileChip");
        if (r.file) {
            chip.hidden = false;
            chip.innerHTML = '<i class="fa-solid ' + (KIND_ICON[r.file.kind] || "fa-file") + '"></i><div><strong></strong><span></span></div>';
            chip.querySelector("strong").textContent = r.file.name;
            chip.querySelector("span").textContent = S.formatBytes(r.file.size) +
                (r.email && r.email.from ? " · " + t("From: {sender}", { sender: r.email.from }) : "");
        } else {
            chip.hidden = true;
        }

        const analyzed = $("analyzedText");
        const qrBox = $("qrAnalyzed");
        if (r.qr) {
            analyzed.hidden = true;
            analyzed.replaceChildren();
            qrBox.hidden = false;
            qrBox.replaceChildren();

            const type = document.createElement("p");
            type.className = "qr-type-line";
            type.textContent = t(QR_TYPES[r.qr.type] || "Plain text");
            qrBox.appendChild(type);

            const label = document.createElement("p");
            label.className = "qr-destination-label";
            label.textContent = t("Decoded destination (not opened)");
            qrBox.appendChild(label);

            const destination = document.createElement("pre");
            destination.className = "qr-destination";
            destination.textContent = r.qr.destination || r.text || "";
            qrBox.appendChild(destination);

            const warning = document.createElement("p");
            warning.className = "qr-safe-warning";
            warning.textContent = t("This destination was decoded on your device and was not opened.");
            qrBox.appendChild(warning);
        } else {
            qrBox.hidden = true;
            qrBox.replaceChildren();
            if (r.text) {
                analyzed.hidden = false;
                analyzed.innerHTML = highlightLinks(r.text) + (r.textTruncated ? '<span class="truncated">' + t("… (shortened)") + "</span>" : "");
            } else {
                analyzed.hidden = !!r.file;
                analyzed.innerHTML = '<span class="muted">' + t("No readable text.") + "</span>";
            }
        }

        const notes = $("notesList");
        notes.innerHTML = "";
        notes.hidden = !(r.notes && r.notes.length);
        (r.notes || []).forEach(function (note) {
            const li = document.createElement("li");
            li.innerHTML = '<i class="fa-solid fa-circle-info"></i><span></span>';
            li.querySelector("span").textContent = note;
            notes.appendChild(li);
        });

        const interfaceLanguage = { en: "English", es: "Spanish", hi: "Hindi", zh: "Mandarin" }[r.lang] || "English";
        $("scanMeta").textContent = t("Scanned {date}", { date: S.formatDate(r.createdAt) }) + " · " +
            t("Interface language: {lang}", { lang: t(interfaceLanguage) });
    }

    // Shows links in the text, but never as clickable links
    function highlightLinks(text) {
        const urls = S.findUrls(text);
        let html = "";
        let pos = 0;
        urls.forEach(function (u) {
            const i = text.indexOf(u, pos);
            if (i < 0) return;
            html += S.escapeHtml(text.slice(pos, i));
            html += '<span class="flagged-link" title="Link disabled for your safety">' + S.escapeHtml(u) + "</span>";
            pos = i + u.length;
        });
        html += S.escapeHtml(text.slice(pos));
        return html;
    }

    $("scanAnotherButton").addEventListener("click", resetScanner);
    $("navScanButton").addEventListener("click", function (e) {
        e.preventDefault();
        resetScanner();
    });

    /* ---------------- ROUTING ---------------- */
    function route() {
        const params = new URLSearchParams(location.search);
        if (params.get("private") === "1") {
            let privateRecords = [];
            try {
                const transfer = JSON.parse(sessionStorage.getItem("scamshield-private-results") || "null");
                sessionStorage.removeItem("scamshield-private-results");
                if (
                    transfer &&
                    Number.isFinite(transfer.createdAt) &&
                    Date.now() - transfer.createdAt < 60000 &&
                    Array.isArray(transfer.records)
                ) {
                    privateRecords = transfer.records;
                }
            } catch (_error) {
                privateRecords = [];
            }
            history.replaceState(null, "", "results.html");
            if (Array.isArray(privateRecords) && privateRecords.length) {
                showBatch(privateRecords, 0);
                return;
            }
            showView("scan");
            $("notFoundNote").textContent = t("Private scan results are no longer available. Run the scan again; Privacy Mode does not retain them.");
            $("notFoundNote").hidden = false;
            return;
        }
        const ids = (params.get("ids") || params.get("id") || "").split(",").filter(Boolean);
        if (!ids.length) {
            shownRecord = null;
            showView("scan");
            return;
        }
        const records = ids.map(S.getRecord).filter(Boolean);
        if (!records.length) {
            showView("scan");
            $("notFoundNote").hidden = false;
            return;
        }
        showBatch(records, 0);
    }

    window.addEventListener("popstate", route);
    window.addEventListener("scamshield:langchange", function () {
        if (shownRecord && !resultView.hidden) {
            renderRecord(shownRecord);
            showView("result");
        } else if (progressView.hidden) {
            showView("scan");
        }
    });
    route();
})();
