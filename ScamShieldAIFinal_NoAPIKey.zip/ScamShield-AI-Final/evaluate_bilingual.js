"use strict";

// Evaluates the browser scanner on a labeled, test-only set. Prints aggregate
// metrics only: message text is never echoed. A low score is a finding to
// document, not something this script should tune away.

const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const DEFAULT_DATASET = path.join(__dirname, "test", "fixtures", "eval_bilingual_holdout.json");
const MEDIUM_THRESHOLD = 40;
const SUPPORTED_LANGUAGES = ["en", "es"];

const context = {
    window: {},
    localStorage: { getItem: function () { return null; }, setItem: function () {} },
    URL: URL
};
vm.runInNewContext(fs.readFileSync(path.join(__dirname, "scamshield-text-model.js"), "utf8"), context);
vm.runInNewContext(fs.readFileSync(path.join(__dirname, "scanner-engine.js"), "utf8"), context);

function fail(message) {
    process.stderr.write("Bilingual evaluation failed: " + message + "\n");
    process.exit(1);
}

function round(value) {
    return value === null ? null : Math.round(value * 10000) / 10000;
}

function metrics(rows, predict) {
    let tn = 0;
    let fp = 0;
    let fn = 0;
    let tp = 0;
    rows.forEach(function (row) {
        const predicted = predict(row);
        if (row.label && predicted) tp++;
        else if (!row.label && predicted) fp++;
        else if (row.label && !predicted) fn++;
        else tn++;
    });
    const precision = tp + fp ? tp / (tp + fp) : 0;
    const recall = tp + fn ? tp / (tp + fn) : 0;
    return {
        examples: rows.length,
        positives: tp + fn,
        negatives: tn + fp,
        true_positives: tp,
        false_positives: fp,
        false_negatives: fn,
        true_negatives: tn,
        precision: round(precision),
        recall: round(recall),
        f1: round(precision + recall ? 2 * precision * recall / (precision + recall) : 0),
        false_positive_rate: round(fp + tn ? fp / (fp + tn) : null)
    };
}

function analyzeExample(example) {
    const analysis = context.window.ScamShield.analyze({ text: example.text, lang: example.lang });
    return {
        id: example.id,
        lang: example.lang,
        label: example.expected_label === "suspicious",
        triage: analysis.score >= MEDIUM_THRESHOLD,
        rules: analysis.ruleScore >= MEDIUM_THRESHOLD,
        model: analysis.textModelMatched,
        score: analysis.score,
        rule_score: analysis.ruleScore
    };
}

function variantReports(rows) {
    return {
        initial_triage: metrics(rows, function (row) { return row.triage; }),
        rules_only: metrics(rows, function (row) { return row.rules; }),
        learned_model_only: metrics(rows, function (row) { return row.model; })
    };
}

const datasetPath = process.argv[2] ? path.resolve(process.argv[2]) : DEFAULT_DATASET;
let dataset;
try {
    dataset = JSON.parse(fs.readFileSync(datasetPath, "utf8"));
} catch (error) {
    fail("cannot read " + datasetPath + " (" + error.message + ")");
}
if (!dataset || typeof dataset !== "object" || !Array.isArray(dataset.examples)) {
    fail("dataset must be an object with an examples array");
}
if (dataset.split !== "test" || dataset.usage !== "evaluation_only") {
    fail("dataset must declare split \"test\" and usage \"evaluation_only\"");
}

const examples = dataset.examples;
if (!examples.length) {
    fail("dataset contains no examples");
}

const ids = new Set();
const rows = [];
const languages = new Set();
examples.forEach(function (example) {
    if (!example || typeof example !== "object") fail("malformed example");
    if (typeof example.id !== "string" || !example.id) fail("every example needs an id");
    if (ids.has(example.id)) fail("duplicate example id: " + example.id);
    ids.add(example.id);
    if (!SUPPORTED_LANGUAGES.includes(example.lang)) fail("unsupported language in " + example.id);
    if (example.split !== "test") fail("example " + example.id + " is not in the test split");
    if (!["suspicious", "benign"].includes(example.expected_label)) {
        fail("example " + example.id + " has an unsupported label");
    }
    if (typeof example.text !== "string" || !example.text.trim()) {
        fail("example " + example.id + " has no text");
    }
    languages.add(example.lang);
    rows.push(analyzeExample(example));
});

SUPPORTED_LANGUAGES.forEach(function (lang) {
    if (!languages.has(lang)) fail("dataset must include both English and Spanish examples");
    const languageRows = rows.filter(function (row) { return row.lang === lang; });
    const labels = new Set(languageRows.map(function (row) { return row.label; }));
    if (labels.size !== 2) fail(lang + " examples must include both labels");
});

const byLanguage = {};
SUPPORTED_LANGUAGES.forEach(function (lang) {
    const languageRows = rows.filter(function (row) { return row.lang === lang; });
    byLanguage[lang] = variantReports(languageRows);
});

const falsePositives = rows.filter(function (row) { return !row.label && row.triage; });
const falseNegatives = rows.filter(function (row) { return row.label && !row.triage; });

console.log(JSON.stringify({
    dataset: {
        name: dataset.name || path.basename(datasetPath),
        version: dataset.version || null,
        examples: rows.length,
        split: dataset.split,
        usage: dataset.usage,
        source: path.relative(__dirname, datasetPath)
    },
    score_note: "Initial triage flags a message at a heuristic score of 40 or more. Scores are not calibrated probabilities.",
    overall: variantReports(rows),
    by_language: byLanguage,
    misclassified_initial_triage: {
        false_positives: falsePositives.map(function (row) { return row.id; }),
        false_negatives: falseNegatives.map(function (row) { return row.id; })
    },
    limitations: dataset.limitations || []
}, null, 2));
