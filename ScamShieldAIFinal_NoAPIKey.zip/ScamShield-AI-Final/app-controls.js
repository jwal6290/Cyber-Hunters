(function () {
    "use strict";

    function t(text, vars) {
        return window.ScamShieldI18n ? window.ScamShieldI18n.translate(text, vars) : text;
    }

    const state = {
        ready: false,
        adultConfirmed: false,
        aiConsent: false,
        privacyMode: false
    };
    let consentSync = Promise.resolve();
    let privacySync = Promise.resolve();

    const styles = document.createElement("style");
    styles.textContent = [
        ".age-gate-overlay{position:fixed;inset:0;z-index:10000;display:grid;place-items:center;padding:20px;background:rgba(13,25,40,.78)}",
        ".age-gate-overlay[hidden]{display:none}",
        ".age-gate-panel{width:min(560px,100%);padding:28px;border-radius:16px;background:#fff;color:#26384b;box-shadow:0 20px 70px rgba(0,0,0,.28)}",
        ".age-gate-panel h2{margin:0 0 12px}",
        ".age-gate-panel p{margin:10px 0}",
        ".age-gate-caveat,.age-gate-status{font-size:14px;color:#596a7b}",
        ".age-gate-actions{display:flex;flex-wrap:wrap;gap:10px;margin:20px 0 12px}",
        ".age-gate-resource{color:#176a86;text-decoration:underline}",
        ".privacy-mode-control{display:flex;gap:10px;align-items:flex-start;margin:14px 0;padding:12px;border:1px solid #d5dee8;border-radius:10px;background:#f7fafc}",
        ".privacy-mode-control input{margin-top:5px}",
        ".privacy-mode-control span{display:grid;gap:3px}",
        ".privacy-mode-control small{font-size:13px;color:#667789}"
    ].join("");
    document.head.appendChild(styles);

    function requestJson(url, payload) {
        return fetch(url, {
            method: payload ? "POST" : "GET",
            headers: payload ? { "Content-Type": "application/json" } : {},
            body: payload ? JSON.stringify(payload) : undefined
        }).then(async function (response) {
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || "The server rejected the request.");
            return result;
        });
    }

    function setGateActive(overlay, active) {
        Array.from(document.body.children).forEach(function (element) {
            if (element === overlay) return;
            if (active) element.setAttribute("inert", "");
            else element.removeAttribute("inert");
        });
        if (active) overlay.querySelector("button").focus();
    }

    function buildAgeGate() {
        const overlay = document.createElement("div");
        overlay.className = "age-gate-overlay";
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-modal", "true");
        overlay.setAttribute("aria-labelledby", "ageGateTitle");

        const panel = document.createElement("section");
        panel.className = "age-gate-panel";
        const langSlot = document.createElement("div");
        langSlot.className = "age-gate-lang";
        if (window.ScamShieldI18n) langSlot.appendChild(window.ScamShieldI18n.createSwitcher());
        const heading = document.createElement("h2");
        heading.id = "ageGateTitle";
        heading.textContent = t("Before using the scanner");
        const message = document.createElement("p");
        message.textContent = t("This scanner includes an optional AI feature. Confirm that you are 18 or older to continue. If you are under 18, scanner access is blocked.");
        const caveat = document.createElement("p");
        caveat.className = "age-gate-caveat";
        caveat.textContent = t("This is a self-attestation, not identity or age verification. Check the configured provider's current terms and your app's audience before enabling AI review.");
        const status = document.createElement("p");
        status.className = "age-gate-status";
        status.setAttribute("role", "status");
        status.setAttribute("aria-live", "polite");
        const actions = document.createElement("div");
        actions.className = "age-gate-actions";
        const confirm = document.createElement("button");
        confirm.type = "button";
        confirm.className = "primary-button";
        confirm.textContent = t("I confirm I am 18 or older");
        const decline = document.createElement("button");
        decline.type = "button";
        decline.className = "secondary-button";
        decline.textContent = t("I am under 18");
        const resources = document.createElement("a");
        resources.href = "learn.html";
        resources.className = "age-gate-resource";
        resources.textContent = t("Visit safety resources");

        confirm.addEventListener("click", async function () {
            confirm.disabled = true;
            status.textContent = t("Saving your confirmation…");
            try {
                await requestJson("/api/age-gate", { adult_confirmed: true });
                state.adultConfirmed = true;
                state.ready = true;
                overlay.hidden = true;
                setGateActive(overlay, false);
                const scannerInput = document.querySelector("#messageInput, #message");
                if (scannerInput) scannerInput.focus({ preventScroll: true });
                document.querySelectorAll("[data-ai-consent]").forEach(function (input) {
                    input.disabled = false;
                });
            } catch (error) {
                status.textContent = error.message || t("Could not save your confirmation. Scanner access remains blocked.");
                confirm.disabled = false;
            }
        });
        decline.addEventListener("click", async function () {
            decline.disabled = true;
            try {
                await requestJson("/api/age-gate", { adult_confirmed: false });
            } catch (_error) {
                // The gate remains blocking even if the server is unavailable.
            }
            state.adultConfirmed = false;
            state.aiConsent = false;
            status.textContent = t("Scanner access is unavailable because you did not confirm that you are 18 or older.");
            decline.disabled = false;
        });

        actions.append(confirm, decline);
        panel.append(langSlot, heading, message, caveat, status, actions, resources);
        overlay.appendChild(panel);

        window.addEventListener("scamshield:langchange", function () {
            heading.textContent = t("Before using the scanner");
            message.textContent = t("This scanner includes an optional AI feature. Confirm that you are 18 or older to continue. If you are under 18, scanner access is blocked.");
            caveat.textContent = t("This is a self-attestation, not identity or age verification. Check the configured provider's current terms and your app's audience before enabling AI review.");
            confirm.textContent = t("I confirm I am 18 or older");
            decline.textContent = t("I am under 18");
            resources.textContent = t("Visit safety resources");
            document.querySelectorAll("[data-privacy-title]").forEach(function (node) {
                node.textContent = t("Privacy Mode");
            });
            document.querySelectorAll("[data-privacy-detail]").forEach(function (node) {
                node.textContent = t("Do not save new scan text to local history. Private results use a one-time tab transfer and are removed after loading.");
            });
        });
        document.body.appendChild(overlay);
        return overlay;
    }

    function installPrivacyToggle() {
        document.querySelectorAll("[data-privacy-controls]").forEach(function (slot) {
            const label = document.createElement("label");
            label.className = "privacy-mode-control";
            const input = document.createElement("input");
            input.type = "checkbox";
            input.setAttribute("data-privacy-toggle", "");
            const text = document.createElement("span");
            const title = document.createElement("strong");
            title.setAttribute("data-privacy-title", "");
            title.textContent = t("Privacy Mode");
            const detail = document.createElement("small");
            detail.setAttribute("data-privacy-detail", "");
            detail.textContent = t("Do not save new scan text to local history. Private results use a one-time tab transfer and are removed after loading.");
            text.append(title, detail);
            label.append(input, text);
            slot.appendChild(label);

            input.addEventListener("change", function () {
                const requested = input.checked;
                state.privacyMode = requested;
                privacySync = requestJson("/api/privacy-mode", { enabled: requested }).catch(function (error) {
                    state.privacyMode = !requested;
                    input.checked = !requested;
                    const status = document.querySelector("[data-consent-status]");
                    if (status) status.textContent = error.message || t("Could not update Privacy Mode.");
                });
            });
        });
    }

    function installConsentControls() {
        const inputs = Array.from(document.querySelectorAll("[data-ai-consent]"));
        inputs.forEach(function (input) {
            input.addEventListener("change", function () {
                consentSync = window.ScamShieldControls.setAIConsent(input.checked).catch(function (error) {
                    input.checked = false;
                    state.aiConsent = false;
                    const status = document.querySelector("[data-consent-status]");
                    if (status) status.textContent = error.message || t("AI consent could not be saved; local scanning remains available.");
                });
            });
        });
    }

    const ageGate = buildAgeGate();
    setGateActive(ageGate, true);
    installPrivacyToggle();
    installConsentControls();

    window.ScamShieldControls = {
        isPrivacyMode: function () { return state.privacyMode; },
        isAdultConfirmed: function () { return state.adultConfirmed; },
        hasAIConsent: function () { return state.aiConsent; },
        waitForConsentSync: function () { return consentSync; },
        waitForPrivacySync: function () { return privacySync; },
        setAIConsent: async function (consent) {
            if (consent && !state.adultConfirmed) throw new Error(t("Confirm that you are 18 or older first."));
            const result = await requestJson("/api/ai-consent", { consent: consent === true });
            state.aiConsent = result.ai_consent;
            return result;
        }
    };

    requestJson("/api/session").then(function (result) {
        state.adultConfirmed = result.adult_confirmed === true;
        state.aiConsent = result.ai_consent === true;
        state.privacyMode = result.privacy_mode === true;
        state.ready = true;
        ageGate.hidden = state.adultConfirmed;
        setGateActive(ageGate, !state.adultConfirmed);
        document.querySelectorAll("[data-ai-consent]").forEach(function (input) {
            input.checked = state.aiConsent;
            input.disabled = !state.adultConfirmed;
        });
        document.querySelectorAll("[data-privacy-toggle]").forEach(function (input) {
            input.checked = state.privacyMode;
        });
    }).catch(function () {
        state.ready = false;
        ageGate.hidden = false;
        ageGate.querySelector(".age-gate-status").textContent =
            t("The server session could not be verified. Scanner access remains blocked until the server is available.");
        ageGate.querySelectorAll("button").forEach(function (button) { button.disabled = true; });
    });
}());
