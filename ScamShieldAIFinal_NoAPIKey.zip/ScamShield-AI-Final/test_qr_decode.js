/* QR decoding and payload-classification checks.
   Run with: node test_qr_decode.js
   Decoding is local; these fixtures are generated QR images. */
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const jsQR = require("./vendor/jsqr.js");
global.jsQR = jsQR;
const qr = require("./qr-decode.js");
qr.setDecoder(jsQR);

const FIXTURES = path.join(__dirname, "test", "fixtures");

function load(name) {
    return JSON.parse(fs.readFileSync(path.join(FIXTURES, name), "utf8"));
}

function decode(name) {
    const fixture = load(name);
    const bytes = Buffer.from(fixture.data_b64, "base64");
    assert.strictEqual(bytes.length, fixture.width * fixture.height, name + ": unexpected fixture size");
    return qr.decodeImageData({
        width: fixture.width,
        height: fixture.height,
        data: new Uint8ClampedArray(bytes)
    });
}

const cases = [
    ["qr_valid_order.json", "https://www.example.com/order/4471", "url"],
    ["qr_benign_usps.json", "https://www.usps.com/tracking", "url"],
    ["qr_shortened.json", "https://bit.ly/3xYzAbC", "url"],
    ["qr_lookalike_delivery.json", "http://usps-track-update.com/reschedule?fee=2.99", "url"],
    ["qr_raw_ip_login.json", "http://192.0.2.10/login", "url"],
    ["qr_dangerous_scheme.json", "javascript:alert(1)", "dangerous"],
    ["qr_email.json", "mailto:helpdesk@example.edu", "email"],
    ["qr_phone.json", "tel:+15550100", "phone"],
    ["qr_wifi.json", "WIFI:T:WPA;S:CampusGuest;P:example123;;", "wifi"],
    ["qr_plain_text_scam.json", "URGENT: Your account is locked. Verify at http://secure-bank-verify.xyz", "text"],
    ["qr_malformed.json", "http://", "url"],
    ["qr_punycode_lookalike.json", "https://аpple.com/verify", "url"]
];

let checks = 0;
function check(label, fn) {
    fn();
    checks += 1;
    console.log("PASS " + label);
}

cases.forEach(function (entry) {
    const name = entry[0];
    const payload = entry[1];
    const type = entry[2];
    check("decodes " + name, function () {
        const decoded = decode(name);
        assert.ok(decoded, name + " did not decode");
        assert.strictEqual(decoded.payload, payload);
        assert.strictEqual(qr.classifyType(decoded.payload), type);
    });
});

check("valid URL becomes one inert analysis link", function () {
    const input = qr.analysisInput({ payload: "https://bit.ly/3xYzAbC" }, "es");
    assert.strictEqual(input.type, "url");
    assert.strictEqual(input.lang, "es");
    assert.strictEqual(input.links.length, 1);
    assert.strictEqual(input.links[0].href, "https://bit.ly/3xYzAbC");
});

check("scheme-less www URL is normalized for analysis only", function () {
    assert.strictEqual(qr.safeUrl("www.example.com/login"), "http://www.example.com/login");
    assert.strictEqual(qr.classifyType("www.example.com/login"), "url");
    const input = qr.analysisInput({ payload: "www.example.com/login" }, "en");
    assert.strictEqual(input.links[0].href, "http://www.example.com/login");
});

check("dangerous schemes are classified and produce no link", function () {
    ["javascript:alert(1)", "data:text/html,<script>alert(1)</script>", "file:///etc/passwd"].forEach(function (payload) {
        const info = qr.classifyPayload(payload);
        assert.strictEqual(info.type, "dangerous", payload);
        assert.strictEqual(info.dangerousScheme, true, payload);
        assert.strictEqual(qr.analysisInput({ payload: payload }).links.length, 0, payload);
    });
});

check("non-URL payloads do not become links", function () {
    ["mailto:helpdesk@example.edu", "tel:+15550100", "WIFI:T:WPA;S:CampusGuest;P:example123;;"].forEach(function (payload) {
        assert.strictEqual(qr.analysisInput({ payload: payload }).links.length, 0, payload);
    });
});

check("Wi-Fi passwords are redacted for display and history", function () {
    const info = qr.classifyPayload("WIFI:T:WPA;S:CampusGuest;P:example123;;");
    assert.strictEqual(info.displayText, "WIFI:T:WPA;S:CampusGuest;P:[hidden];;");
    assert.ok(info.displayText.indexOf("example123") < 0);
    assert.ok(info.payload.indexOf("example123") >= 0);
});

check("malformed and empty payloads are handled without throwing", function () {
    assert.strictEqual(qr.classifyType("http://"), "url");
    assert.strictEqual(qr.safeUrl("http://"), "http://");
    assert.strictEqual(qr.classifyType(""), "empty");
    assert.strictEqual(qr.classifyType("   "), "empty");
});

check("payload normalization trims and caps length", function () {
    assert.strictEqual(qr.normalizePayload("  hello\u0000  "), "hello");
    assert.strictEqual(qr.normalizePayload("x".repeat(5000)).length, qr.MAX_PAYLOAD);
});

check("grayscale image data expands to opaque RGBA", function () {
    const rgba = qr.imageDataToRgba({ width: 2, height: 1, data: new Uint8ClampedArray([0, 255]) });
    assert.deepStrictEqual(Array.from(rgba), [0, 0, 0, 255, 255, 255, 255, 255]);
});

check("a blank image returns no QR result", function () {
    const width = 120;
    const height = 120;
    const blank = new Uint8ClampedArray(width * height * 4).fill(255);
    assert.strictEqual(qr.decodeImageData({ width: width, height: height, data: blank }), null);
});

console.log("\n" + checks + " QR checks passed.");
