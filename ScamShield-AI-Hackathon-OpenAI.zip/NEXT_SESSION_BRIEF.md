# Next-session brief: ScamShield hackathon

You are continuing ScamShield in the personal project folder:

`C:\Users\SHADO\Downloads\Cyber-Hunters-main\Cyber-Hunters-main`

Read `SCAMSHIELD_PROJECT_AUDIT.md` first. The user's goal is a responsible, convincing hackathon prototype that helps people notice scam indicators—not a claim of production-grade detection or a standalone security product.

## Boundaries

- Work only in the personal project unless the user explicitly authorizes team-file edits.
- Keep the team folder and original downloaded ZIP unchanged.
- Never ask the user to paste a credential. Never put API keys in frontend code, documents, logs, screenshots, or commits.
- An OpenAI API key was exposed in chat. Treat it as compromised; remind the user to revoke it and review usage if its status is not confirmed. Do not repeat, test, or use it.
- The current local server uses `GEMINI_API_KEY` and Gemini HTTP from Flask. The standalone Firebase module also uses Gemini, but is not integrated. OpenAI is not implemented. Do not silently switch providers; make the integration choice clear and server-side.
- The supplied 101–300 synthetic data and the 17-record user-provided data have already been evaluated. Do not train or tune on either and then report them as independent holdouts.

## First concrete bug to fix

The browser pages load `scamshield-text-model.js`, but Flask's `PUBLIC_FILES` allowlist omits it. The verified response is 404 for `/scamshield-text-model.js` and 200 for `/scanner-engine.js`. The local model therefore does not load through the Flask-served app. Add the model asset to the safe static allowlist and add a regression test that:

1. Requests the model asset through Flask and expects 200.
2. Checks it is loaded before `scanner-engine.js` on each page using it.
3. Exercises a known model-matching message through the same browser scanner code, confirming model-enabled triage.

Do not treat this implementation bug as solved merely because the offline benchmark directly loaded the model file from disk.

## Model evidence to preserve

- Scam Shield SMS public held-out test: model-only F1 94.6%; combined scanner F1 95.5%.
- UCI SMS spam domain-shift check: model-only F1 88.0%; combined F1 86.5%.
- GPT-generated 101–300 set: 160 binary-labeled messages, with 40 ambiguous excluded. Model-only F1 75.2% (13 FP, 24 FN); combined F1 73.6% (23 FP, 20 FN).
- User file called `scamshield_real_world_examples.json`: 17 records, 16 suspicious and 1 benign. Model-only F1 60.9%; combined 66.7%. Too small and imbalanced for reliable conclusions; source authenticity is not verified.
- Scores and the 0.7 threshold are heuristics, not calibrated probabilities. Do not claim head-to-head competitiveness or real-world accuracy.

## After fixing model delivery

Inspect false positives and false negatives by ID/category without printing or persisting private message text. Decide, using only development/validation data, whether rules should influence the combined score or remain visible indicators. On some sets the combined strategy adds false positives and reduces F1. Preserve a new untouched final test set for evaluation after changes.

Do not force ambiguous messages into “safe” or “scam.” Propose an “uncertain / verify independently” outcome and measurable abstention behavior. Seek a larger, balanced, consented, independently labeled dataset that reflects the hackathon's target use case.

## Provider and eligibility gates

- Confirm whether the hackathon audience includes or is directed toward people under 18. A self-attestation checkbox is not age verification and does not make an otherwise ineligible Gemini app eligible. If Gemini terms do not allow this audience, keep the demo local-only or use another reviewed design.
- If the user selects OpenAI, implement a server-side Cloud Function/Cloud Run/Flask call backed by a secret manager; do not use Firebase AI Logic as if it were an OpenAI adapter.
- If using the Firebase drop-in, it remains a separate integration requiring the team's `firebase.js` named `app` export, Firebase AI Logic setup, App Check enforcement, public site key, and fixing the team's previously observed duplicate Firestore imports. Recheck that import issue read-only before advising the team.
- Keep AI optional. Local scanning should work if the provider, network, App Check, or key is unavailable.

## Verification/reporting

Run the smallest relevant tests after changes, then the existing Python and JavaScript suites if the scanner path is affected. Report actual served-app behavior, not only unit/offline metrics. Clearly separate:

- what changed in the personal project,
- what the team still needs to configure or implement,
- metrics and dataset limitations,
- tests run and any live-provider setup not exercised.

Do not claim the project is production-ready. Never modify the team folder or downloaded ZIP without explicit authorization.
