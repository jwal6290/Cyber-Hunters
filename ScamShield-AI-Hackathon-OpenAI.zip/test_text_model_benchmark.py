import json
import tempfile
import unittest
from pathlib import Path

from benchmark_text_model import benchmark_scanner, load_model, load_user_json, predict, report_metrics


class TextModelBenchmarkTests(unittest.TestCase):
    def setUp(self):
        self.model = {
            "intercept": -2.0,
            "threshold": 0.7,
            "weights": {"urgent": 5.0, "urgent pay": 1.0},
        }

    def test_prediction_uses_binary_unigram_and_bigram_features(self):
        self.assertGreater(predict(self.model, "URGENT pay"), 0.7)
        self.assertLess(predict(self.model, "ordinary note"), 0.7)

    def test_report_contains_aggregate_metrics_not_message_text(self):
        reports = report_metrics(
            "test",
            [("urgent pay now", 1), ("ordinary safe phrase", 0)],
            self.model,
        )
        self.assertEqual(reports["examples"], 2)
        self.assertNotIn("urgent", json.dumps(reports))
        self.assertEqual(reports["true_positives"], 1)

    def test_user_json_ignores_ambiguous_and_invalid_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "examples.json"
            path.write_text(json.dumps([
                {"text": "first", "expected_label": "suspicious"},
                {"text": "second", "expected_label": "benign"},
                {"text": "third", "expected_label": "ambiguous"},
                {"text": 12, "expected_label": "suspicious"},
            ]), encoding="utf-8")
            self.assertEqual(load_user_json(path), [("first", 1), ("second", 0)])

    def test_model_file_parser_reads_generated_format(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.js"
            path.write_text(
                '/* Generated model */\n"use strict";\n'
                'window.ScamShieldTextModel = Object.freeze({"intercept":-1,"threshold":0.7,"weights":{"x":2}});\n',
                encoding="utf-8",
            )
            self.assertEqual(load_model(path)["weights"]["x"], 2)

    def test_integrated_scanner_reports_rules_model_and_combined_triage(self):
        results = benchmark_scanner([
            ("Urgent: buy a gift card and send the code now.", 1),
            ("I asked for a gift card for my birthday.", 0),
        ])
        self.assertIn("rules_only", results)
        self.assertIn("model_only", results)
        self.assertIn("model_with_strong_rule_override", results)
        self.assertEqual(results["combined_initial_triage"]["true_positives"], 1)


if __name__ == "__main__":
    unittest.main()
